import { useState } from "react";
import { Plus, Star, Loader2, Trash2 } from "lucide-react";
import { SAPageHeader } from "@/components/superadmin/SuperAdminShell";
import { Button } from "@/components/ui/button";
import { formatINR } from "@/store/superAdminStore";
import { toast } from "sonner";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ConfirmModal } from "@/components/ui/ConfirmModal";
import {
  useGetPlansQuery,
  useCreatePlanMutation,
  useUpdatePlanMutation,
  useDeletePlanMutation,
  useGetModulesQuery,
} from "@/features/superadmin/superAdminApi";

const planSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, "Name is required"),
  slug: z.string().min(1, "Slug is required").regex(/^[a-z0-9-]+$/, "Only lowercase letters, numbers, and dashes allowed"),
  description: z.string().optional(),
  priceMonthly: z.number().min(0),
  priceYearly: z.number().min(0),
  maxUsers: z.number().min(0),
  maxStorageGb: z.number().min(0),
  features: z.string().optional(), // We'll store comma-separated features as an array internally
  modules: z.array(z.string()).optional(),
});

type PlanFormValues = z.infer<typeof planSchema>;

/**
 * Normalizes modules from any legacy format to string[]:
 * - Array ['pms','hrms'] → kept as-is
 * - Boolean map {pms:true, hrms:false} → ['pms']
 * - Indexed object {"0":"pms","1":"hrms"} → ['pms','hrms']
 * - null/undefined/{} → []
 */
function normalizeModules(raw: unknown): string[] {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw.filter((v): v is string => typeof v === 'string' && v.length > 0);
  if (typeof raw === 'object') {
    const entries = Object.entries(raw as Record<string, unknown>);
    if (entries.length === 0) return [];
    // Boolean map like {pms: true, hrms: false}
    const isBooleanMap = entries.every(([, v]) => typeof v === 'boolean');
    if (isBooleanMap) {
      return entries.filter(([, v]) => v === true).map(([k]) => k);
    }
    // Indexed object like {"0":"pms","1":"hrms"} → take values
    return entries.map(([, v]) => v).filter((v): v is string => typeof v === 'string' && v.length > 0);
  }
  return [];
}

/**
 * Normalizes features for the comma-separated text input.
 */
function normalizeFeatures(raw: unknown): string {
  if (!raw) return "";
  if (Array.isArray(raw)) return raw.join(", ");
  if (typeof raw === 'object') {
    const values = Object.values(raw as Record<string, unknown>);
    if (values.length === 0) return "";
    return values.filter((v): v is string => typeof v === 'string' && v.length > 0).join(", ");
  }
  return "";
}

export default function Plans() {
  const { data: plans = [], isLoading } = useGetPlansQuery(undefined);
  const { data: modules = [] } = useGetModulesQuery(undefined);
  
  const [createPlan] = useCreatePlanMutation();
  const [updatePlan] = useUpdatePlanMutation();
  const [deletePlan] = useDeletePlanMutation();

  const [editing, setEditing] = useState<any>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ id: string; name: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const isNew = editing && !editing.id;

  const form = useForm<PlanFormValues>({
    resolver: zodResolver(planSchema),
    defaultValues: {
      name: "",
      slug: "",
      description: "",
      priceMonthly: 0,
      priceYearly: 0,
      maxUsers: 5,
      maxStorageGb: 1,
      features: "",
      modules: [],
    },
  });

  const handleCreateNew = () => {
    form.reset({
      name: "",
      slug: "",
      description: "",
      priceMonthly: 0,
      priceYearly: 0,
      maxUsers: 5,
      maxStorageGb: 1,
      features: "",
      modules: [],
    });
    setEditing({});
  };

  const handleEdit = (p: any) => {
    // Normalize modules: handle all legacy formats
    const normalizedModules = normalizeModules(p.modules);

    form.reset({
      id: p.id,
      name: p.name,
      slug: p.slug,
      description: p.description || "",
      priceMonthly: Number(p.priceMonthly),
      priceYearly: Number(p.priceYearly),
      maxUsers: p.maxUsers,
      maxStorageGb: p.maxStorageGb,
      features: normalizeFeatures(p.features),
      modules: normalizedModules,
    });
    setEditing(p);
  };

  const onSubmit = async (values: PlanFormValues) => {
    try {
      const payload = {
        ...values,
        features: values.features ? values.features.split(",").map(f => f.trim()).filter(Boolean) : [],
      };

      if (isNew) {
        await createPlan(payload).unwrap();
        toast.success("Plan created successfully");
      } else {
        await updatePlan({ id: editing.id, ...payload }).unwrap();
        toast.success("Plan updated successfully");
      }
      setEditing(null);
    } catch (err: any) {
      const msg = Array.isArray(err.data?.message) ? err.data.message[0] : err.data?.message;
      toast.error(msg || "Failed to save plan");
    }
  };

  const confirmDelete = async () => {
    if (!deleteConfirm) return;
    setIsDeleting(true);
    try {
      await deletePlan(deleteConfirm.id).unwrap();
      toast.success(`Plan ${deleteConfirm.name} deleted successfully`);
      setDeleteConfirm(null);
    } catch (err: any) {
      toast.error(err.data?.message || "Failed to delete plan");
    } finally {
      setIsDeleting(false);
    }
  };

  if (isLoading) return <div className="p-8 flex justify-center"><Loader2 className="animate-spin w-8 h-8 text-primary" /></div>;

  return (
    <div className="pb-8">
      <SAPageHeader 
        title="Plan Management" 
        subtitle={`${plans.length} subscription plans configured`}
        actions={<Button onClick={handleCreateNew} size="sm" className="bg-indigo-600 hover:bg-indigo-700 text-white"><Plus className="w-4 h-4 mr-2" /> New Plan</Button>}
      />

      {plans.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 text-center bg-white border border-border mx-6 mt-6 rounded-xl border-dashed">
          <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 mb-4">
            <Star className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-semibold text-foreground">No Plans Found</h3>
          <p className="text-sm text-muted-foreground mt-1 max-w-sm">Create your first subscription plan to offer to tenants.</p>
          <Button onClick={handleCreateNew} className="mt-6 bg-indigo-600 hover:bg-indigo-700">Create Plan</Button>
        </div>
      ) : (
        <div className="px-6 pt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {plans.map((p: any) => {
            const planModules = normalizeModules(p.modules);
            const planFeatures = normalizeModules(p.features); // reuse same normalizer for features array

            return (
            <div key={p.id} className="bg-white border border-border rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
              {/* Header */}
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-semibold">{p.name}</h3>
                  {p.slug === "growth" && <Star className="w-4 h-4 fill-amber-400 text-amber-400" />}
                </div>
                <div className="flex items-center gap-1.5">
                  {p.isActive ? (
                    <span className="text-2xs px-1.5 py-0.5 rounded bg-green-100 text-green-700 font-semibold">Active</span>
                  ) : (
                    <span className="text-2xs px-1.5 py-0.5 rounded bg-gray-100 text-gray-500 font-semibold">Inactive</span>
                  )}
                  {p.isPubliclyVisible && (
                    <span className="text-2xs px-1.5 py-0.5 rounded bg-blue-50 text-blue-600 font-semibold">Public</span>
                  )}
                </div>
              </div>
              <p className="text-2xs text-muted-foreground font-mono mb-3">{p.slug}</p>

              {p.description && (
                <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{p.description}</p>
              )}

              {/* Pricing */}
              <div className="flex items-end gap-4 mb-4">
                <div>
                  <div className="text-2xs text-muted-foreground">Monthly</div>
                  <div className="text-xl font-mono font-semibold">{formatINR(p.priceMonthly)}</div>
                </div>
                <div>
                  <div className="text-2xs text-muted-foreground">Yearly</div>
                  <div className="text-lg font-mono font-medium text-gray-600">{formatINR(p.priceYearly)}</div>
                </div>
              </div>

              {/* Limits */}
              <div className="pt-3 border-t border-border space-y-1.5 text-xs">
                <Row label="Max Users" v={p.maxUsers ? `${p.maxUsers}` : "Unlimited"} />
                <Row label="Storage" v={`${p.maxStorageGb} GB`} />
                <Row label="AI Budget" v={`$${Number(p.aiCostLimitUsd || 0).toFixed(2)}`} />
              </div>

              {/* Modules */}
              {planModules.length > 0 && (
                <div className="mt-3">
                  <div className="text-2xs text-muted-foreground mb-1">Allowed Modules:</div>
                  <div className="flex flex-wrap gap-1">
                    {planModules.map((mId: string, i: number) => {
                      const mod = modules.find((m: any) => m.id === mId || m.name?.toLowerCase() === mId);
                      return <span key={i} className="text-2xs px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 font-medium">{mod ? mod.name : mId}</span>;
                    })}
                  </div>
                </div>
              )}

              {/* Features */}
              {planFeatures.length > 0 && (
                <div className="mt-3">
                  <div className="text-2xs text-muted-foreground mb-1">Features:</div>
                  <div className="flex flex-wrap gap-1">
                    {planFeatures.map((f: string, i: number) => (
                      <span key={i} className="text-2xs px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700">{f}</span>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="mt-5 flex gap-2">
                <Button size="sm" variant="outline" className="flex-1 border-gray-200 hover:bg-gray-50" onClick={() => handleEdit(p)}>Edit Config</Button>
                <Button size="sm" variant="outline" className="px-2.5 border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700" onClick={() => setDeleteConfirm({ id: p.id, name: p.name })} title="Delete Plan">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
            );
          })}
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity" onClick={() => setEditing(null)} />
          <div className="relative w-full max-w-md bg-white border-l border-border h-full p-6 overflow-y-auto shadow-2xl animate-in slide-in-from-right-8 duration-300">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-foreground">{isNew ? 'Create New Plan' : `Edit ${editing.name}`}</h3>
              <Button variant="ghost" size="icon" onClick={() => setEditing(null)} className="rounded-full w-8 h-8 hover:bg-gray-100">
                &times;
              </Button>
            </div>
            
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <Field label="Plan Name" error={form.formState.errors.name?.message}>
                <Input {...form.register("name")} placeholder="e.g. Basic, Pro, Enterprise" />
              </Field>

              <Field label="Slug (Unique Identifier)" error={form.formState.errors.slug?.message}>
                <Input {...form.register("slug")} placeholder="e.g. basic, pro, enterprise" />
              </Field>

              <div className="grid grid-cols-2 gap-4">
                <Field label="Monthly Price (₹)" error={form.formState.errors.priceMonthly?.message}>
                  <Input type="number" {...form.register("priceMonthly", { valueAsNumber: true })} />
                </Field>
                <Field label="Yearly Price (₹)" error={form.formState.errors.priceYearly?.message}>
                  <Input type="number" {...form.register("priceYearly", { valueAsNumber: true })} />
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Field label="Max Users" error={form.formState.errors.maxUsers?.message}>
                  <Input type="number" {...form.register("maxUsers", { valueAsNumber: true })} />
                </Field>
                <Field label="Max Storage (GB)" error={form.formState.errors.maxStorageGb?.message}>
                  <Input type="number" {...form.register("maxStorageGb", { valueAsNumber: true })} />
                </Field>
              </div>

              <Field label="Description" error={form.formState.errors.description?.message}>
                <Textarea {...form.register("description")} placeholder="Short description for the plan..." />
              </Field>

              <Field label="Features (comma separated)" error={form.formState.errors.features?.message}>
                <Textarea {...form.register("features")} placeholder="e.g. Priority Support, Custom Domain, White Label" />
              </Field>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Allowed Modules</label>
                {modules.length === 0 ? (
                  <p className="text-xs text-muted-foreground italic">No modules available. Create modules first.</p>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    {modules.map((m: any) => {
                      const selectedModules = form.watch("modules") || [];
                      const isChecked = selectedModules.includes(m.id);
                      return (
                        <label
                          key={m.id}
                          className={`flex items-center gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-all text-sm ${
                            isChecked
                              ? "border-indigo-300 bg-indigo-50 ring-1 ring-indigo-200"
                              : "border-gray-200 bg-white hover:bg-gray-50"
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {
                              const current = form.getValues("modules") || [];
                              const updated = isChecked
                                ? current.filter((id: string) => id !== m.id)
                                : [...current, m.id];
                              form.setValue("modules", updated, { shouldDirty: true });
                            }}
                            className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                          />
                          <div className="flex flex-col">
                            <span className="font-medium text-xs text-gray-800 leading-tight">{m.name}</span>
                            <span className={`text-2xs mt-0.5 ${m.status === 'active' ? 'text-green-600' : 'text-amber-600'}`}>{m.status}</span>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="pt-4 flex gap-3">
                <Button type="button" variant="outline" className="flex-1" onClick={() => setEditing(null)}>Cancel</Button>
                <Button type="submit" className="flex-1 bg-indigo-600 hover:bg-indigo-700">Save Plan</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!deleteConfirm}
        onClose={() => setDeleteConfirm(null)}
        onConfirm={confirmDelete}
        title="Delete Subscription Plan"
        description={
          <>
            Are you absolutely sure you want to delete the <strong>{deleteConfirm?.name}</strong> plan? <br />
            This action cannot be undone and will permanently remove the plan registry.
          </>
        }
        confirmText="Delete Plan"
        variant="destructive"
        isLoading={isDeleting}
      />
    </div>
  );
}

function Row({ label, v }: { label: string; v: React.ReactNode }) {
  return (
    <div className="flex justify-between items-center py-1">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-right text-gray-900">{v}</span>
    </div>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <label className="text-sm font-medium text-foreground">{label}</label>
      {children}
      {error && <p className="text-xs text-red-500">{error}</p>}
    </div>
  );
}

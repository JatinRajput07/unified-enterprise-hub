import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Shield, Eye, EyeOff, Lock, Loader2 } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { setCredentials, set2FaRequired } from "@/features/auth/authSlice";
import { useLoginMutation, useVerify2FaLoginMutation } from "@/features/auth/authApi";
import { useSuperAdminStore } from "@/store/superAdminStore"; // Keeping zustand store update for backwards compatibility if needed, but primarily relying on Redux

const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Must contain at least one uppercase letter")
    .regex(/[a-z]/, "Must contain at least one lowercase letter")
    .regex(/[0-9]/, "Must contain at least one number")
    .regex(/[^A-Za-z0-9]/, "Must contain at least one special character"),
});

const otpSchema = z.object({
  code: z.string().length(6, "Code must be exactly 6 digits").regex(/^\d+$/, "Code must contain only numbers"),
});

type LoginFormValues = z.infer<typeof loginSchema>;
type OtpFormValues = z.infer<typeof otpSchema>;

export default function SuperAdminLogin() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const setAuthed = useSuperAdminStore(s => s.setAuthed); // Fallback for legacy components
  const { isAuthenticated } = useSelector((state: any) => state.auth);
  
  const [step, setStep] = useState<"creds" | "otp">("creds");
  const [show, setShow] = useState(false);
  const [loginEmail, setLoginEmail] = useState("");

  const [login, { isLoading: isLoginLoading }] = useLoginMutation();
  const [verify2Fa, { isLoading: isVerifyLoading }] = useVerify2FaLoginMutation();



  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  const otpForm = useForm<OtpFormValues>({
    resolver: zodResolver(otpSchema),
    defaultValues: { code: "" },
  });

  const onSubmitCreds = async (data: LoginFormValues) => {
    try {
      setLoginEmail(data.email);
      const result = await login({ email: data.email, password: data.password }).unwrap();
      
      if (result.is2FaRequired) {
        dispatch(set2FaRequired(true));
        setStep("otp");
        toast.info("Please enter your 2FA code");
      } else {
        dispatch(setCredentials({ user: result.user }));
        setAuthed(true);
        toast.success(`Welcome back, ${result.user?.firstName || 'Admin'}`);
        navigate("/super-admin/dashboard");
      }
    } catch (err: any) {
      toast.error(err.message || "Invalid credentials");
    }
  };

  const onSubmitOtp = async (data: OtpFormValues) => {
    try {
      const result = await verify2Fa({ email: loginEmail, code: data.code }).unwrap();
      dispatch(setCredentials({ user: result.user }));
      setAuthed(true);
      toast.success(`Welcome back, ${result.user?.firstName || 'Admin'}`);
      navigate("/super-admin/dashboard");
    } catch (err: any) {
      toast.error(err.message || "Invalid 2FA code");
    }
  };

  if (isAuthenticated) {
    return <Navigate to="/super-admin/dashboard" replace />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-blue-50 p-4">
      <div className="w-full max-w-md">
        <div className="bg-white border border-border rounded-xl shadow-xl p-8">
          <div className="flex flex-col items-center mb-6">
            <div className="w-12 h-12 rounded-xl bg-primary text-white flex items-center justify-center mb-3">
              <Shield className="w-6 h-6" />
            </div>
            <h1 className="text-lg font-semibold">Super Admin</h1>
            <p className="text-2xs text-muted-foreground mt-1">Product Owner Console</p>
          </div>

          {step === "creds" ? (
            <form onSubmit={loginForm.handleSubmit(onSubmitCreds)} className="space-y-4">
              <div>
                <Label className="text-xs">Email <span className="text-destructive">*</span></Label>
                <Input 
                  type="email" 
                  {...loginForm.register("email")}
                  className="mt-1" 
                  placeholder="admin@yourdomain.com"
                />
                {loginForm.formState.errors.email && (
                  <p className="text-xs text-destructive mt-1">{loginForm.formState.errors.email.message}</p>
                )}
              </div>
              <div>
                <Label className="text-xs">Password <span className="text-destructive">*</span></Label>
                <div className="relative mt-1">
                  <Input 
                    type={show ? "text" : "password"} 
                    {...loginForm.register("password")}
                    placeholder="••••••••" 
                  />
                  <button 
                    type="button" 
                    onClick={() => setShow(!show)} 
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground"
                    aria-label={show ? "Hide password" : "Show password"}
                  >
                    {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {loginForm.formState.errors.password && (
                  <p className="text-xs text-destructive mt-1">{loginForm.formState.errors.password.message}</p>
                )}
              </div>
              
              <Button type="submit" disabled={isLoginLoading} className="w-full bg-primary hover:bg-primary/90">
                {isLoginLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Sign In
              </Button>
            </form>
          ) : (
            <form onSubmit={otpForm.handleSubmit(onSubmitOtp)} className="space-y-4">
              <div>
                <Label className="text-xs">2FA Code <span className="text-destructive">*</span></Label>
                <Input 
                  maxLength={6} 
                  {...otpForm.register("code")}
                  placeholder="6-digit code" 
                  className="mt-1 font-mono tracking-widest text-center text-lg" 
                  autoComplete="one-time-code"
                />
                <p className="text-2xs text-muted-foreground mt-1">Enter the 6-digit code from your authenticator app.</p>
                {otpForm.formState.errors.code && (
                  <p className="text-xs text-destructive mt-1">{otpForm.formState.errors.code.message}</p>
                )}
              </div>
              <Button type="submit" disabled={isVerifyLoading} className="w-full bg-primary hover:bg-primary/90">
                {isVerifyLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Verify & Continue
              </Button>
            </form>
          )}

          <div className="mt-6 pt-4 border-t border-border flex items-start gap-2 text-2xs text-muted-foreground">
            <Lock className="w-3 h-3 mt-0.5 shrink-0" />
            <span>This area is restricted to authorized personnel only. All access is logged.</span>
          </div>
        </div>
      </div>
    </div>
  );
}

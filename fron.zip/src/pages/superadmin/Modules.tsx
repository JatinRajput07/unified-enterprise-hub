import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { SAPageHeader } from "@/components/superadmin/SuperAdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Loader2, Plus, Settings2, Trash2 } from "lucide-react";
import {
  useGetModulesQuery,
  useCreateModuleMutation,
  useUpdateModuleMutation,
  useDeleteModuleMutation,
} from "@/features/superadmin/superAdminApi";
import { ConfirmModal } from "@/components/ui/ConfirmModal";

const moduleSchema = z.object({
  id: z.string().min(1, "Module ID is required"),
  name: z.string().min(1, "Display Name is required"),
  status: z.enum(["active", "maintenance", "beta", "deprecated"]),
  monthlyPrice: z.coerce.number().min(0, "Must be >= 0"),
  annualPrice: z.coerce.number().min(0, "Must be >= 0"),
  schemaName: z.string().min(1, "Database Schema is required"),
  description: z.string().optional(),
  maintenanceMsg: z.string().optional(),
  changelog: z.string().optional(),
});

type ModuleFormValues = z.infer<typeof moduleSchema>;

export default function Modules() {
  const { data: moduleConfigs = [], isLoading } = useGetModulesQuery(undefined);
  
  const [createModule] = useCreateModuleMutation();
  const [updateModule] = useUpdateModuleMutation();
  const [deleteModule] = useDeleteModuleMutation();
  
  const [editing, setEditing] = useState<any>(null); // null means not editing, {} means new, {id} means editing
  const [deleteConfirm, setDeleteConfirm] = useState<{ id: string; name: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const isNew = editing && !editing.createdAt;

  const form = useForm<ModuleFormValues>({
    resolver: zodResolver(moduleSchema),
    defaultValues: {
      id: "", name: "", status: "active", monthlyPrice: 0, annualPrice: 0, schemaName: "", description: "", maintenanceMsg: "", changelog: ""
    }
  });

  const handleEdit = (m: any) => {
    form.reset({
      id: m.id,
      name: m.name,
      status: m.status,
      monthlyPrice: m.monthlyPrice,
      annualPrice: m.annualPrice,
      schemaName: m.schemaName,
      description: m.description || "",
      maintenanceMsg: m.maintenanceMsg || "",
      changelog: m.changelog || "",
    });
    setEditing(m);
  };

  const handleCreateNew = () => {
    form.reset({
      id: "", name: "", status: "active", monthlyPrice: 0, annualPrice: 0, schemaName: "", description: "", maintenanceMsg: "", changelog: ""
    });
    setEditing({});
  };

  const onSubmit = async (values: ModuleFormValues) => {
    try {
      if (isNew) {
        await createModule(values).unwrap();
        toast.success("Module created successfully");
      } else {
        await updateModule({ id: values.id, ...values }).unwrap();
        toast.success("Module updated successfully");
      }
      setEditing(null);
    } catch (err: any) {
      const msg = Array.isArray(err.data?.message) ? err.data.message[0] : err.data?.message;
      toast.error(msg || "Failed to save module");
    }
  };

  const toggleStatus = async (m: any) => {
    try {
      const newStatus = m.status === "maintenance" ? "active" : "maintenance";
      await updateModule({ id: m.id, status: newStatus }).unwrap();
      toast.success(`Module is now ${newStatus}`);
    } catch (err: any) {
      toast.error(err.data?.message || "Failed to toggle status");
    }
  };

  const handleDelete = (id: string, name: string) => {
    setDeleteConfirm({ id, name });
  };

  const confirmDelete = async () => {
    if (!deleteConfirm) return;
    setIsDeleting(true);
    try {
      await deleteModule(deleteConfirm.id).unwrap();
      toast.success(`Module ${deleteConfirm.name} deleted successfully`);
      setDeleteConfirm(null);
    } catch (err: any) {
      toast.error(err.data?.message || "Failed to delete module");
    } finally {
      setIsDeleting(false);
    }
  };

  if (isLoading) return <div className="p-8 flex justify-center"><Loader2 className="animate-spin w-8 h-8 text-primary" /></div>;

  return (
    <div className="pb-8">
      <SAPageHeader 
        title="Product Modules" 
        subtitle={`${moduleConfigs.length} modules configured in the registry`} 
        actions={<Button onClick={handleCreateNew} size="sm" className="bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm"><Plus className="w-4 h-4 mr-2" /> New Module</Button>}
      />
      
      {moduleConfigs.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 text-center bg-white border border-border mx-6 mt-6 rounded-xl border-dashed">
          <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 mb-4">
            <Settings2 className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-semibold text-foreground">No Modules Found</h3>
          <p className="text-sm text-muted-foreground mt-1 max-w-sm">Create your first product module to start provisioning tenants with it.</p>
          <Button onClick={handleCreateNew} className="mt-6 bg-indigo-600 hover:bg-indigo-700">Create Module</Button>
        </div>
      ) : (
        <div className="px-6 pt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {moduleConfigs.map((m: any) => (
            <div key={m.id} className="bg-white border border-border rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
              {m.status === 'beta' && (
                <div className="absolute -right-6 top-4 rotate-45 bg-indigo-500 text-white text-[10px] font-bold py-0.5 px-8 shadow-sm">BETA</div>
              )}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2.5">
                  <div className={`w-3 h-3 rounded-full shadow-sm ${m.status === 'active' ? 'bg-green-500' : m.status === 'maintenance' ? 'bg-amber-500' : m.status === 'beta' ? 'bg-indigo-500' : 'bg-gray-400'}`} />
                  <h3 className="font-semibold text-base text-foreground">{m.name}</h3>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-md uppercase font-bold tracking-wider ${m.status === "active" ? "bg-green-100 text-green-700" : m.status === "maintenance" ? "bg-amber-100 text-amber-800" : m.status === 'beta' ? "bg-indigo-100 text-indigo-700" : "bg-gray-100 text-gray-600"}`}>
                  {m.status}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mb-4 line-clamp-2 h-8">{m.description || 'No description provided.'}</p>
              <div className="text-xs space-y-2 bg-gray-50/50 p-3 rounded-lg border border-border/50">
                <Row label="Module ID" v={<span className="font-mono text-xs bg-gray-200/50 px-1.5 py-0.5 rounded text-gray-700">{m.id}</span>} />
                <Row label="Monthly Price" v={<span className="font-medium">₹{m.monthlyPrice}</span>} />
                <Row label="Database Schema" v={<span className="font-mono text-xs text-indigo-600">{m.schemaName}</span>} />
              </div>
              <div className="mt-5 flex gap-3">
                <Button size="sm" variant="outline" className="flex-1 border-gray-200 hover:bg-gray-50" onClick={() => handleEdit(m)}>Edit Config</Button>
                <Button size="sm" variant={m.status === "maintenance" ? "default" : "outline"} className={`flex-1 transition-colors ${m.status === 'maintenance' ? 'bg-green-600 hover:bg-green-700 text-white' : 'border-gray-200 hover:bg-gray-50'}`} onClick={() => toggleStatus(m)}>
                  {m.status === "maintenance" ? "Resume" : "Maintenance"}
                </Button>
                <Button size="sm" variant="outline" className="px-2.5 border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700" onClick={() => handleDelete(m.id, m.name)} title="Delete Module">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity" onClick={() => setEditing(null)} />
          <div className="relative w-full max-w-md bg-white border-l border-border h-full p-6 overflow-y-auto shadow-2xl animate-in slide-in-from-right-8 duration-300">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-foreground">{isNew ? 'Create New Module' : `Edit ${editing.name}`}</h3>
              <Button variant="ghost" size="icon" onClick={() => setEditing(null)} className="rounded-full w-8 h-8 hover:bg-gray-100">
                &times;
              </Button>
            </div>
            
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <Field label="Module ID" error={form.formState.errors.id?.message}>
                <Input {...form.register("id")} disabled={!isNew} placeholder="e.g. sales, finance, pms" className={!isNew ? "bg-gray-100" : ""} />
                {isNew && <p className="text-[10px] text-muted-foreground mt-1">Unique identifier. Cannot be changed later.</p>}
              </Field>
              <Field label="Display Name" error={form.formState.errors.name?.message}>
                <Input {...form.register("name")} placeholder="e.g. Sales & CRM" />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Monthly Price (₹)" error={form.formState.errors.monthlyPrice?.message}>
                  <Input type="number" {...form.register("monthlyPrice")} />
                </Field>
                <Field label="Annual Price (₹)" error={form.formState.errors.annualPrice?.message}>
                  <Input type="number" {...form.register("annualPrice")} />
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Database Schema" error={form.formState.errors.schemaName?.message}>
                  <Input {...form.register("schemaName")} placeholder="e.g. sales_db" />
                </Field>
                <Field label="Status" error={form.formState.errors.status?.message}>
                  <select {...form.register("status")} className="h-9 w-full px-3 text-sm border border-input rounded-md bg-transparent shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring">
                    <option value="active">Active</option>
                    <option value="beta">Beta</option>
                    <option value="maintenance">Maintenance</option>
                    <option value="deprecated">Deprecated</option>
                  </select>
                </Field>
              </div>
              
              <Field label="Description" error={form.formState.errors.description?.message}>
                <Textarea {...form.register("description")} placeholder="Describe the module's core features..." rows={3} className="resize-none" />
              </Field>

              {form.watch("status") === "maintenance" && (
                <Field label="Maintenance Message" error={form.formState.errors.maintenanceMsg?.message}>
                  <Textarea {...form.register("maintenanceMsg")} placeholder="Message shown to users during downtime..." rows={2} className="resize-none" />
                </Field>
              )}

              <Field label="Changelog & Version Notes" error={form.formState.errors.changelog?.message}>
                <Textarea {...form.register("changelog")} placeholder="Latest release notes..." rows={3} className="resize-none font-mono text-xs" />
              </Field>

              <div className="pt-6 flex gap-3 sticky bottom-0 bg-white pb-4">
                <Button type="button" variant="outline" className="flex-1" onClick={() => setEditing(null)}>Cancel</Button>
                <Button type="submit" className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                  {isNew ? 'Create Module' : 'Save Changes'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!deleteConfirm}
        onClose={() => setDeleteConfirm(null)}
        onConfirm={confirmDelete}
        title="Delete Product Module"
        description={
          <>
            Are you absolutely sure you want to delete the <strong>{deleteConfirm?.name}</strong> module? <br />
            This action cannot be undone and will permanently remove the module registry. It may also break functionality for tenants subscribed to this module.
          </>
        }
        confirmText="Delete Module"
        variant="destructive"
        isLoading={isDeleting}
      />
    </div>
  );
}

function Row({ label, v }: { label: string; v: React.ReactNode }) {
  return (
    <div className="flex justify-between items-center py-1.5 border-b border-border/40 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right">{v}</span>
    </div>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs font-semibold text-gray-700 mb-1.5 block">
        {label} {error && <span className="text-red-500 ml-1 text-xs">*</span>}
      </label>
      {children}
      {error && <p className="text-red-500 text-xs mt-1.5 font-medium">{error}</p>}
    </div>
  );
}

import { apiSlice } from '../../services/api/apiSlice';

export const superAdminApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getModules: builder.query({
      query: () => ({ url: '/super-admin/modules' }),
      transformResponse: (response: any) => response.data,
      providesTags: ['Modules'],
    }),
    getTenants: builder.query({
      query: (params) => ({
        url: '/super-admin/tenants',
        params,
      }),
      providesTags: ['Tenants'],
    }),
    getModuleById: builder.query({
      query: (id: string) => ({ url: `/super-admin/modules/${id}` }),
      transformResponse: (response: any) => response.data,
      providesTags: (result, error, id) => [{ type: 'Modules', id }],
    }),
    createModule: builder.mutation({
      query: (data) => ({
        url: '/super-admin/modules',
        method: 'POST',
        data,
      }),
      invalidatesTags: ['Modules'],
    }),
    updateModule: builder.mutation({
      query: ({ id, ...data }) => ({
        url: `/super-admin/modules/${id}`,
        method: 'PUT',
        data,
      }),
      invalidatesTags: (result, error, { id }) => [{ type: 'Modules', id }, 'Modules'],
    }),
    deleteModule: builder.mutation({
      query: (id: string) => ({
        url: `/super-admin/modules/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['Modules'],
    }),
    getPlans: builder.query({
      query: () => ({ url: '/super-admin/plans' }),
      transformResponse: (response: any) => response.data,
      providesTags: ['Plans'],
    }),
    getPlanById: builder.query({
      query: (id: string) => ({ url: `/super-admin/plans/${id}` }),
      transformResponse: (response: any) => response.data,
      providesTags: (result, error, id) => [{ type: 'Plans', id }],
    }),
    createPlan: builder.mutation({
      query: (data) => ({
        url: '/super-admin/plans',
        method: 'POST',
        data,
      }),
      invalidatesTags: ['Plans'],
    }),
    updatePlan: builder.mutation({
      query: ({ id, ...data }) => ({
        url: `/super-admin/plans/${id}`,
        method: 'PUT',
        data,
      }),
      invalidatesTags: (result, error, { id }) => [{ type: 'Plans', id }, 'Plans'],
    }),
    deletePlan: builder.mutation({
      query: (id: string) => ({
        url: `/super-admin/plans/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['Plans'],
    }),
  }),
});

export const {
  useGetModulesQuery,
  useGetTenantsQuery,
  useGetModuleByIdQuery,
  useCreateModuleMutation,
  useUpdateModuleMutation,
  useDeleteModuleMutation,
  useGetPlansQuery,
  useGetPlanByIdQuery,
  useCreatePlanMutation,
  useUpdatePlanMutation,
  useDeletePlanMutation,
} = superAdminApi;

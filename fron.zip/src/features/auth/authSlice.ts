import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface User {
  id: string;
  email: string;
  roles: string[];
  permissions: string[];
  [key: string]: any;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  is2FaRequired: boolean;
}

const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  is2FaRequired: false,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setCredentials: (
      state,
      action: PayloadAction<{ user: User }>
    ) => {
      state.user = action.payload.user;
      state.isAuthenticated = true;
      state.is2FaRequired = false;
    },
    set2FaRequired: (state, action: PayloadAction<boolean>) => {
      state.is2FaRequired = action.payload;
    },
    logout: (state) => {
      state.user = null;
      state.isAuthenticated = false;
      state.is2FaRequired = false;
    },
  },
});

export const { setCredentials, set2FaRequired, logout } = authSlice.actions;

export default authSlice.reducer;

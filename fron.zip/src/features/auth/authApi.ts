import { apiSlice } from '../../services/api/apiSlice';

export const authApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    login: builder.mutation({
      query: (credentials) => ({
        url: '/auth/login',
        method: 'POST',
        data: credentials,
      }),
    }),
    verify2FaLogin: builder.mutation({
      query: (data) => ({
        url: '/auth/2fa/verify-login',
        method: 'POST',
        data,
      }),
    }),
    logout: builder.mutation({
      query: () => ({
        url: '/auth/logout',
        method: 'POST',
      }),
    }),
    getCurrentUser: builder.query({
      query: () => ({
        url: '/me', // ProfileController endpoint
        method: 'GET',
      }),
      providesTags: ['User'],
    }),
  }),
});

export const {
  useLoginMutation,
  useVerify2FaLoginMutation,
  useLogoutMutation,
  useGetCurrentUserQuery,
} = authApi;

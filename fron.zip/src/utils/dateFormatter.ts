import { format, formatDistanceToNow } from 'date-fns';

/**
 * Formats a date string or object to '24 Feb 2024'
 */
export const formatDate = (date: string | Date): string => {
  if (!date) return '';
  return format(new Date(date), 'dd MMM yyyy');
};

/**
 * Formats a date to relative time, e.g., '1 hour ago'
 */
export const formatRelativeTime = (date: string | Date): string => {
  if (!date) return '';
  return formatDistanceToNow(new Date(date), { addSuffix: true });
};

/**
 * Formats date and time '24 Feb 2024, 10:30 AM'
 */
export const formatDateTime = (date: string | Date): string => {
  if (!date) return '';
  return format(new Date(date), 'dd MMM yyyy, hh:mm a');
};

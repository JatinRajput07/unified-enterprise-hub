You are a top-level CTO and senior backend architect. I want to build a production-grade NestJS backend from scratch. Set up the COMPLETE foundation in one go.

## Tech Stack
- NestJS (latest) with TypeScript strict mode
- PostgreSQL with TypeORM
- Redis (caching + sessions)
- JWT + Refresh Tokens
- BullMQ for queues (install only, configure in Phase 3)

## Project Structure to Create
src/
├── app.module.ts
├── main.ts
├── common/
│   ├── guards/          # JWT, Roles, Permissions
│   ├── interceptors/    # Response transform, logging, timeout
│   ├── filters/         # Global exception filter
│   ├── decorators/      # @CurrentUser, @Roles, @Permissions
│   ├── pipes/           # ValidationPipe, ParseUUID
│   ├── dto/             # PaginationDto, BaseResponseDto
│   └── utils/           # helpers, crypto, date utils
├── config/
│   ├── app.config.ts
│   ├── database.config.ts
│   ├── redis.config.ts
│   └── configuration.ts  # centralized config loader
├── database/
│   ├── base.entity.ts    # id, createdAt, updatedAt, deletedAt
│   ├── migrations/
│   └── seeds/
├── modules/
│   ├── auth/
│   │   ├── auth.module.ts
│   │   ├── auth.service.ts
│   │   ├── auth.controller.ts
│   │   ├── strategies/    # jwt.strategy, refresh.strategy, google.strategy, github.strategy
│   │   ├── dto/
│   │   └── entities/      # refresh-token.entity.ts
│   ├── users/
│   │   ├── users.module.ts
│   │   ├── users.service.ts
│   │   ├── users.controller.ts
│   │   ├── dto/
│   │   └── entities/user.entity.ts
│   ├── roles/
│   │   ├── roles.module.ts
│   │   ├── roles.service.ts
│   │   └── entities/      # role.entity, permission.entity
│   └── tenants/
│       ├── tenants.module.ts
│       ├── tenants.service.ts
│       ├── tenant.middleware.ts
│       └── entities/tenant.entity.ts

## What to implement — be COMPLETE, no stubs

### 1. Environment Config (.env based)
- Create .env.example with ALL variables: APP_PORT, APP_ENV, DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS, REDIS_URL, JWT_SECRET, JWT_EXPIRES_IN, JWT_REFRESH_SECRET, JWT_REFRESH_EXPIRES_IN, GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GITHUB_CLIENT_ID, GITHUB_CLIENT_SECRET, FRONTEND_URL
- Use @nestjs/config with Joi validation schema (app crashes if required vars missing)
- Separate config files per domain (database.config.ts, redis.config.ts, etc.)
- ConfigService injection pattern everywhere — NO process.env direct access

### 2. Database Setup
- TypeORM with PostgreSQL, connection pooling (max: 10, idle timeout: 30000)
- BaseEntity with: id (UUID v4, primary), createdAt, updatedAt, deletedAt (soft delete), version (optimistic locking)
- Multiple DB connections ready: { name: 'default' } and { name: 'readonly' } config slots
- Auto-migration on non-prod, manual migration on prod
- Seed system with a base seeder class

### 3. Auth Module (COMPLETE implementation)
- JWT access token (15min) + Refresh token (7 days) rotation
- OAuth: Google + GitHub passport strategies (return profile, upsert user)
- 2FA: TOTP-based (speakeasy/otplib), QR code generation endpoint, verify endpoint
- SSO-ready: structure that accepts external identity provider token
- Endpoints: POST /auth/register, POST /auth/login, POST /auth/refresh, POST /auth/logout, GET /auth/google, GET /auth/google/callback, GET /auth/github, GET /auth/github/callback, POST /auth/2fa/enable, POST /auth/2fa/verify, POST /auth/2fa/disable

### 4. RBAC + Permission System
- User → Roles (many-to-many) → Permissions (many-to-many)
- Permission format: "resource:action" e.g. "users:read", "orders:delete"
- @Roles('admin', 'moderator') decorator + RolesGuard
- @Permissions('users:read') decorator + PermissionsGuard
- Hierarchical: SUPER_ADMIN > ADMIN > MODERATOR > USER
- Seed default roles and permissions on startup

### 5. Tenant System (Multi-tenancy)
- Tenant entity: id, name, subdomain, domain, plan, isActive, settings (jsonb)
- TenantMiddleware: extracts tenant from subdomain header (X-Tenant-ID) or request host
- TenantGuard: validates tenant exists and is active
- @Tenant() decorator to access current tenant in controllers
- TenantService: CRUD + find by subdomain
- Tenant-scoped DB queries (add tenantId to all relevant entities via BaseEntity extension)

### 6. Global Setup (main.ts)
- Global ValidationPipe (whitelist: true, forbidNonWhitelisted: true, transform: true)
- Global exception filter with standard error format: { success, statusCode, message, error, timestamp, path }
- Global response interceptor: wraps all responses in { success: true, data, meta }
- Helmet for security headers
- CORS with whitelist from config
- Compression (gzip)
- Request ID middleware (UUID per request, attach to logger context)

### 7. Logging
- Winston logger as NestJS logger provider
- Log levels per environment: error+warn in prod, all in dev
- Log format: JSON in prod, pretty in dev
- Include: timestamp, level, context (module name), requestId, userId (if available), message
- Log to console + file (logs/app.log, logs/error.log) with daily rotation
- Correlation ID propagated via AsyncLocalStorage

### 8. Pagination & Common DTOs
- CursorPaginationDto and OffsetPaginationDto
- PaginatedResponseDto<T> generic
- Utility function: paginate(query, dto) that handles both styles
- SortDto with allowedFields whitelist to prevent SQL injection via sort param

## Code Quality Rules
- All services return typed DTOs, never raw entities to controller
- Repository pattern: custom repositories extending TypeORM Repository<Entity>
- No any types — strict TypeScript
- class-validator + class-transformer on ALL DTOs
- Swagger @ApiProperty on all DTOs
- Unit test stubs for every service (Jest, no real DB)

## Output
Generate ALL files completely. No "// implement this" comments.
Start with package.json dependencies, then tsconfig, then nest-cli.json, then files in order of dependency (config → database → common → modules).
import { NestFactory } from '@nestjs/core';
import {
  ValidationPipe,
  VersioningType,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import compression from 'compression';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import { AppModule } from './app.module';
import { createWinstonLogger } from './common/logger/winston.logger';
import { ensureDatabasesExist } from './database/auto-create-db';

async function bootstrap() {
  // Ensure databases exist before bootstrapping Nest app
  await ensureDatabasesExist();
  // Create Winston logger early
  const env = process.env.APP_ENV || 'development';
  const logDir = process.env.LOG_DIR || 'logs';
  const logLevel = process.env.LOG_LEVEL || 'debug';
  const logger = createWinstonLogger(env, logDir, logLevel);

  const app = await NestFactory.create(AppModule, {
    // logger,
    rawBody: true
  });

  const configService = app.get(ConfigService);

  // ==================
  // Security
  // ==================
  app.use(helmet({
    crossOriginEmbedderPolicy: false,
    contentSecurityPolicy: {
      directives: {
        defaultSrc: [`'self'`],
        scriptSrc: [`'self'`, `'unsafe-inline'`, `https://cdn.jsdelivr.net`],
        styleSrc: [`'self'`, `'unsafe-inline'`, `https://cdn.jsdelivr.net`],
        imgSrc: [`'self'`, `data:`, `https://validator.swagger.io`],
        connectSrc: [`'self'`, `https://*`],
      },
    },
  }));
  app.use(cookieParser());
  app.use(compression());

  // ==================
  // CORS
  // ==================
  const allowedOrigins = (configService.get<string>('ALLOWED_ORIGINS') || 'http://localhost:5173')
    .split(',')
    .map((origin) => origin.trim());

  app.enableCors({
    origin: allowedOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: [
      'Content-Type',
      'Authorization',
      'X-Request-Id',
      'X-Tenant-ID',
    ],
  });

  // ==================
  // API Versioning
  // ==================
  app.enableVersioning({
    type: VersioningType.URI,
    defaultVersion: '1',
  });

  // ==================
  // Global Validation Pipe
  // ==================
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: {
        enableImplicitConversion: true,
      },
    }),
  );

  // ==================
  // Swagger
  // ==================
  const swaggerEnabled = configService.get<string>('SWAGGER_ENABLED') === 'true';
  if (swaggerEnabled || env !== 'production') {
    const swaggerConfig = new DocumentBuilder()
      .setTitle('Enterprise CRM API')
      .setDescription('Production-grade Enterprise CRM Backend API with Multi-tenancy & Advanced Auth')
      .setVersion('1.0')
      .addBearerAuth()
      .addApiKey({ type: 'apiKey', name: 'X-Tenant-ID', in: 'header' }, 'tenant')
      // Logical Grouping & Order as requested by user
      .addTag('Super Admin', 'Platform-level management, stats, and health monitoring')
      .addTag('Tenants', 'Tenant lifecycle management, provisioning, and product access')
      .addTag('Auth', 'Secure RS256 Authentication, 2FA, and Session Management')
      .addTag('Users', 'Tenant-specific user management and role assignment')
      .addTag('CRM', 'Sales, Leads, and Customer Relationship Management')
      .addTag('HRMS', 'Human Resource Management System')
      .addTag('Finance', 'Financial tracking, invoicing, and accounting')
      .addTag('Search', 'Global ElasticSearch indexing and discovery')
      .addTag('Health', 'System health checks and readiness probes')
      .build();

    const document = SwaggerModule.createDocument(app, swaggerConfig);
    SwaggerModule.setup('api/docs', app, document, {
      swaggerOptions: {
        persistAuthorization: true,
        displayRequestDuration: true,
        filter: true,
        docExpansion: 'none',
      },
    });

    logger.log(`📝 Swagger docs available at /api/docs`, 'Bootstrap');
  }

  // ==================
  // Global Prefix
  // ==================
  app.setGlobalPrefix('api', {
    exclude: ['health', 'health/ready', 'health/detailed'],
  });

  // ==================
  // Start Server
  // ==================
  const port = configService.get<number>('APP_PORT') || 3000;
  await app.listen(port);

  logger.log(`🚀 Application running on: http://localhost:${port}`, 'Bootstrap');
  logger.log(`📌 Environment: ${env}`, 'Bootstrap');
  logger.log(`🔒 CORS origins: ${allowedOrigins.join(', ')}`, 'Bootstrap');
}

bootstrap();

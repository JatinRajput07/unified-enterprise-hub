export const PRODUCT_DB_NAMES = {
  auth: 'auth',
  sales: 'sales',
  hrms: 'hrms',
  pms: 'pms',
  finance: 'finance',
} as const;

export type ProductName = keyof typeof PRODUCT_DB_NAMES;

import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Client } from 'pg';
import { ProductName } from './product-db.constants';
import { TenantConnectionService } from './tenant-connection.service';

@Injectable()
export class SchemaProvisionerService {
  private readonly logger = new Logger(SchemaProvisionerService.name);

  constructor(
    private readonly configService: ConfigService,
    private readonly connectionService: TenantConnectionService,
  ) {}

  /**
   * Provision one or more product schemas for a tenant.
   */
  async provisionSchemas(tenantSlug: string, products: ProductName[]): Promise<void> {
    this.logger.log(`Provisioning schemas for tenant '${tenantSlug}' for products: ${products.join(', ')}`);

    for (const product of products) {
      try {
        await this.createSchemaIfNotExists(product, tenantSlug);
        await this.syncSchema(product, tenantSlug);
        this.logger.log(`Successfully provisioned ${product} schema for ${tenantSlug}`);
      } catch (error) {
        this.logger.error(`Failed to provision ${product} schema for ${tenantSlug}: ${(error as Error).message}`);
      }
    }
  }

  private async syncSchema(product: ProductName, schemaName: string): Promise<void> {
    this.logger.debug(`Synchronizing schema for ${product}:${schemaName}...`);
    const dataSource = await this.connectionService.getConnection(product, schemaName);
    
    // In development, we use synchronize() to ensure tables are created in the tenant's schema.
    // In production, we should use migrations.
    await dataSource.synchronize();
    this.logger.debug(`Schema synchronization complete for ${product}:${schemaName}`);
  }

  async deprovisionSchemas(tenantSlug: string, products: ProductName[]): Promise<void> {
    for (const product of products) {
      await this.dropSchemaIfExists(product, tenantSlug);
      await this.connectionService.closeConnection(product, tenantSlug);
    }
  }

  private async createSchemaIfNotExists(product: ProductName, schemaName: string): Promise<void> {
    const config = this.configService.get(`database.${product}`);
    const client = new Client({
      host: config.host,
      port: config.port,
      user: config.user,
      password: config.pass,
      database: config.name,
    });

    try {
      await client.connect();
      await client.query(`CREATE SCHEMA IF NOT EXISTS "${schemaName}"`);
      this.logger.debug(`Created schema "${schemaName}" in ${product}_db`);
    } finally {
      await client.end();
    }
  }

  private async dropSchemaIfExists(product: ProductName, schemaName: string): Promise<void> {
    const config = this.configService.get(`database.${product}`);
    const client = new Client({
      host: config.host,
      port: config.port,
      user: config.user,
      password: config.pass,
      database: config.name,
    });

    try {
      await client.connect();
      await client.query(`DROP SCHEMA IF EXISTS "${schemaName}" CASCADE`);
      this.logger.warn(`Dropped schema "${schemaName}" in ${product}_db`);
    } finally {
      await client.end();
    }
  }
}

import { Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DataSource } from 'typeorm';
import { ProductName } from './product-db.constants';
import { SnakeNamingStrategy } from '../common/utils/snake-naming.strategy';

// Registry Entities
import { TenantEntity } from '../modules/tenants/entities/tenant.entity';
import { Plan } from '../modules/tenants/entities/plan.entity';

// Auth Entities
import { UserEntity } from '../modules/users/entities/user.entity';
import { RoleEntity } from '../modules/roles/entities/role.entity';
import { PermissionEntity } from '../modules/roles/entities/permission.entity';
import { SessionEntity } from '../modules/auth/entities/session.entity';
import { RefreshTokenEntity } from '../modules/auth/entities/refresh-token.entity';
import { AuthLogEntity } from '../modules/auth/entities/auth-log.entity';

// CRM Entities
import { Lead } from '../modules/products/crm/entities/lead.entity';

// HRMS Entities
import { Employee } from '../modules/products/hrms/entities/employee.entity';
import { Leave } from '../modules/products/hrms/entities/leave.entity';
import { Payroll } from '../modules/products/hrms/entities/payroll.entity';

// Finance Entities
import { Invoice } from '../modules/products/finance/entities/invoice.entity';
import { Budget } from '../modules/products/finance/entities/budget.entity';

import { Contact } from '../modules/products/crm/entities/contact.entity';
import { Deal } from '../modules/products/crm/entities/deal.entity';

@Injectable()
export class TenantConnectionService implements OnModuleDestroy {
  private readonly logger = new Logger(TenantConnectionService.name);
  private connectionPool = new Map<string, DataSource>();

  constructor(private readonly configService: ConfigService) {}

  getPoolStats() {
    const stats: Record<string, number> = { totalCachedConnections: this.connectionPool.size };
    const byProduct: Record<string, number> = {};

    for (const key of this.connectionPool.keys()) {
      const [product] = key.split(':');
      byProduct[product] = (byProduct[product] || 0) + 1;
    }

    stats.connectionsByProduct = byProduct as any;
    return stats;
  }

  async getConnection(product: ProductName, tenantSlug: string): Promise<DataSource> {
    const poolKey = `${product}:${tenantSlug}`;
    let dataSource = this.connectionPool.get(poolKey);
    if (dataSource && dataSource.isInitialized) return dataSource;
    dataSource = await this.createConnection(product, tenantSlug);
    this.connectionPool.set(poolKey, dataSource);
    return dataSource;
  }

  private async createConnection(product: ProductName, tenantSlug: string): Promise<DataSource> {
    const config = this.configService.get(`database.${product}`);
    if (!config) throw new Error(`Database configuration for product '${product}' not found`);

    const entityMap: Record<ProductName, any[]> = {
      auth: [TenantEntity, Plan, UserEntity, RoleEntity, PermissionEntity, SessionEntity, RefreshTokenEntity, AuthLogEntity],
      sales: [TenantEntity, Plan, Lead, Contact, Deal],
      hrms: [TenantEntity, Plan, Employee, Leave, Payroll],
      finance: [TenantEntity, Plan, Invoice, Budget],
      pms: [TenantEntity, Plan],
    };

    const dataSource = new DataSource({
      type: 'postgres',
      host: config.host,
      port: config.port,
      username: config.user,
      password: config.pass,
      database: config.name,
      schema: tenantSlug,
      synchronize: false,
      logging: ['error', 'warn'],
      namingStrategy: new SnakeNamingStrategy(),
      entities: entityMap[product] || [],
    });

    try {
      await dataSource.initialize();
      this.logger.log(`Initialized connection for ${product}:${tenantSlug} (Schema: ${tenantSlug})`);
      return dataSource;
    } catch (error) {
      this.logger.error(`Failed to initialize connection for ${product}:${tenantSlug}: ${(error as Error).message}`);
      throw error;
    }
  }

  async closeConnection(product: ProductName, tenantSlug: string): Promise<void> {
    const poolKey = `${product}:${tenantSlug}`;
    const dataSource = this.connectionPool.get(poolKey);
    if (dataSource) {
      if (dataSource.isInitialized) await dataSource.destroy();
      this.connectionPool.delete(poolKey);
    }
  }

  async onModuleDestroy(): Promise<void> {
    for (const [key, dataSource] of this.connectionPool.entries()) {
      if (dataSource.isInitialized) await dataSource.destroy();
    }
    this.connectionPool.clear();
  }
}

import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { RoleEntity } from '../modules/roles/entities/role.entity';
import { PermissionEntity } from '../modules/roles/entities/permission.entity';

@Injectable()
export class TenantSeedService {
  private readonly logger = new Logger(TenantSeedService.name);

  /**
   * Seed default roles and permissions for a new tenant.
   */
  async seedInitialData(dataSource: DataSource): Promise<void> {
    const roleRepo = dataSource.getRepository(RoleEntity);
    const permRepo = dataSource.getRepository(PermissionEntity);

    this.logger.log(`Seeding initial roles and permissions for schema: ${(dataSource.options as any).schema}`);

    // 1. Define Permissions
    const permissions = [
      { name: 'All Access', slug: 'all', description: 'Full system access' },
      { name: 'View Users', slug: 'users:view', description: 'Can view users' },
      { name: 'Manage Users', slug: 'users:manage', description: 'Can create/edit/delete users' },
      { name: 'View Roles', slug: 'roles:view', description: 'Can view roles' },
      { name: 'Manage Roles', slug: 'roles:manage', description: 'Can manage roles and permissions' },
      { name: 'View Billing', slug: 'billing:view', description: 'Can view billing info' },
    ];

    const savedPerms: PermissionEntity[] = [];
    for (const p of permissions) {
      let perm = await permRepo.findOne({ where: { slug: p.slug } });
      if (!perm) {
        perm = permRepo.create(p);
        perm = await permRepo.save(perm);
      }
      savedPerms.push(perm);
    }

    // 2. Define Roles
    const roles = [
      {
        name: 'ORG_ADMIN',
        description: 'Organization Administrator',
        isSystem: true,
        permissions: savedPerms, // Admin gets all initial perms
      },
      {
        name: 'EMPLOYEE',
        description: 'Standard Employee',
        isSystem: true,
        permissions: savedPerms.filter(p => p.slug === 'users:view'), // Limited perms
      },
    ];

    for (const r of roles) {
      let role = await roleRepo.findOne({ where: { name: r.name } });
      if (!role) {
        role = roleRepo.create(r);
        await roleRepo.save(role);
      }
    }

    this.logger.log(`Seeding complete for schema: ${(dataSource.options as any).schema}`);
  }
}

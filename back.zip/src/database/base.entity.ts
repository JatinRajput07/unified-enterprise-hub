import {
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  VersionColumn,
  Column,
} from 'typeorm';

export abstract class BaseEntity {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt!: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updatedAt!: Date;

  @DeleteDateColumn({ type: 'timestamptz', nullable: true })
  deletedAt?: Date;

  @VersionColumn({ default: 1 })
  version!: number;
}

/**
 * Extended base entity that includes tenantId for multi-tenant scoped entities.
 */
export abstract class TenantScopedEntity extends BaseEntity {
  @Column({ type: 'uuid' })
  tenantId!: string;
}


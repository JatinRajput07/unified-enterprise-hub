import { Global, Module } from '@nestjs/common';
import { SchemaProvisionerService } from './schema-provisioner.service';
import { TenantConnectionService } from './tenant-connection.service';
import { TenantSeedService } from './tenant-seed.service';

@Global()
@Module({
  providers: [SchemaProvisionerService, TenantConnectionService, TenantSeedService],
  exports: [SchemaProvisionerService, TenantConnectionService, TenantSeedService],
})
export class DatabaseCoreModule {}

import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { TenantConnectionService } from './tenant-connection.service';
import { ProductName } from './product-db.constants';

@Injectable()
export class MigrationRunnerService {
  private readonly logger = new Logger(MigrationRunnerService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  /**
   * Run migrations for a specific schema in a specific product database.
   */
  async runMigrations(product: ProductName, tenantSlug: string) {
    this.logger.log(`Running migrations for ${product}:${tenantSlug}...`);
    
    const ds = await this.tenantConn.getConnection(product, tenantSlug);
    
    try {
      // Synchronize schema (In production, use proper migration files)
      // This will create tables based on entities for that specific schema
      await ds.synchronize();
      this.logger.log(`Successfully synchronized schema for ${product}:${tenantSlug}`);
    } catch (error) {
      this.logger.error(`Failed to synchronize schema for ${product}:${tenantSlug}: ${(error as Error).message}`);
      throw error;
    }
  }
}

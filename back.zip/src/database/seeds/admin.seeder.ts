import { DataSource } from 'typeorm';
import { BaseSeeder } from './base.seeder';
import * as bcrypt from 'bcrypt';

/**
 * Seeds a default super admin user on first run.
 * This seeder is idempotent — it won't create duplicates.
 */
export class AdminSeeder extends BaseSeeder {
  constructor(private readonly dataSource: DataSource) {
    super('AdminSeeder');
  }

  async seed(): Promise<void> {
    const queryRunner = this.dataSource.createQueryRunner();

    try {
      // Check if super admin already exists
      const existing = await queryRunner.query(
        `SELECT id FROM users WHERE email = $1`,
        ['admin@enterprise-crm.com'],
      );

      if (existing.length > 0) {
        this.logger.log('Super admin user already exists, skipping');
        return;
      }

      // Get SUPER_ADMIN role
      const roles = await queryRunner.query(
        `SELECT id FROM roles WHERE name = $1`,
        ['SUPER_ADMIN'],
      );

      if (roles.length === 0) {
        this.logger.warn('SUPER_ADMIN role not found, skipping admin seed');
        return;
      }

      // Create admin user
      const hashedPassword = await bcrypt.hash('Admin@123456', 12);
      const result = await queryRunner.query(
        `INSERT INTO users (id, email, password, first_name, last_name, is_active, is_email_verified, auth_provider, created_at, updated_at)
         VALUES (gen_random_uuid(), $1, $2, $3, $4, true, true, 'local', NOW(), NOW())
         RETURNING id`,
        ['admin@enterprise-crm.com', hashedPassword, 'Super', 'Admin'],
      );

      const userId = result[0].id;

      // Assign SUPER_ADMIN role
      await queryRunner.query(
        `INSERT INTO user_roles (user_id, role_id) VALUES ($1, $2)`,
        [userId, roles[0].id],
      );

      this.logger.log(`Super admin user created: admin@enterprise-crm.com`);
    } finally {
      await queryRunner.release();
    }
  }
}

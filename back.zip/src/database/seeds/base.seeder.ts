import { Logger } from '@nestjs/common';

/**
 * Base seeder class that all seeders should extend.
 * Provides a consistent interface for running database seeds.
 */
export abstract class BaseSeeder {
  protected readonly logger: Logger;

  constructor(name: string) {
    this.logger = new Logger(name);
  }

  abstract seed(): Promise<void>;

  async run(): Promise<void> {
    const startTime = Date.now();
    this.logger.log('Starting seed...');

    try {
      await this.seed();
      const elapsed = Date.now() - startTime;
      this.logger.log(`Seed completed in ${elapsed}ms`);
    } catch (error) {
      this.logger.error(`Seed failed: ${(error as Error).message}`, (error as Error).stack);
      throw error;
    }
  }
}

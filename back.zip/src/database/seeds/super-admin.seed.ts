import { Injectable, Logger, OnApplicationBootstrap } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserEntity, AuthProvider } from '../../modules/users/entities/user.entity';
import { RoleEntity } from '../../modules/roles/entities/role.entity';
import { hashPassword } from '../../common/utils/crypto.util';

@Injectable()
export class SuperAdminSeeder implements OnApplicationBootstrap {
  private readonly logger = new Logger(SuperAdminSeeder.name);

  constructor(
    private readonly configService: ConfigService,
    @InjectRepository(UserEntity)
    private readonly userRepository: Repository<UserEntity>,
    @InjectRepository(RoleEntity)
    private readonly roleRepository: Repository<RoleEntity>,
  ) {}

  async onApplicationBootstrap() {
    // We check for both the .env credentials and the default ones provided by the user
    const credentials = [
      {
        email: this.configService.get<string>('SUPER_ADMIN_EMAIL'),
        password: this.configService.get<string>('SUPER_ADMIN_PASSWORD'),
      },
      {
        email: 'admin@enterprise-crm.com',
        password: 'Admin@123456',
      }
    ];

    for (const cred of credentials) {
      if (!cred.email || !cred.password) continue;

      await this.seedSuperAdmin(cred.email, cred.password);
    }
  }

  private async seedSuperAdmin(email: string, password: string) {
    try {
      const existing = await this.userRepository.findOne({ where: { email } });
      if (existing) {
        this.logger.debug(`Super admin ${email} already exists.`);
        return;
      }

      this.logger.log(`Seeding super admin: ${email}`);

      const superAdminRole = await this.roleRepository.findOne({ where: { name: 'SUPER_ADMIN' } });
      if (!superAdminRole) {
        this.logger.error('SUPER_ADMIN role not found. Ensure RolesModule has finished seeding.');
        return;
      }

      const hashedPassword = await hashPassword(password);
      const user = this.userRepository.create({
        email,
        password: hashedPassword,
        firstName: 'System',
        lastName: 'Administrator',
        isActive: true,
        isEmailVerified: true,
        authProvider: AuthProvider.LOCAL,
        roles: [superAdminRole],
      });

      await this.userRepository.save(user);
      this.logger.log(`Super admin ${email} created successfully.`);
    } catch (error) {
      this.logger.error(`Failed to seed super admin ${email}: ${(error as Error).message}`);
    }
  }
}

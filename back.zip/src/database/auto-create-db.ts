import { Client } from 'pg';
import * as dotenv from 'dotenv';
import { Logger } from '@nestjs/common';

dotenv.config();

export async function ensureDatabasesExist() {
  const logger = new Logger('DatabaseProvisioner');

  // Default postgres connection details to connect and create other databases
  const host = process.env.AUTH_DB_HOST || process.env.DB_HOST || 'localhost';
  const port = parseInt(process.env.AUTH_DB_PORT || process.env.DB_PORT || '5432', 10);
  const user = process.env.AUTH_DB_USER || process.env.DB_USER || 'postgres';
  const password = process.env.AUTH_DB_PASS || process.env.DB_PASS || 'postgres';

  const rawDatabases = [
    process.env.AUTH_DB_NAME || 'auth_db',
    process.env.SALES_DB_NAME || 'sales_db',
    process.env.HRMS_DB_NAME || 'hrms_db',
    process.env.PMS_DB_NAME || 'pms_db',
    process.env.FINANCE_DB_NAME || 'finance_db',
    process.env.READONLY_DB_NAME || 'auth_db',
  ];

  // Remove duplicates in case READONLY_DB_NAME is the same as AUTH_DB_NAME
  const databases = Array.from(new Set(rawDatabases));


  // Connect to the default 'postgres' database
  const client = new Client({
    host,
    port,
    user,
    password,
    database: 'postgres',
  });

  try {
    await client.connect();

    for (const dbName of databases) {
      if (!dbName) continue;

      const res = await client.query(`SELECT datname FROM pg_catalog.pg_database WHERE datname = $1`, [dbName]);

      if (res.rowCount === 0) {
        logger.log(`Database "${dbName}" does not exist. Creating...`);
        // We cannot use parameterized queries for CREATE DATABASE
        await client.query(`CREATE DATABASE "${dbName}"`);
        logger.log(`Database "${dbName}" created successfully.`);
      } else {
        logger.debug(`Database "${dbName}" already exists.`);
      }
    }
  } catch (err) {
    logger.error('Error ensuring databases exist', err);
    throw err;
  } finally {
    await client.end();
  }
}

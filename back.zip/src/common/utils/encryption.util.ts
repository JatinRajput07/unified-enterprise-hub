import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';

@Injectable()
export class EncryptionUtil {
  private readonly algorithm = 'aes-256-cbc';
  private readonly key: Buffer;
  private readonly iv: Buffer;

  constructor(private readonly configService: ConfigService) {
    const encKey = this.configService.get<string>('ENCRYPTION_KEY');
    const encIv = this.configService.get<string>('ENCRYPTION_IV');

    if (!encKey || !encIv) {
      throw new Error('ENCRYPTION_KEY and ENCRYPTION_IV must be set in environment');
    }

    this.key = Buffer.from(encKey, 'hex');
    this.iv = Buffer.from(encIv, 'hex');
  }

  /**
   * Encrypt plaintext using AES-256-CBC.
   */
  encrypt(plaintext: string): string {
    const cipher = crypto.createCipheriv(this.algorithm, this.key, this.iv);
    let encrypted = cipher.update(plaintext, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
  }

  /**
   * Decrypt AES-256-CBC encrypted text.
   */
  decrypt(encryptedText: string): string {
    const decipher = crypto.createDecipheriv(this.algorithm, this.key, this.iv);
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  }

  /**
   * SHA-256 hash (for fast token lookups — NOT for passwords).
   */
  hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  /**
   * Generate a cryptographically secure random token.
   */
  generateSecureToken(bytes = 40): string {
    return crypto.randomBytes(bytes).toString('hex');
  }

  /**
   * Generate a numeric OTP of the specified length.
   */
  generateOtp(length = 6): string {
    const max = Math.pow(10, length);
    const otp = crypto.randomInt(0, max);
    return otp.toString().padStart(length, '0');
  }
}

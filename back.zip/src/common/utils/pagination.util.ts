import { ObjectLiteral, SelectQueryBuilder } from 'typeorm';
import {
  OffsetPaginationDto,
  CursorPaginationDto,
} from '../dto/pagination.dto';
import { PaginatedResponseDto, CursorPaginatedResponseDto } from '../dto/response.dto';

/**
 * Apply offset-based pagination to a TypeORM query builder.
 */
export async function paginateOffset<T extends ObjectLiteral>(
  queryBuilder: SelectQueryBuilder<T>,
  dto: OffsetPaginationDto,
  allowedSortFields: string[] = ['createdAt', 'updatedAt'],
): Promise<PaginatedResponseDto<T>> {
  // Validate sort field
  const alias = queryBuilder.alias;
  const sortField =
    dto.sortBy && allowedSortFields.includes(dto.sortBy)
      ? dto.sortBy
      : 'createdAt';

  queryBuilder
    .orderBy(`${alias}.${sortField}`, dto.sortOrder)
    .skip(dto.skip)
    .take(dto.limit);

  const [data, total] = await queryBuilder.getManyAndCount();

  return PaginatedResponseDto.create(data, total, dto.page, dto.limit);
}

/**
 * Apply cursor-based pagination to a TypeORM query builder.
 */
export async function paginateCursor<T extends ObjectLiteral>(
  queryBuilder: SelectQueryBuilder<T>,
  dto: CursorPaginationDto,
  cursorField: string = 'id',
): Promise<CursorPaginatedResponseDto<T>> {
  const alias = queryBuilder.alias;

  if (dto.cursor) {
    const operator = dto.sortOrder === 'ASC' ? '>' : '<';
    queryBuilder.andWhere(`${alias}.${cursorField} ${operator} :cursor`, {
      cursor: dto.cursor,
    });
  }

  queryBuilder
    .orderBy(`${alias}.${cursorField}`, dto.sortOrder)
    .take(dto.limit + 1);

  const results = await queryBuilder.getMany();
  const hasMore = results.length > dto.limit;

  if (hasMore) {
    results.pop();
  }

  const nextCursor = hasMore
    ? (results[results.length - 1] as Record<string, unknown>)[cursorField] as string
    : undefined;

  return CursorPaginatedResponseDto.create(results, dto.limit, nextCursor);
}

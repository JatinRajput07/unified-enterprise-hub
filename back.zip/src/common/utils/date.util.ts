/**
 * Parse a duration string (e.g., '15m', '7d', '1h') to milliseconds.
 */
export function parseDuration(duration: string): number {
  const units: Record<string, number> = {
    s: 1000,
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
  };

  const match = duration.match(/^(\d+)([smhdw])$/);
  if (!match) {
    throw new Error(`Invalid duration format: ${duration}`);
  }

  const value = parseInt(match[1], 10);
  const unit = match[2];

  return value * (units[unit] || 1000);
}

/**
 * Format a date to ISO string without milliseconds.
 */
export function formatDate(date: Date): string {
  return date.toISOString().replace(/\.\d{3}Z$/, 'Z');
}

/**
 * Check if a date is expired.
 */
export function isExpired(date: Date): boolean {
  return new Date() > date;
}

/**
 * Get a date that is `duration` in the future.
 */
export function dateFromNow(durationMs: number): Date {
  return new Date(Date.now() + durationMs);
}

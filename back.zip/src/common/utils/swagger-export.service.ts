import { Injectable, OnApplicationBootstrap, Logger } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import * as fs from 'fs';
import * as path from 'path';

@Injectable()
export class SwaggerExplorerService implements OnApplicationBootstrap {
  private readonly logger = new Logger(SwaggerExplorerService.name);

  async onApplicationBootstrap() {
    if (process.env.APP_ENV === 'production') return;

    try {
      // This is a bit tricky to run within the app itself for the current app instance
      // But we can generate it and save to a file
      this.logger.log('Exporting swagger.json for CI/CD...');
      
      // In a real implementation, we'd use the document generated in main.ts
      // For now, this is a placeholder to show the logic is here
      // The actual export often happens via a standalone script or a specific endpoint
    } catch (error) {
      this.logger.error(`Failed to export swagger: ${(error as Error).message}`);
    }
  }
}

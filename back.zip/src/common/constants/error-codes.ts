export enum ErrorCode {
  // Auth & Permissions
  AUTH_INVALID_TOKEN = 'AUTH_001',
  AUTH_EXPIRED_TOKEN = 'AUTH_002',
  AUTH_INSUFFICIENT_PERMISSIONS = 'AUTH_003',
  AUTH_ACCOUNT_LOCKED = 'AUTH_004',

  // Database & Resources
  DB_NOT_FOUND = 'DB_001',
  DB_DUPLICATE_ENTRY = 'DB_002',
  DB_CONSTRAINT_VIOLATION = 'DB_003',
  DB_QUERY_FAILED = 'DB_004',

  // AI & Automation
  AI_QUOTA_EXCEEDED = 'AI_001',
  AI_PROVIDER_ERROR = 'AI_002',
  AI_INVALID_PROMPT = 'AI_003',

  // Billing
  BILLING_NO_SUBSCRIPTION = 'BILL_001',
  BILLING_PAYMENT_FAILED = 'BILL_002',

  // System
  SYS_INTERNAL_ERROR = 'SYS_001',
  SYS_TIMEOUT = 'SYS_002',
  SYS_UNAVAILABLE = 'SYS_003',
}

export interface ErrorResponse {
  success: false;
  errorCode: ErrorCode;
  message: string;
  details?: any;
  requestId: string;
  timestamp: string;
}

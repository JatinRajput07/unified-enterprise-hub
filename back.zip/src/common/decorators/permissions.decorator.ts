import { SetMetadata } from '@nestjs/common';

export const PERMISSIONS_KEY = 'permissions';

/**
 * Decorator to restrict access based on fine-grained permissions.
 * Permission format: "resource:action"
 * Usage: @Permissions('users:read', 'users:update')
 */
export const Permissions = (...permissions: string[]) =>
  SetMetadata(PERMISSIONS_KEY, permissions);

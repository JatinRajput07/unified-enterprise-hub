import { applyDecorators, SetMetadata } from '@nestjs/common';

export const PUBLIC_KEY = 'isPublic';

/**
 * Marks a route as public (no authentication required).
 * Bypasses JWT guard when applied.
 */
export const Public = () => applyDecorators(SetMetadata(PUBLIC_KEY, true));

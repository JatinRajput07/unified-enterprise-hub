import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { Request } from 'express';

/**
 * Custom decorator to access the current tenant context in controllers.
 * Usage: @Tenant() tenant: TenantEntity
 * Usage: @Tenant('id') tenantId: string
 */
export const Tenant = createParamDecorator(
  (data: string | undefined, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest<Request>();
    const tenant = (request as unknown as Record<string, unknown>)['tenant'];
    return data ? (tenant as Record<string, unknown>)?.[data] : tenant;
  },
);

import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  Logger,
} from '@nestjs/common';
import { Observable, tap } from 'rxjs';
import { Request, Response } from 'express';

/**
 * Logs every incoming request and its response with timing information.
 */
@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger('HTTP');

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = context.switchToHttp().getRequest<Request>();
    const response = context.switchToHttp().getResponse<Response>();
    const { method, url, ip } = request;
    const userAgent = request.get('user-agent') || '';
    const requestId = request.headers['x-request-id'] as string;
    const startTime = Date.now();

    return next.handle().pipe(
      tap({
        next: () => {
          const elapsed = Date.now() - startTime;
          const { statusCode } = response;
          this.logger.log(
            `${method} ${url} ${statusCode} ${elapsed}ms - ${ip} - ${userAgent} [${requestId || 'no-request-id'}]`,
          );
        },
        error: (error: Error) => {
          const elapsed = Date.now() - startTime;
          this.logger.error(
            `${method} ${url} ERROR ${elapsed}ms - ${ip} - ${error.message} [${requestId || 'no-request-id'}]`,
          );
        },
      }),
    );
  }
}

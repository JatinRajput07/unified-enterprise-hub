import { PipeTransform, Injectable, BadRequestException } from '@nestjs/common';
import { validate as uuidValidate, version as uuidVersion } from 'uuid';

/**
 * Custom UUID validation pipe.
 * Validates that the parameter is a valid UUID v4.
 */
@Injectable()
export class ParseUUIDv4Pipe implements PipeTransform<string, string> {
  transform(value: string): string {
    if (!uuidValidate(value) || uuidVersion(value) !== 4) {
      throw new BadRequestException(`Invalid UUID v4: ${value}`);
    }
    return value;
  }
}

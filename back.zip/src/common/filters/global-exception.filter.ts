import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { ErrorCode, ErrorResponse } from '../constants/error-codes';

@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(GlobalExceptionFilter.name);

  catch(exception: any, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'Internal server error';
    let errorCode = ErrorCode.SYS_INTERNAL_ERROR;
    let details = null;

    if (exception instanceof HttpException) {
      status = exception.getStatus();
      const exceptionResponse = exception.getResponse() as any;
      message = exceptionResponse.message || exception.message;
      details = exceptionResponse.details || null;

      // Map HTTP status to ErrorCode if not explicitly provided
      errorCode = this.mapStatusToErrorCode(status);
    } else {
      this.logger.error(`Unhandled Exception: ${exception.message}`, exception.stack);
    }

    const errorResponse: ErrorResponse = {
      success: false,
      errorCode,
      message,
      details,
      requestId: (request as any).id || 'unknown',
      timestamp: new Date().toISOString(),
    };

    response.status(status).json(errorResponse);
  }

  private mapStatusToErrorCode(status: number): ErrorCode {
    switch (status) {
      case HttpStatus.UNAUTHORIZED: return ErrorCode.AUTH_INVALID_TOKEN;
      case HttpStatus.FORBIDDEN: return ErrorCode.AUTH_INSUFFICIENT_PERMISSIONS;
      case HttpStatus.NOT_FOUND: return ErrorCode.DB_NOT_FOUND;
      case HttpStatus.CONFLICT: return ErrorCode.DB_DUPLICATE_ENTRY;
      case HttpStatus.TOO_MANY_REQUESTS: return ErrorCode.AI_QUOTA_EXCEEDED; // Overload
      default: return ErrorCode.SYS_INTERNAL_ERROR;
    }
  }
}

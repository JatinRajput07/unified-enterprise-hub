import { SetMetadata } from '@nestjs/common';

export interface CacheOptions {
  key: string | ((args: any[]) => string);
  ttl?: number;
  tenantScoped?: boolean;
}

export const CACHE_METADATA_KEY = 'cacheable';
export const CACHE_EVICT_METADATA_KEY = 'cache_evict';

/**
 * Decorator to cache method results.
 */
export const Cacheable = (options: CacheOptions) =>
  SetMetadata(CACHE_METADATA_KEY, options);

/**
 * Decorator to evict cache on method execution (e.g. after update/delete).
 */
export const CacheEvict = (options: Omit<CacheOptions, 'ttl'>) =>
  SetMetadata(CACHE_EVICT_METADATA_KEY, options);

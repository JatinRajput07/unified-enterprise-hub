import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

@Injectable()
export class CacheService implements OnModuleInit {
  private readonly logger = new Logger(CacheService.name);
  private redis!: Redis;
  private readonly DEFAULT_TTL = 3600; // 1 hour

  constructor(private readonly configService: ConfigService) {}

  onModuleInit(): void {
    const redisUrl = this.configService.get<string>('REDIS_URL') || 'redis://localhost:6379';
    this.redis = new Redis(redisUrl, {
      maxRetriesPerRequest: null,
      retryStrategy: (times: number) => Math.min(times * 50, 2000),
    });

    this.redis.on('connect', () => this.logger.log('Redis Cache connected'));
    this.redis.on('error', (err) => this.logger.error(`Redis Error: ${err.message}`));
  }

  /**
   * Get a typed value from cache.
   */
  async get<T>(key: string): Promise<T | null> {
    try {
      const value = await this.redis.get(key);
      if (!value) return null;
      return JSON.parse(value) as T;
    } catch (error) {
      this.logger.warn(`Cache get failed for key ${key}: ${(error as Error).message}`);
      return null;
    }
  }

  /**
   * Set a value in cache with optional TTL.
   */
  async set(key: string, value: unknown, ttl?: number): Promise<void> {
    try {
      const serialized = JSON.stringify(value);
      if (ttl) {
        await this.redis.setex(key, ttl, serialized);
      } else {
        await this.redis.set(key, serialized);
      }
    } catch (error) {
      this.logger.warn(`Cache set failed for key ${key}: ${(error as Error).message}`);
    }
  }

  /**
   * Delete one or more keys.
   */
  async del(key: string | string[]): Promise<void> {
    try {
      if (Array.isArray(key)) {
        if (key.length > 0) await this.redis.del(...key);
      } else {
        await this.redis.del(key);
      }
    } catch (error) {
      this.logger.warn(`Cache del failed: ${(error as Error).message}`);
    }
  }

  /**
   * Stale-while-revalidate pattern.
   * Gets value from cache, if missing, calls factory, caches it, and returns.
   */
  async getOrSet<T>(
    key: string,
    factory: () => Promise<T>,
    ttl: number = this.DEFAULT_TTL,
  ): Promise<T> {
    const cached = await this.get<T>(key);
    if (cached !== null) return cached;

    const value = await factory();
    await this.set(key, value, ttl);
    return value;
  }

  /**
   * Invalidate keys by pattern using SCAN (safer than KEYS).
   */
  async invalidateByPattern(pattern: string): Promise<void> {
    try {
      let cursor = '0';
      do {
        const [nextCursor, keys] = await this.redis.scan(
          cursor,
          'MATCH',
          pattern,
          'COUNT',
          100,
        );
        cursor = nextCursor;
        if (keys.length > 0) {
          await this.redis.del(...keys);
        }
      } while (cursor !== '0');
      this.logger.debug(`Invalidated cache pattern: ${pattern}`);
    } catch (error) {
      this.logger.warn(`Cache invalidateByPattern failed: ${(error as Error).message}`);
    }
  }

  /**
   * Get internal Redis client for advanced operations.
   */
  getClient(): Redis {
    return this.redis;
  }
}

import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  Logger,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { CacheService } from './cache.service';
import {
  CACHE_METADATA_KEY,
  CACHE_EVICT_METADATA_KEY,
  CacheOptions,
} from './decorators/cacheable.decorator';

@Injectable()
export class CacheInterceptor implements NestInterceptor {
  private readonly logger = new Logger(CacheInterceptor.name);

  constructor(
    private readonly reflector: Reflector,
    private readonly cacheService: CacheService,
  ) {}

  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<any>> {
    const cacheOptions = this.reflector.get<CacheOptions>(
      CACHE_METADATA_KEY,
      context.getHandler(),
    );

    const evictOptions = this.reflector.get<CacheOptions>(
      CACHE_EVICT_METADATA_KEY,
      context.getHandler(),
    );

    // Handle eviction first (if any)
    if (evictOptions) {
      return next.handle().pipe(
        tap(async () => {
          const key = this.generateKey(evictOptions, context);
          await this.cacheService.del(key);
          this.logger.debug(`Evicted cache key: ${key}`);
        }),
      );
    }

    // Handle caching
    if (!cacheOptions) {
      return next.handle();
    }

    const key = this.generateKey(cacheOptions, context);
    const cachedData = await this.cacheService.get(key);

    if (cachedData !== null) {
      this.logger.debug(`Cache hit: ${key}`);
      return of(cachedData);
    }

    return next.handle().pipe(
      tap(async (data) => {
        if (data !== undefined) {
          await this.cacheService.set(key, data, cacheOptions.ttl);
          this.logger.debug(`Cached result for key: ${key}`);
        }
      }),
    );
  }

  private generateKey(options: CacheOptions, context: ExecutionContext): string {
    const request = context.switchToHttp().getRequest();
    const args = request.params || {}; // This is a simplification
    
    let key = '';
    if (typeof options.key === 'function') {
      // In a real implementation, we'd extract actual method arguments
      // Here we approximate with request parameters
      key = options.key([args, request.query]);
    } else {
      key = options.key;
    }

    // Tenant isolation
    if (options.tenantScoped && request.tenantId) {
      key = `tenant:${request.tenantId}:${key}`;
    }

    return key;
  }
}

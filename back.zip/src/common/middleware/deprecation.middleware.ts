import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class DeprecationMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    // Check if the request is for v1
    if (req.url.includes('/v1/')) {
      // Add Deprecation header if it's considered deprecated
      // In a real app, this would be conditional based on a config or route map
      res.setHeader('Deprecation', 'true');
      res.setHeader('Link', `<${req.url.replace('/v1/', '/v2/')}>; rel="alternate"`);
    }
    next();
  }
}

import { Injectable, ExecutionContext, HttpException, HttpStatus } from '@nestjs/common';
import { ThrottlerGuard, ThrottlerException } from '@nestjs/throttler';

@Injectable()
export class EnhancedThrottlerGuard extends ThrottlerGuard {
  protected async throwThrottlingException(
    context: ExecutionContext,
    throttlerLimitDetail: any,
  ): Promise<void> {
    const response = context.switchToHttp().getResponse();
    
    // Add Retry-After header in seconds
    const retryAfter = Math.ceil((throttlerLimitDetail.timeToBlock || 0) / 1000);
    response.header('Retry-After', retryAfter.toString());

    throw new HttpException(
      {
        statusCode: HttpStatus.TOO_MANY_REQUESTS,
        message: 'Too many requests. Please slow down.',
        error: 'Too Many Requests',
        retryAfter,
      },
      HttpStatus.TOO_MANY_REQUESTS,
    );
  }

  protected async getTracker(req: Record<string, any>): Promise<string> {
    // Skip throttling for internal service requests
    const internalKey = req.headers['x-internal-key'];
    if (internalKey && internalKey === process.env.INTERNAL_SERVICE_KEY) {
      return 'internal';
    }

    // Per-user limits if authenticated, otherwise fallback to IP
    if (req.user && req.user.id) {
      return `user:${req.user.id}`;
    }

    return req.ip;
  }
}

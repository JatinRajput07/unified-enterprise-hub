import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PERMISSIONS_KEY } from '../decorators/permissions.decorator';

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredPermissions = this.reflector.getAllAndOverride<string[]>(
      PERMISSIONS_KEY,
      [context.getHandler(), context.getClass()],
    );

    if (!requiredPermissions || requiredPermissions.length === 0) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;
    if (!user) {
      throw new ForbiddenException('Access denied: User not authenticated');
    }

    // SUPER_ADMIN bypasses all permission checks
    if (user.roles && user.roles.includes('SUPER_ADMIN')) {
      return true;
    }

    if (!user.permissions) {
      throw new ForbiddenException('Access denied: No permissions assigned');
    }

    const userPermissions: string[] = user.permissions;

    // Check wildcard permission (e.g., 'users:*' or '*:*')
    const hasPermission = requiredPermissions.every((required) => {
      const [requiredResource, requiredAction] = required.split(':');

      return userPermissions.some((userPerm) => {
        const [userResource, userAction] = userPerm.split(':');

        // Wildcard: '*:*' grants all permissions
        if (userResource === '*' && userAction === '*') return true;

        // Resource wildcard: 'users:*' grants all actions on users
        if (userResource === requiredResource && userAction === '*') return true;

        // Exact match
        return userPerm === required;
      });
    });

    if (!hasPermission) {
      throw new ForbiddenException(
        `Access denied: Required permissions [${requiredPermissions.join(', ')}]`,
      );
    }

    return true;
  }
}

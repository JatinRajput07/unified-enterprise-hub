import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

/**
 * Validates that the current tenant exists and is active.
 * This guard should be applied to routes that require tenant context.
 */
@Injectable()
export class TenantGuard implements CanActivate {
  private readonly logger = new Logger(TenantGuard.name);

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const tenant = request.tenant;

    if (!tenant) {
      this.logger.warn('Access attempt without tenant context');
      throw new ForbiddenException('Tenant context is required');
    }

    if (!tenant.isActive) {
      this.logger.warn(`Access attempt to inactive tenant: ${tenant.id}`);
      throw new ForbiddenException('Tenant is inactive');
    }

    return true;
  }
}

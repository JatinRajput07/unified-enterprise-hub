import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { SortOrder } from './pagination.dto';

/**
 * SortDto with allowedFields whitelist to prevent SQL injection via sort param.
 * Extend this class and override allowedFields in subclasses.
 */
export class SortDto {
  @ApiPropertyOptional({ description: 'Field to sort by', example: 'createdAt' })
  @IsOptional()
  @IsString()
  sortBy?: string;

  @ApiPropertyOptional({ description: 'Sort order', enum: SortOrder, example: SortOrder.DESC })
  @IsOptional()
  @IsEnum(SortOrder)
  sortOrder: SortOrder = SortOrder.DESC;

  /** Override in subclasses to restrict sortable fields */
  protected get allowedFields(): string[] {
    return ['createdAt', 'updatedAt'];
  }

  /**
   * Returns the validated sort field. Defaults to 'createdAt' if the 
   * requested field is not in the allowlist.
   */
  getSafeSort(): { field: string; order: SortOrder } {
    const field = this.sortBy && this.allowedFields.includes(this.sortBy)
      ? this.sortBy
      : 'createdAt';
    return { field, order: this.sortOrder };
  }
}

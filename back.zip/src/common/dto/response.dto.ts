import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class PaginationMeta {
  @ApiProperty({ example: 100 })
  total!: number;

  @ApiProperty({ example: 1 })
  page!: number;

  @ApiProperty({ example: 20 })
  limit!: number;

  @ApiProperty({ example: 5 })
  totalPages!: number;

  @ApiProperty({ example: true })
  hasNextPage!: boolean;

  @ApiProperty({ example: false })
  hasPreviousPage!: boolean;
}

export class CursorPaginationMeta {
  @ApiProperty({ example: 20 })
  limit!: number;

  @ApiPropertyOptional({ example: 'uuid-string' })
  nextCursor?: string;

  @ApiProperty({ example: true })
  hasMore!: boolean;
}

export class BaseResponseDto<T> {
  @ApiProperty({ example: true })
  success!: boolean;

  @ApiPropertyOptional()
  data?: T;

  @ApiPropertyOptional()
  message?: string;

  @ApiPropertyOptional()
  meta?: PaginationMeta | CursorPaginationMeta;

  static ok<T>(data: T, meta?: PaginationMeta | CursorPaginationMeta): BaseResponseDto<T> {
    const response = new BaseResponseDto<T>();
    response.success = true;
    response.data = data;
    if (meta) {
      response.meta = meta;
    }
    return response;
  }

  static error(message: string): BaseResponseDto<null> {
    const response = new BaseResponseDto<null>();
    response.success = false;
    response.message = message;
    return response;
  }
}

export class PaginatedResponseDto<T> {
  @ApiProperty({ example: true })
  success!: boolean;

  data!: T[];

  @ApiProperty({ type: PaginationMeta })
  meta!: PaginationMeta;

  static create<T>(
    data: T[],
    total: number,
    page: number,
    limit: number,
  ): PaginatedResponseDto<T> {
    const totalPages = Math.ceil(total / limit);
    const response = new PaginatedResponseDto<T>();
    response.success = true;
    response.data = data;
    response.meta = {
      total,
      page,
      limit,
      totalPages,
      hasNextPage: page < totalPages,
      hasPreviousPage: page > 1,
    };
    return response;
  }
}

export class CursorPaginatedResponseDto<T> {
  @ApiProperty({ example: true })
  success!: boolean;

  data!: T[];

  @ApiProperty({ type: CursorPaginationMeta })
  meta!: CursorPaginationMeta;

  static create<T>(
    data: T[],
    limit: number,
    nextCursor?: string,
  ): CursorPaginatedResponseDto<T> {
    const response = new CursorPaginatedResponseDto<T>();
    response.success = true;
    response.data = data;
    response.meta = {
      limit,
      nextCursor,
      hasMore: !!nextCursor,
    };
    return response;
  }
}

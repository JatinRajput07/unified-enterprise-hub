import * as winston from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import { WinstonModule, utilities as nestWinstonModuleUtilities } from 'nest-winston';

/**
 * Sensitive fields to mask in logs to prevent data leaks.
 */
const SENSITIVE_FIELDS = ['password', 'token', 'secret', 'authorization', 'cookie', 'cardNumber', 'cvv'];

/**
 * Winston format that masks sensitive fields in log messages.
 */
const maskSensitiveData = winston.format((info) => {
  if (typeof info.message === 'string') {
    SENSITIVE_FIELDS.forEach((field) => {
      const regex = new RegExp(`("${field}"\\s*:\\s*)"[^"]*"`, 'gi');
      info.message = (info.message as string).replace(regex, `$1"[REDACTED]"`);
    });
  }
  return info;
});

/**
 * Create Winston logger instance for NestJS.
 */
export function createWinstonLogger(env: string, logDir: string, logLevel: string) {
  const isProduction = env === 'production';

  const transports: winston.transport[] = [
    // Console transport
    new winston.transports.Console({
      format: isProduction
        ? winston.format.combine(
            winston.format.timestamp(),
            maskSensitiveData(),
            winston.format.json(),
          )
        : winston.format.combine(
            winston.format.timestamp(),
            maskSensitiveData(),
            nestWinstonModuleUtilities.format.nestLike('EnterpriseCRM', {
              prettyPrint: true,
              colors: true,
            }),
          ),
    }),
  ];

  // File transports (all environments except test)
  if (env !== 'test') {
    // All logs daily rotation
    transports.push(
      new DailyRotateFile({
        dirname: logDir,
        filename: 'app-%DATE%.log',
        datePattern: 'YYYY-MM-DD',
        maxSize: '20m',
        maxFiles: '14d',
        format: winston.format.combine(
          winston.format.timestamp(),
          maskSensitiveData(),
          winston.format.json(),
        ),
      }),
    );

    // Error logs daily rotation
    transports.push(
      new DailyRotateFile({
        dirname: logDir,
        filename: 'error-%DATE%.log',
        datePattern: 'YYYY-MM-DD',
        maxSize: '20m',
        maxFiles: '30d',
        level: 'error',
        format: winston.format.combine(
          winston.format.timestamp(),
          maskSensitiveData(),
          winston.format.json(),
        ),
      }),
    );
  }

  return WinstonModule.createLogger({
    level: isProduction ? 'warn' : logLevel,
    transports,
  });
}

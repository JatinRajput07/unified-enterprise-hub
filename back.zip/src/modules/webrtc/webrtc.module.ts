import { Module } from '@nestjs/common';
import { WebRtcGateway } from './webrtc.gateway';
import { WebRtcController } from './webrtc.controller';
import { RoomService } from './room.service';

@Module({
  controllers: [WebRtcController],
  providers: [WebRtcGateway, RoomService],
  exports: [RoomService],
})
export class WebRtcModule {}

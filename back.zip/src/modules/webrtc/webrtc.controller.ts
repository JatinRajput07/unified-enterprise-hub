import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';

@ApiTags('WebRTC')
@ApiBearerAuth()
@Controller({ path: 'webrtc', version: '1' })
export class WebRtcController {
  constructor(private readonly configService: ConfigService) {}

  @Get('ice-config')
  @ApiOperation({ summary: 'Get STUN/TURN server configuration for WebRTC' })
  getIceConfig(): { iceServers: Array<Record<string, unknown>> } {
    return {
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
        // TURN servers from env (if configured)
        ...(this.configService.get<string>('TURN_URL')
          ? [
              {
                urls: this.configService.get<string>('TURN_URL'),
                username: this.configService.get<string>('TURN_USERNAME'),
                credential: this.configService.get<string>('TURN_CREDENTIAL'),
              },
            ]
          : []),
      ],
    };
  }
}

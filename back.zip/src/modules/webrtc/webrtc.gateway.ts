import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Logger } from '@nestjs/common';
import { Server, Socket } from 'socket.io';
import { RoomService } from './room.service';
import { SocketEvents } from '../gateway/events.enum';
import { SocketUserData } from '../gateway/dto/socket-event.dto';

@WebSocketGateway({
  cors: { origin: '*', credentials: true },
  namespace: '/webrtc',
})
export class WebRtcGateway {
  @WebSocketServer()
  server!: Server;

  private readonly logger = new Logger(WebRtcGateway.name);

  constructor(private readonly roomService: RoomService) {}

  @SubscribeMessage(SocketEvents.WEBRTC_ROOM_JOIN)
  async handleJoinRoom(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { roomId: string; maxParticipants?: number },
  ): Promise<void> {
    const user = client.data.user as SocketUserData;
    if (!user) return;

    const room = await this.roomService.joinRoom(data.roomId, user.id);

    if (!room) {
      client.emit(SocketEvents.WEBRTC_ROOM_FULL, { roomId: data.roomId });
      return;
    }

    await client.join(`webrtc:${data.roomId}`);

    // Notify others in the room
    client.to(`webrtc:${data.roomId}`).emit(SocketEvents.WEBRTC_PEER_JOINED, {
      userId: user.id,
      roomId: data.roomId,
      participants: room.participants,
    });

    // Send room info back to the joiner
    client.emit(SocketEvents.WEBRTC_ROOM_JOIN, {
      roomId: data.roomId,
      participants: room.participants,
    });

    this.logger.log(`User ${user.id} joined WebRTC room ${data.roomId}`);
  }

  @SubscribeMessage(SocketEvents.WEBRTC_ROOM_LEAVE)
  async handleLeaveRoom(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { roomId: string },
  ): Promise<void> {
    const user = client.data.user as SocketUserData;
    if (!user) return;

    await this.roomService.leaveRoom(data.roomId, user.id);
    await client.leave(`webrtc:${data.roomId}`);

    // Notify others
    client.to(`webrtc:${data.roomId}`).emit(SocketEvents.WEBRTC_PEER_LEFT, {
      userId: user.id,
      roomId: data.roomId,
    });

    this.logger.log(`User ${user.id} left WebRTC room ${data.roomId}`);
  }

  @SubscribeMessage(SocketEvents.WEBRTC_OFFER)
  handleOffer(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { targetUserId: string; offer: unknown; roomId: string },
  ): void {
    const user = client.data.user as SocketUserData;
    if (!user) return;

    client.to(`webrtc:${data.roomId}`).emit(SocketEvents.WEBRTC_OFFER, {
      senderId: user.id,
      offer: data.offer,
      roomId: data.roomId,
    });
  }

  @SubscribeMessage(SocketEvents.WEBRTC_ANSWER)
  handleAnswer(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { targetUserId: string; answer: unknown; roomId: string },
  ): void {
    const user = client.data.user as SocketUserData;
    if (!user) return;

    client.to(`webrtc:${data.roomId}`).emit(SocketEvents.WEBRTC_ANSWER, {
      senderId: user.id,
      answer: data.answer,
      roomId: data.roomId,
    });
  }

  @SubscribeMessage(SocketEvents.WEBRTC_ICE_CANDIDATE)
  handleIceCandidate(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { targetUserId: string; candidate: unknown; roomId: string },
  ): void {
    const user = client.data.user as SocketUserData;
    if (!user) return;

    client.to(`webrtc:${data.roomId}`).emit(SocketEvents.WEBRTC_ICE_CANDIDATE, {
      senderId: user.id,
      candidate: data.candidate,
      roomId: data.roomId,
    });
  }
}

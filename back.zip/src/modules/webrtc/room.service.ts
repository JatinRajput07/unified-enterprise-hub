import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

export interface WebRtcRoom {
  id: string;
  participants: string[];
  createdAt: string;
  maxParticipants: number;
}

@Injectable()
export class RoomService {
  private readonly logger = new Logger(RoomService.name);
  private readonly redis: Redis;
  private readonly ROOM_TTL = 3600; // 1 hour

  constructor(private readonly configService: ConfigService) {
    this.redis = new Redis(
      this.configService.get<string>('REDIS_URL') || 'redis://localhost:6379',
    );
  }

  async createRoom(roomId: string, maxParticipants: number = 10): Promise<WebRtcRoom> {
    const room: WebRtcRoom = {
      id: roomId,
      participants: [],
      createdAt: new Date().toISOString(),
      maxParticipants,
    };

    await this.redis.setex(
      this.roomKey(roomId),
      this.ROOM_TTL,
      JSON.stringify(room),
    );

    this.logger.log(`WebRTC room created: ${roomId}`);
    return room;
  }

  async getRoom(roomId: string): Promise<WebRtcRoom | null> {
    const data = await this.redis.get(this.roomKey(roomId));
    if (!data) return null;
    return JSON.parse(data) as WebRtcRoom;
  }

  async joinRoom(roomId: string, userId: string): Promise<WebRtcRoom | null> {
    let room = await this.getRoom(roomId);

    if (!room) {
      room = await this.createRoom(roomId);
    }

    if (room.participants.length >= room.maxParticipants) {
      this.logger.warn(`Room ${roomId} is full`);
      return null;
    }

    if (!room.participants.includes(userId)) {
      room.participants.push(userId);
      await this.redis.setex(
        this.roomKey(roomId),
        this.ROOM_TTL,
        JSON.stringify(room),
      );
    }

    this.logger.debug(`User ${userId} joined room ${roomId}`);
    return room;
  }

  async leaveRoom(roomId: string, userId: string): Promise<WebRtcRoom | null> {
    const room = await this.getRoom(roomId);
    if (!room) return null;

    room.participants = room.participants.filter((p) => p !== userId);

    if (room.participants.length === 0) {
      // Room is empty — clean up
      await this.redis.del(this.roomKey(roomId));
      this.logger.log(`Room ${roomId} deleted (empty)`);
      return null;
    }

    await this.redis.setex(
      this.roomKey(roomId),
      this.ROOM_TTL,
      JSON.stringify(room),
    );

    this.logger.debug(`User ${userId} left room ${roomId}`);
    return room;
  }

  async deleteRoom(roomId: string): Promise<void> {
    await this.redis.del(this.roomKey(roomId));
    this.logger.log(`Room ${roomId} deleted`);
  }

  private roomKey(roomId: string): string {
    return `webrtc:room:${roomId}`;
  }

  async onModuleDestroy(): Promise<void> {
    await this.redis.quit();
  }
}

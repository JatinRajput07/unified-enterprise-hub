export const UserIndexMapping = {
  id: { type: 'keyword' },
  email: { type: 'text', analyzer: 'standard' },
  firstName: { type: 'text', analyzer: 'standard' },
  lastName: { type: 'text', analyzer: 'standard' },
  fullName: { type: 'text', analyzer: 'standard' },
  role: { type: 'keyword' },
  tenantId: { type: 'keyword' },
  isActive: { type: 'boolean' },
  createdAt: { type: 'date' },
  updatedAt: { type: 'date' },
};

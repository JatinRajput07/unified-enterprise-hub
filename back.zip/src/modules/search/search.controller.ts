import { Controller, Get, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { SearchService, SearchResult } from './search.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('Search')
@ApiBearerAuth()
@Controller({ path: 'search', version: '1' })
export class SearchController {
  constructor(private readonly searchService: SearchService) {}

  @Get()
  @ApiOperation({ summary: 'Global search across all entities' })
  @ApiQuery({ name: 'q', required: true, description: 'Search query' })
  @ApiQuery({ name: 'index', required: false, description: 'Index to search (e.g., users, contacts, leads)' })
  @ApiQuery({ name: 'page', required: false, description: 'Page number', type: Number })
  @ApiQuery({ name: 'limit', required: false, description: 'Results per page', type: Number })
  async search(
    @Query('q') query: string,
    @Query('index') index: string = 'crm_global',
    @Query('page') page: number = 1,
    @Query('limit') limit: number = 20,
    @CurrentUser('tenantId') tenantId?: string,
  ): Promise<SearchResult> {
    return this.searchService.search({
      index,
      query,
      from: (page - 1) * limit,
      size: limit,
      highlight: true,
      tenantId,
    });
  }
}

import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Client } from '@elastic/elasticsearch';

export interface SearchOptions {
  index: string;
  query: string;
  fields?: string[];
  from?: number;
  size?: number;
  filters?: Record<string, unknown>;
  sort?: Array<Record<string, 'asc' | 'desc'>>;
  highlight?: boolean;
  tenantId?: string;
}

export interface SearchResult<T = Record<string, unknown>> {
  hits: Array<{
    id: string;
    score: number;
    source: T;
    highlight?: Record<string, string[]>;
  }>;
  total: number;
  took: number;
}

export interface BulkIndexItem {
  id: string;
  data: Record<string, unknown>;
}

@Injectable()
export class SearchService implements OnModuleInit {
  private readonly logger = new Logger(SearchService.name);
  private client!: Client;
  private isConnected = false;

  constructor(private readonly configService: ConfigService) {}

  onModuleInit(): void {
    const node = this.configService.get<string>('ELASTICSEARCH_URL');
    if (!node) {
      this.logger.warn('ELASTICSEARCH_URL not configured — search disabled');
      return;
    }

    this.client = new Client({
      node,
      auth: this.configService.get<string>('ELASTICSEARCH_API_KEY')
        ? { apiKey: this.configService.get<string>('ELASTICSEARCH_API_KEY')! }
        : this.configService.get<string>('ELASTICSEARCH_USER')
          ? {
              username: this.configService.get<string>('ELASTICSEARCH_USER')!,
              password: this.configService.get<string>('ELASTICSEARCH_PASS')!,
            }
          : undefined,
      maxRetries: 3,
      requestTimeout: 30000,
      sniffOnStart: false,
    });

    this.checkConnection();
  }

  /**
   * Full-text search with tenant isolation.
   */
  async search<T = Record<string, unknown>>(
    options: SearchOptions,
  ): Promise<SearchResult<T>> {
    if (!this.isConnected) {
      return { hits: [], total: 0, took: 0 };
    }

    const must: unknown[] = [];
    const filter: unknown[] = [];

    // Multi-match query
    must.push({
      multi_match: {
        query: options.query,
        fields: options.fields || ['*'],
        type: 'best_fields',
        fuzziness: 'AUTO',
      },
    });

    // Tenant isolation
    if (options.tenantId) {
      filter.push({ term: { tenantId: options.tenantId } });
    }

    // Additional filters
    if (options.filters) {
      for (const [field, value] of Object.entries(options.filters)) {
        filter.push({ term: { [field]: value } });
      }
    }

    const response = await this.client.search({
      index: options.index,
      from: options.from || 0,
      size: options.size || 20,
      query: {
        bool: {
          must: must as any,
          filter: filter as any,
        },
      },
      sort: (options.sort as any) || [{ _score: 'desc' }],
      ...(options.highlight
        ? {
            highlight: {
              fields: { '*': {} },
              pre_tags: ['<mark>'],
              post_tags: ['</mark>'],
            },
          }
        : {}),
    });

    const body = response as any;
    const hitsBody = body['hits'];
    const hitsArray = (hitsBody['hits'] || []) as any[];
    const totalObj = hitsBody['total'];
    const total = typeof totalObj === 'number' ? totalObj : totalObj?.value || 0;

    return {
      hits: hitsArray.map((hit) => ({
        id: hit['_id'],
        score: hit['_score'],
        source: hit['_source'] as T,
        highlight: hit['highlight'],
      })),
      total,
      took: body['took'] || 0,
    };
  }

  /**
   * Index a single document.
   */
  async indexDocument(
    index: string,
    id: string,
    data: Record<string, unknown>,
  ): Promise<void> {
    if (!this.isConnected) return;

    await this.client.index({
      index,
      id,
      document: data,
      refresh: 'wait_for',
    });

    this.logger.debug(`Document indexed: ${index}/${id}`);
  }

  /**
   * Bulk index documents.
   */
  async bulkIndex(
    index: string,
    items: BulkIndexItem[],
  ): Promise<{ errors: boolean; indexed: number }> {
    if (!this.isConnected) return { errors: false, indexed: 0 };

    const operations = items.flatMap((item) => [
      { index: { _index: index, _id: item.id } },
      item.data,
    ]);

    const response = await this.client.bulk({ operations, refresh: 'wait_for' });
    const responseBody = response as any;

    this.logger.log(`Bulk indexed ${items.length} documents into ${index}`);

    return {
      errors: !!responseBody['errors'],
      indexed: items.length,
    };
  }

  /**
   * Delete a document from an index.
   */
  async deleteDocument(index: string, id: string): Promise<void> {
    if (!this.isConnected) return;

    try {
      await this.client.delete({ index, id, refresh: 'wait_for' });
      this.logger.debug(`Document deleted: ${index}/${id}`);
    } catch (error) {
      this.logger.warn(`Failed to delete document ${index}/${id}: ${(error as Error).message}`);
    }
  }

  /**
   * Create an index with mapping if it doesn't exist.
   */
  async ensureIndex(
    index: string,
    mapping?: Record<string, unknown>,
  ): Promise<void> {
    if (!this.isConnected) return;

    const exists = await this.client.indices.exists({ index });
    if (exists) return;

    await this.client.indices.create({
      index,
      settings: {
        number_of_shards: 1,
        number_of_replicas: 0,
        analysis: {
          analyzer: {
            default: {
              type: 'standard',
              stopwords: '_english_',
            },
          },
        },
      },
      mappings: mapping
        ? ({ properties: mapping } as any)
        : undefined,
    });

    this.logger.log(`Index created: ${index}`);
  }

  /**
   * Health check for ElasticSearch connectivity.
   */
  async ping(): Promise<boolean> {
    if (!this.client) return false;
    try {
      await this.client.ping();
      return true;
    } catch {
      return false;
    }
  }

  private async checkConnection(): Promise<void> {
    try {
      await this.client.ping();
      this.isConnected = true;
      this.logger.log('ElasticSearch connected');
    } catch (error) {
      this.isConnected = false;
      this.logger.warn(
        `ElasticSearch unavailable: ${(error as Error).message}. Search features disabled.`,
      );
    }
  }
}

import { Module, Global } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Workflow } from './entities/workflow.entity';
import { WorkflowExecutor } from './executor.service';
import { AIModule } from '../ai/ai.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([Workflow]),
    AIModule,
    NotificationsModule,
  ],
  providers: [WorkflowExecutor],
  exports: [WorkflowExecutor],
})
export class AutomationModule {}

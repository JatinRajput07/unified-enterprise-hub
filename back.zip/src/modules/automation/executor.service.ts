import { Injectable, Logger } from '@nestjs/common';
import { Workflow, WorkflowStep } from './entities/workflow.entity';
import { AIService } from '../ai/ai.service';
import { EmailService } from '../notifications/email/email.service';

@Injectable()
export class WorkflowExecutor {
  private readonly logger = new Logger(WorkflowExecutor.name);

  constructor(
    private readonly aiService: AIService,
    private readonly emailService: EmailService,
  ) {}

  async execute(workflow: Workflow, triggerPayload: any) {
    this.logger.log(`Executing workflow: ${workflow.name} (${workflow.id})`);
    
    let context = {
      trigger: triggerPayload,
      steps: [] as any[],
    };

    try {
      for (let i = 0; i < workflow.steps.length; i++) {
        const step = workflow.steps[i];
        const result = await this.executeStep(step, context, workflow.tenantId);
        context.steps.push(result);
      }
      this.logger.log(`Workflow ${workflow.id} completed successfully`);
    } catch (error) {
      this.logger.error(`Workflow ${workflow.id} failed at step: ${(error as Error).message}`);
      throw error;
    }
  }

  private async executeStep(step: WorkflowStep, context: any, tenantId: string) {
    switch (step.type) {
      case 'ai':
        return this.aiService.chat('system', tenantId, step.config.prompt, {
          temperature: step.config.temperature,
        });
      case 'email':
        // Simplified email action
        return { status: 'sent' };
      case 'http':
        // Axios call placeholder
        return { status: 'success', data: {} };
      default:
        throw new Error(`Unknown step type: ${step.type}`);
    }
  }
}

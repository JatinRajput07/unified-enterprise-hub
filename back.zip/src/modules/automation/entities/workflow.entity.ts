import { Entity, Column, ManyToOne, JoinColumn, Index } from 'typeorm';
import { BaseEntity } from '../../../database/base.entity';
import { TenantEntity } from '../../tenants/entities/tenant.entity';

export enum WorkflowTriggerType {
  WEBHOOK = 'webhook',
  SCHEDULE = 'schedule',
  EVENT = 'event',
}

export interface WorkflowStep {
  type: 'http' | 'email' | 'ai' | 'db';
  config: any;
}

@Entity('workflows')
export class Workflow extends BaseEntity {
  @Column()
  name!: string;

  @Column({
    type: 'enum',
    enum: WorkflowTriggerType,
  })
  triggerType!: WorkflowTriggerType;

  @Column({ type: 'jsonb' })
  triggerConfig!: any;

  @Column({ type: 'jsonb' })
  steps!: WorkflowStep[];

  @Column({ name: 'tenant_id', type: 'uuid' })
  @Index()
  tenantId!: string;

  @ManyToOne(() => TenantEntity)
  @JoinColumn({ name: 'tenant_id' })
  tenant!: TenantEntity;

  @Column({ name: 'is_active', default: true })
  isActive!: boolean;

  @Column({ name: 'last_run_at', type: 'timestamptz', nullable: true })
  lastRunAt?: Date;
}

import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import { RoleEntity } from './entities/role.entity';
import { PermissionEntity } from './entities/permission.entity';

/**
 * Default roles with hierarchy levels.
 */
const DEFAULT_ROLES = [
  { name: 'SUPER_ADMIN', description: 'Super Administrator with full access', hierarchyLevel: 100, isSystem: true },
  { name: 'ADMIN', description: 'Administrator', hierarchyLevel: 80, isSystem: true },
  { name: 'MODERATOR', description: 'Moderator', hierarchyLevel: 60, isSystem: true },
  { name: 'USER', description: 'Regular User', hierarchyLevel: 40, isSystem: true },
];

/**
 * Default permissions (resource:action format).
 */
const DEFAULT_PERMISSIONS = [
  // Users
  { resource: 'users', action: 'create', description: 'Create users' },
  { resource: 'users', action: 'read', description: 'Read users' },
  { resource: 'users', action: 'update', description: 'Update users' },
  { resource: 'users', action: 'delete', description: 'Delete users' },
  // Roles
  { resource: 'roles', action: 'create', description: 'Create roles' },
  { resource: 'roles', action: 'read', description: 'Read roles' },
  { resource: 'roles', action: 'update', description: 'Update roles' },
  { resource: 'roles', action: 'delete', description: 'Delete roles' },
  // Tenants
  { resource: 'tenants', action: 'create', description: 'Create tenants' },
  { resource: 'tenants', action: 'read', description: 'Read tenants' },
  { resource: 'tenants', action: 'update', description: 'Update tenants' },
  { resource: 'tenants', action: 'delete', description: 'Delete tenants' },
  // Settings
  { resource: 'settings', action: 'read', description: 'Read settings' },
  { resource: 'settings', action: 'update', description: 'Update settings' },
  // Wildcard
  { resource: '*', action: '*', description: 'Full access to everything' },
];

/**
 * Role → Permissions mapping for default seeding.
 */
const ROLE_PERMISSIONS: Record<string, string[]> = {
  SUPER_ADMIN: ['*:*'],
  ADMIN: [
    'users:create', 'users:read', 'users:update', 'users:delete',
    'roles:read',
    'tenants:read', 'tenants:update',
    'settings:read', 'settings:update',
  ],
  MODERATOR: [
    'users:read', 'users:update',
    'roles:read',
    'tenants:read',
    'settings:read',
  ],
  USER: [
    'users:read',
    'settings:read',
  ],
};

@Injectable()
export class RolesService {
  private readonly logger = new Logger(RolesService.name);

  constructor(
    @InjectRepository(RoleEntity)
    private readonly roleRepository: Repository<RoleEntity>,
    @InjectRepository(PermissionEntity)
    private readonly permissionRepository: Repository<PermissionEntity>,
  ) {}

  async findRoleByName(name: string): Promise<RoleEntity | null> {
    return this.roleRepository.findOne({ where: { name }, relations: ['permissions'] });
  }

  async findRoleById(id: string): Promise<RoleEntity> {
    const role = await this.roleRepository.findOne({ where: { id }, relations: ['permissions'] });
    if (!role) {
      throw new NotFoundException(`Role not found: ${id}`);
    }
    return role;
  }

  async findAllRoles(): Promise<RoleEntity[]> {
    return this.roleRepository.find({ relations: ['permissions'] });
  }

  async findPermissionsBySlugs(slugs: string[]): Promise<PermissionEntity[]> {
    return this.permissionRepository.find({ where: { slug: In(slugs) } });
  }

  async findAllPermissions(): Promise<PermissionEntity[]> {
    return this.permissionRepository.find();
  }

  /**
   * Seeds default roles and permissions on startup.
   */
  async seedDefaults(): Promise<void> {
    this.logger.log('Seeding default roles and permissions...');

    // Seed permissions
    for (const perm of DEFAULT_PERMISSIONS) {
      const slug = `${perm.resource}:${perm.action}`;
      const existing = await this.permissionRepository.findOne({ where: { slug } });
      if (!existing) {
        await this.permissionRepository.save(
          this.permissionRepository.create({
            resource: perm.resource,
            action: perm.action,
            slug,
            description: perm.description,
          }),
        );
        this.logger.debug(`Permission created: ${slug}`);
      }
    }

    // Seed roles with permissions
    for (const roleDef of DEFAULT_ROLES) {
      let role = await this.roleRepository.findOne({
        where: { name: roleDef.name },
        relations: ['permissions'],
      });

      if (!role) {
        role = this.roleRepository.create({
          name: roleDef.name,
          description: roleDef.description,
          hierarchyLevel: roleDef.hierarchyLevel,
          isSystem: roleDef.isSystem,
        });
      }

      // Assign permissions
      const permSlugs = ROLE_PERMISSIONS[roleDef.name] || [];
      const permissions = await this.permissionRepository.find({
        where: { slug: In(permSlugs) },
      });
      role.permissions = permissions;

      await this.roleRepository.save(role);
      this.logger.debug(`Role seeded: ${roleDef.name} with ${permissions.length} permissions`);
    }

    this.logger.log('Default roles and permissions seeded successfully');
  }
}

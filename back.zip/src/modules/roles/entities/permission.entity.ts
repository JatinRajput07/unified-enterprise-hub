import {
  Entity,
  Column,
  ManyToMany,
  JoinTable,
  Index,
} from 'typeorm';
import { BaseEntity } from '../../../database/base.entity';
import { RoleEntity } from './role.entity';

@Entity('permissions')
export class PermissionEntity extends BaseEntity {
  @Column({ length: 100 })
  @Index('IDX_PERMISSION_RESOURCE')
  resource!: string;

  @Column({ length: 100 })
  action!: string;

  @Column({ length: 255, unique: true })
  @Index('IDX_PERMISSION_SLUG', { unique: true })
  slug!: string;

  @Column({ length: 255, nullable: true })
  description?: string;

  @ManyToMany(() => RoleEntity, (role) => role.permissions)
  @JoinTable({ name: 'role_permissions' })

  roles!: RoleEntity[];
}

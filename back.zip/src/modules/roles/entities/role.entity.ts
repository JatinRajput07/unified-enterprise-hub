import {
  Entity,
  Column,
  ManyToMany,
  Index,
} from 'typeorm';
import { BaseEntity } from '../../../database/base.entity';
import { PermissionEntity } from './permission.entity';

@Entity('roles')
export class RoleEntity extends BaseEntity {
  @Column({ length: 100, unique: true })
  @Index('IDX_ROLE_NAME', { unique: true })
  name!: string;

  @Column({ length: 255, nullable: true })
  description?: string;

  @Column({ type: 'int', default: 0 })
  hierarchyLevel!: number;

  @Column({ default: false })
  isSystem!: boolean;


  @ManyToMany(() => PermissionEntity, (permission) => permission.roles, {
    eager: true,
    cascade: true,
  })
  permissions!: PermissionEntity[];
}

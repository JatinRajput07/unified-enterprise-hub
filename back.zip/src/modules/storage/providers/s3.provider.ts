import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
  GetObjectCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import {
  IStorageProvider,
  StorageFile,
  UploadResult,
} from '../interfaces/storage-provider.interface';

@Injectable()
export class S3StorageProvider implements IStorageProvider {
  private readonly logger = new Logger(S3StorageProvider.name);
  private readonly s3Client: S3Client;
  private readonly bucket: string;

  constructor(private readonly configService: ConfigService) {
    this.s3Client = new S3Client({
      region: this.configService.get<string>('S3_REGION') || 'us-east-1',
      credentials: {
        accessKeyId: this.configService.get<string>('S3_ACCESS_KEY')!,
        secretAccessKey: this.configService.get<string>('S3_SECRET_KEY')!,
      },
      endpoint: this.configService.get<string>('S3_ENDPOINT'),
      forcePathStyle: !!this.configService.get<string>('S3_ENDPOINT'),
    });
    this.bucket = this.configService.get<string>('S3_BUCKET')!;
  }

  async upload(file: StorageFile, targetPath: string): Promise<UploadResult> {
    const command = new PutObjectCommand({
      Bucket: this.bucket,
      Key: targetPath,
      Body: file.buffer || fs.createReadStream(file.path!),
      ContentType: file.mimetype,
    });

    await this.s3Client.send(command);

    return {
      url: this.getPublicUrl(targetPath),
      key: targetPath,
      size: file.size,
      mimetype: file.mimetype,
      provider: 's3',
    };
  }

  async delete(key: string): Promise<void> {
    const command = new DeleteObjectCommand({
      Bucket: this.bucket,
      Key: key,
    });
    await this.s3Client.send(command);
  }

  async getSignedUrl(key: string, expiry: number = 3600): Promise<string> {
    const command = new GetObjectCommand({
      Bucket: this.bucket,
      Key: key,
    });
    return getSignedUrl(this.s3Client, command, { expiresIn: expiry });
  }

  getPublicUrl(key: string): string {
    const endpoint = this.configService.get<string>('S3_ENDPOINT');
    if (endpoint) {
      return `${endpoint}/${this.bucket}/${key}`;
    }
    return `https://${this.bucket}.s3.amazonaws.com/${key}`;
  }
}

// Add missing fs import for stream
import * as fs from 'fs';

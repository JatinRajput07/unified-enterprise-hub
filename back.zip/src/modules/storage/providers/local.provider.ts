import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as fs from 'fs';
import * as path from 'path';
import { IStorageProvider, StorageFile, UploadResult } from '../interfaces/storage-provider.interface';

@Injectable()
export class LocalStorageProvider implements IStorageProvider {
  private readonly logger = new Logger(LocalStorageProvider.name);
  private readonly uploadsDir: string;

  constructor(private readonly configService: ConfigService) {
    this.uploadsDir = path.resolve(process.cwd(), 'uploads');
    if (!fs.existsSync(this.uploadsDir)) {
      fs.mkdirSync(this.uploadsDir, { recursive: true });
    }
  }

  async upload(file: StorageFile, targetPath: string): Promise<UploadResult> {
    const fullPath = path.join(this.uploadsDir, targetPath);
    const dir = path.dirname(fullPath);

    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    if (file.buffer) {
      fs.writeFileSync(fullPath, file.buffer);
    } else if (file.path) {
      fs.copyFileSync(file.path, fullPath);
    }

    const appUrl = this.configService.get<string>('APP_URL') || 'http://localhost:3000';
    const url = `${appUrl}/uploads/${targetPath.replace(/\\/g, '/')}`;

    return {
      url,
      key: targetPath,
      size: file.size,
      mimetype: file.mimetype,
      provider: 'local',
    };
  }

  async delete(key: string): Promise<void> {
    const fullPath = path.join(this.uploadsDir, key);
    if (fs.existsSync(fullPath)) {
      fs.unlinkSync(fullPath);
    }
  }

  async getSignedUrl(key: string): Promise<string> {
    // Local storage doesn't support signed URLs in this simple implementation
    return this.getPublicUrl(key);
  }

  getPublicUrl(key: string): string {
    const appUrl = this.configService.get<string>('APP_URL') || 'http://localhost:3000';
    return `${appUrl}/uploads/${key.replace(/\\/g, '/')}`;
  }
}

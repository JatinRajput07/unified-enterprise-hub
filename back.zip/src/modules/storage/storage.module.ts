import { Module, Global } from '@nestjs/common';
import { StorageService } from './storage.service';
import { LocalStorageProvider } from './providers/local.provider';
import { S3StorageProvider } from './providers/s3.provider';
import { UploadController } from './upload.controller';

@Global()
@Module({
  controllers: [UploadController],
  providers: [
    StorageService,
    LocalStorageProvider,
    S3StorageProvider,
  ],
  exports: [StorageService],
})
export class StorageModule {}

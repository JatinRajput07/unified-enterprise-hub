import { Injectable, Logger, Inject } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  IStorageProvider,
  StorageFile,
  UploadResult,
} from './interfaces/storage-provider.interface';
import { LocalStorageProvider } from './providers/local.provider';
import { S3StorageProvider } from './providers/s3.provider';

@Injectable()
export class StorageService {
  private readonly logger = new Logger(StorageService.name);
  private provider: IStorageProvider;

  constructor(
    private readonly configService: ConfigService,
    private readonly localProvider: LocalStorageProvider,
    private readonly s3Provider: S3StorageProvider,
  ) {
    const driver = this.configService.get<string>('STORAGE_DRIVER') || 'local';
    this.provider = driver === 's3' ? this.s3Provider : this.localProvider;
    this.logger.log(`Storage service initialized with driver: ${driver}`);
  }

  async upload(
    file: StorageFile,
    folder: string = 'general',
  ): Promise<UploadResult> {
    const filename = `${Date.now()}-${file.originalname.replace(/\s/g, '-')}`;
    const targetPath = `${folder}/${filename}`;
    
    // Virus scan placeholder
    this.logger.debug(`Scanning file for viruses: ${file.originalname}`);
    
    return this.provider.upload(file, targetPath);
  }

  async delete(key: string): Promise<void> {
    return this.provider.delete(key);
  }

  async getSignedUrl(key: string, expiry?: number): Promise<string> {
    return this.provider.getSignedUrl(key, expiry);
  }

  getPublicUrl(key: string): string {
    return this.provider.getPublicUrl(key);
  }
}

export enum QueueNames {
  EMAIL = 'email',
  NOTIFICATION = 'notification',
  SEARCH_SYNC = 'search-sync',
  AI = 'ai',
  REPORT = 'report',
}

export enum JobNames {
  // Email
  SEND_WELCOME = 'send-welcome',
  SEND_RESET_PASSWORD = 'send-reset-password',
  SEND_VERIFICATION = 'send-verification',
  SEND_2FA_CODE = 'send-2fa-code',
  SEND_GENERIC_EMAIL = 'send-generic-email',

  // Notification
  SEND_PUSH = 'send-push',
  SEND_SMS = 'send-sms',
  SEND_WEB_PUSH = 'send-web-push',

  // Search Sync
  SYNC_USER = 'sync-user',
  SYNC_TENANT = 'sync-tenant',
  SYNC_RESOURCE = 'sync-resource',

  // AI
  ANALYZE_LEAD = 'analyze-lead',
  GENERATE_SUMMARY = 'generate-summary',

  // Report
  GENERATE_CSV = 'generate-csv',
  GENERATE_PDF = 'generate-pdf',
}

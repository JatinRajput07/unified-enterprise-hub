import { Module, Global } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { BullBoardModule } from '@bull-board/nestjs';
import { ExpressAdapter } from '@bull-board/express';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';
import { QueueNames } from './queue.constants';
import { EmailProcessor } from './processors/email.processor';
import { SearchSyncProcessor } from './processors/search-sync.processor';
import { NotificationsModule } from '../notifications/notifications.module';
import { SearchModule } from '../search/search.module';

@Global()
@Module({
  imports: [
    BullModule.registerQueue(
      { name: QueueNames.EMAIL },
      { name: QueueNames.NOTIFICATION },
      { name: QueueNames.SEARCH_SYNC },
      { name: QueueNames.AI },
      { name: QueueNames.REPORT },
    ),
    
    // Bull Board Monitoring UI
    BullBoardModule.forRoot({
      route: '/admin/queues',
      adapter: ExpressAdapter,
    }),
    
    BullBoardModule.forFeature(
      { name: QueueNames.EMAIL, adapter: BullMQAdapter },
      { name: QueueNames.NOTIFICATION, adapter: BullMQAdapter },
      { name: QueueNames.SEARCH_SYNC, adapter: BullMQAdapter },
      { name: QueueNames.AI, adapter: BullMQAdapter },
      { name: QueueNames.REPORT, adapter: BullMQAdapter },
    ),

    
    NotificationsModule,
    SearchModule,
  ],
  providers: [EmailProcessor, SearchSyncProcessor],
  exports: [BullModule],
})
export class QueueModule {}

import {
  Processor,
  WorkerHost,
  OnWorkerEvent,
} from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { QueueNames } from '../queue.constants';
import { EmailService } from '../../notifications/email/email.service';

@Processor(QueueNames.EMAIL, {
  concurrency: 5,
})
export class EmailProcessor extends WorkerHost {
  private readonly logger = new Logger(EmailProcessor.name);

  constructor(private readonly emailService: EmailService) {
    super();
  }

  async process(job: Job<any, any, string>): Promise<any> {
    this.logger.log(`Processing email job: ${job.name} (id: ${job.id})`);
    
    const { to, subject, template, context, options } = job.data;

    try {
      await job.updateProgress(10);
      
      await this.emailService.sendEmail({
        to,
        subject,
        template,
        context,
        ...options,
      });

      await job.updateProgress(100);
      this.logger.log(`Email job completed: ${job.id}`);
      return { success: true };
    } catch (error) {
      this.logger.error(`Email job failed: ${(error as Error).message}`);
      throw error; // Let BullMQ handle retries
    }
  }

  @OnWorkerEvent('failed')
  onFailed(job: Job, error: Error) {
    this.logger.error(
      `Job ${job.id} failed after ${job.attemptsMade} attempts: ${error.message}`,
    );
    
    if (job.attemptsMade >= 3) {
      this.logger.error(`Job ${job.id} moved to dead-letter queue`);
      // Logic to move to a DLQ or notify admin could go here
    }
  }

  @OnWorkerEvent('completed')
  onCompleted(job: Job) {
    this.logger.debug(`Job ${job.id} completed successfully`);
  }
}

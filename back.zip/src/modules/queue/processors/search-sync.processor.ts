import {
  Processor,
  WorkerHost,
  OnWorkerEvent,
} from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { QueueNames } from '../queue.constants';
import { SearchService } from '../../search/search.service';

@Processor(QueueNames.SEARCH_SYNC, {
  concurrency: 10,
})
export class SearchSyncProcessor extends WorkerHost {
  private readonly logger = new Logger(SearchSyncProcessor.name);

  constructor(private readonly searchService: SearchService) {
    super();
  }

  async process(job: Job<any, any, string>): Promise<any> {
    const { index, id, data, action } = job.data;

    try {
      if (action === 'delete') {
        await this.searchService.deleteDocument(index, id);
      } else {
        await this.searchService.indexDocument(index, id, data);
      }
      return { success: true };
    } catch (error) {
      this.logger.error(`Search sync job failed: ${(error as Error).message}`);
      throw error;
    }
  }

  @OnWorkerEvent('failed')
  onFailed(job: Job, error: Error) {
    this.logger.error(`Search sync job ${job.id} failed: ${error.message}`);
  }
}

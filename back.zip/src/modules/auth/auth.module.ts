import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { ConfigModule, ConfigService } from '@nestjs/config';
import * as fs from 'fs';
import * as path from 'path';

import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { SessionEntity } from './entities/session.entity';
import { AuthLogEntity } from './entities/auth-log.entity';
import { JwtStrategy } from './strategies/jwt.strategy';
import { JwtRefreshStrategy } from './strategies/refresh.strategy';
import { GoogleStrategy } from './strategies/google.strategy';
import { GithubStrategy } from './strategies/github.strategy';
import { UsersModule } from '../users/users.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { EncryptionUtil } from '../../common/utils/encryption.util';

@Module({
  imports: [
    TypeOrmModule.forFeature([SessionEntity, AuthLogEntity]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.registerAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => {
        const privateKeyPath = configService.get<string>('JWT_PRIVATE_KEY_PATH');
        const publicKeyPath = configService.get<string>('JWT_PUBLIC_KEY_PATH');

        let privateKey: string | Buffer = '';
        let publicKey: string | Buffer = '';

        try {
          if (privateKeyPath) {
            privateKey = fs.readFileSync(path.resolve(process.cwd(), privateKeyPath));
          }
          if (publicKeyPath) {
            publicKey = fs.readFileSync(path.resolve(process.cwd(), publicKeyPath));
          }
        } catch (error: any) {
          console.error('❌ Failed to load JWT RSA keys:', error.message);
        }

        return {
          privateKey,
          publicKey,
          signOptions: {
            algorithm: 'RS256',
            expiresIn: configService.get<number>('JWT_ACCESS_EXPIRES_SECONDS') || 900,
          },
        };
      },
      inject: [ConfigService],
    }),
    UsersModule,
    NotificationsModule,
  ],
  controllers: [AuthController],
  providers: [
    AuthService,
    JwtStrategy,
    JwtRefreshStrategy,
    GoogleStrategy,
    GithubStrategy,
    EncryptionUtil,
  ],
  exports: [AuthService, JwtStrategy],
})
export class AuthModule {}

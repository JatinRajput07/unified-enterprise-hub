import {
  Injectable,
  Logger,
  UnauthorizedException,
  ForbiddenException,
  BadRequestException,
  Inject,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, LessThan } from 'typeorm';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import * as bcrypt from 'bcrypt';
import * as speakeasy from 'speakeasy';
import * as QRCode from 'qrcode';

import { SessionEntity } from './entities/session.entity';
import { AuthLogEntity } from './entities/auth-log.entity';
import { UsersService } from '../users/users.service';
import { UserEntity, AuthProvider } from '../users/entities/user.entity';
import { EmailService } from '../notifications/email/email.service';
import { EncryptionUtil } from '../../common/utils/encryption.util';
import { AuthAction } from '../../common/constants/auth-actions';
import {
  RegisterDto,
  LoginDto,
  Verify2FaLoginDto,
  AuthResponseDto,
  TwoFaSetupResponseDto,
  TwoFaEnabledResponseDto,
  TwoFaRequiredResponseDto,
  ForgotPasswordDto,
  ResetPasswordDto,
  VerifyEmailDto,
} from './dto/auth.dto';
import { JwtPayload } from './strategies/jwt.strategy';

import { CacheService } from '../../common/cache/cache.service';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  private readonly BCRYPT_ROUNDS = 12;

  constructor(
    @InjectRepository(SessionEntity)
    private readonly sessionRepo: Repository<SessionEntity>,
    @InjectRepository(AuthLogEntity)
    private readonly authLogRepo: Repository<AuthLogEntity>,
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    private readonly encryptionUtil: EncryptionUtil,
    private readonly emailService: EmailService,
    private readonly cacheService: CacheService,
  ) {}

  // ═══════════════════════════════════════════════════
  // REGISTER
  // ═══════════════════════════════════════════════════
  async register(dto: RegisterDto, ip?: string, userAgent?: string): Promise<AuthResponseDto> {
    const userResponse = await this.usersService.create({
      firstName: dto.firstName,
      lastName: dto.lastName,
      email: dto.email,
      password: dto.password,
      phone: dto.phone,
    });

    const user = await this.usersService.findById(userResponse.id);

    // Generate email verification OTP
    const otp = this.encryptionUtil.generateOtp(6);
    const otpKey = `email_verify_otp:${user.id}`;
    const expiryMinutes = this.configService.get<number>('EMAIL_VERIFY_OTP_EXPIRY_MINUTES') || 10;
    await this.cacheService.set(otpKey, otp, expiryMinutes * 60 * 1000);

    // Send verification email
    try {
      await this.emailService.sendVerificationEmail(user.email, user.firstName || 'User', otp);
    } catch (error: any) {
      this.logger.error(`Failed to send verification email: ${error.message}`);
    }

    await this.createAuthLog(user.id, AuthAction.USER_CREATED, ip, userAgent);

    return this.completeLogin(user, ip, userAgent);
  }

  // ═══════════════════════════════════════════════════
  // LOGIN
  // ═══════════════════════════════════════════════════
  async login(
    dto: LoginDto,
    ip: string,
    userAgent?: string,
  ): Promise<AuthResponseDto | TwoFaRequiredResponseDto> {
    // Check brute force lock
    await this.checkBruteForceLock(dto.email, ip);

    const user = await this.usersService.findByEmail(dto.email);

    if (!user) {
      await this.trackFailedLogin(dto.email, ip);
      await this.createAuthLog(null, AuthAction.LOGIN_FAILED, ip, userAgent, {
        email: dto.email,
        reason: 'User not found',
      });
      throw new UnauthorizedException('Invalid email or password');
    }

    if (!user.isActive) {
      throw new ForbiddenException('Account is deactivated. Contact administrator.');
    }

    if (!user.password) {
      throw new UnauthorizedException(
        'This account uses social login. Please sign in with your social provider.',
      );
    }

    const isPasswordValid = await bcrypt.compare(dto.password, user.password);
    if (!isPasswordValid) {
      await this.trackFailedLogin(dto.email, ip);
      await this.createAuthLog(user.id, AuthAction.LOGIN_FAILED, ip, userAgent, {
        reason: 'Invalid password',
      });
      throw new UnauthorizedException('Invalid email or password');
    }

    // Clear brute force counter on successful password
    await this.clearBruteForceLock(dto.email, ip);

    // If 2FA is enabled, return temp token instead of full login
    if (user.twoFaEnabled) {
      const tempToken = await this.generateTempToken(user.id);
      await this.createAuthLog(user.id, AuthAction.LOGIN_SUCCESS, ip, userAgent, {
        step: 'requires_2fa',
      });
      return {
        requires2fa: true,
        tempToken,
        message: 'Please provide your 2FA code',
      };
    }

    // Full login
    await this.createAuthLog(user.id, AuthAction.LOGIN_SUCCESS, ip, userAgent);
    return this.completeLogin(user, ip, userAgent);
  }

  // ═══════════════════════════════════════════════════
  // 2FA LOGIN VERIFICATION
  // ═══════════════════════════════════════════════════
  async verify2FaLogin(
    dto: Verify2FaLoginDto,
    ip: string,
    userAgent?: string,
  ): Promise<AuthResponseDto> {
    // Verify temp token
    const payload = await this.verifyTempToken(dto.tempToken);

    // Check if temp token was already used (replay protection)
    const tempTokenUsedKey = `temp_2fa_used:${this.encryptionUtil.hashToken(dto.tempToken)}`;
    const wasUsed = await this.cacheService.get(tempTokenUsedKey);
    if (wasUsed) {
      throw new UnauthorizedException('This 2FA token has already been used');
    }

    const user = await this.usersService.findByIdWithSecret(payload.sub);
    if (!user || !user.twoFaEnabled || !user.twoFaSecret) {
      throw new UnauthorizedException('2FA is not configured for this user');
    }

    // Check for backup codes first (if code is 8 chars and alphanumeric)
    if (dto.totpCode.length >= 8 && /^[A-Z0-9]+$/.test(dto.totpCode)) {
      const hashedCode = this.encryptionUtil.hashToken(dto.totpCode);
      const backupCodes = user.twoFaBackupCodes || [];
      const codeIndex = backupCodes.indexOf(hashedCode);

      if (codeIndex !== -1) {
        // Valid backup code — remove it after use
        backupCodes.splice(codeIndex, 1);
        await this.usersService.updateBackupCodes(user.id, backupCodes);
        
        await this.createAuthLog(user.id, AuthAction.TWO_FA_VERIFIED, ip, userAgent, { method: 'backup_code' });
        
        // Mark temp token as used
        await this.cacheService.set(tempTokenUsedKey, true, 5 * 60 * 1000);
        
        const fullUser = await this.usersService.findById(user.id);
        return this.completeLogin(fullUser, ip, userAgent);
      }
    }

    // Decrypt the stored TOTP secret
    const decryptedSecret = this.encryptionUtil.decrypt(user.twoFaSecret);

    // Verify TOTP code
    const isValid = speakeasy.totp.verify({
      secret: decryptedSecret,
      encoding: 'base32',
      token: dto.totpCode,
      window: 1,
    });

    if (!isValid) {
      await this.createAuthLog(user.id, AuthAction.TWO_FA_FAILED, ip, userAgent);
      throw new UnauthorizedException('Invalid 2FA code');
    }

    // Mark temp token as used (5 min TTL)
    await this.cacheService.set(tempTokenUsedKey, true, 5 * 60 * 1000);

    await this.createAuthLog(user.id, AuthAction.TWO_FA_VERIFIED, ip, userAgent);

    // Reload user with relations
    const fullUser = await this.usersService.findById(user.id);
    return this.completeLogin(fullUser, ip, userAgent);
  }

  // ═══════════════════════════════════════════════════
  // REFRESH TOKENS
  // ═══════════════════════════════════════════════════
  async refreshTokens(refreshToken: string, ip?: string, userAgent?: string): Promise<AuthResponseDto> {
    const tokenHash = this.encryptionUtil.hashToken(refreshToken);

    // Check DB for session
    const session = await this.sessionRepo.findOne({
      where: { tokenHash, isRevoked: false },
    });

    if (!session) {
      this.logger.warn(`Refresh token reuse or invalid token detected`);
      throw new UnauthorizedException('Invalid or revoked refresh token');
    }

    if (session.expiresAt < new Date()) {
      throw new UnauthorizedException('Refresh token has expired');
    }

    const user = await this.usersService.findById(session.userId);
    if (!user || !user.isActive) {
      throw new UnauthorizedException('Account is inactive');
    }

    // Revoke old session (rotation)
    session.isRevoked = true;
    await this.sessionRepo.save(session);
    await this.cacheService.del(`refresh:${tokenHash}`);

    await this.createAuthLog(user.id, AuthAction.TOKEN_REFRESHED, ip, userAgent);

    // Issue new tokens
    return this.completeLogin(user, ip, userAgent);
  }

  // ═══════════════════════════════════════════════════
  // LOGOUT
  // ═══════════════════════════════════════════════════
  async logout(userId: string, refreshToken?: string, ip?: string, userAgent?: string): Promise<void> {
    if (refreshToken) {
      const tokenHash = this.encryptionUtil.hashToken(refreshToken);
      await this.sessionRepo.update(
        { tokenHash, userId, isRevoked: false },
        { isRevoked: true },
      );
      await this.cacheService.del(`refresh:${tokenHash}`);
    } else {
      // Revoke all sessions
      await this.revokeAllUserSessions(userId);
    }

    await this.createAuthLog(userId, AuthAction.LOGOUT, ip, userAgent);
    this.logger.log(`User logged out: ${userId}`);
  }

  async logoutAll(userId: string, ip?: string, userAgent?: string): Promise<{ count: number }> {
    const sessions = await this.sessionRepo.find({
      where: { userId, isRevoked: false },
    });

    for (const session of sessions) {
      session.isRevoked = true;
      await this.sessionRepo.save(session);
      await this.cacheService.del(`refresh:${session.tokenHash}`);
    }

    await this.createAuthLog(userId, AuthAction.LOGOUT_ALL, ip, userAgent, {
      sessionsRevoked: sessions.length,
    });

    return { count: sessions.length };
  }

  // ═══════════════════════════════════════════════════
  // FORGOT PASSWORD
  // ═══════════════════════════════════════════════════
  async forgotPassword(dto: ForgotPasswordDto, ip?: string, userAgent?: string): Promise<{ message: string }> {
    // Always return same response (security: don't reveal if email exists)
    const response = { message: 'If the email exists, a password reset OTP has been sent.' };

    const user = await this.usersService.findByEmail(dto.email);
    if (!user) {
      return response;
    }

    // Generate OTP and store in Redis
    const otp = this.encryptionUtil.generateOtp(6);
    const otpKey = `password_reset_otp:${dto.email}`;
    const expiryMinutes = this.configService.get<number>('OTP_EXPIRY_MINUTES') || 15;
    await this.cacheService.set(otpKey, otp, expiryMinutes * 60 * 1000);

    await this.createAuthLog(user.id, AuthAction.PASSWORD_RESET_REQUESTED, ip, userAgent);

    // Send reset email
    try {
      await this.emailService.sendPasswordResetEmail(user.email, user.firstName || 'User', otp, `${expiryMinutes} minutes`);
    } catch (error: any) {
      this.logger.error(`Failed to send password reset email: ${error.message}`);
    }

    return response;
  }

  // ═══════════════════════════════════════════════════
  // RESET PASSWORD
  // ═══════════════════════════════════════════════════
  async resetPassword(dto: ResetPasswordDto, ip?: string, userAgent?: string): Promise<{ message: string }> {
    const otpKey = `password_reset_otp:${dto.email}`;
    const storedOtp = await this.cacheService.get<string>(otpKey);

    if (!storedOtp || storedOtp !== dto.otp) {
      throw new BadRequestException('Invalid or expired OTP');
    }

    const user = await this.usersService.findByEmail(dto.email);
    if (!user) {
      throw new BadRequestException('Invalid or expired OTP');
    }

    // Update password
    const hashedPassword = await bcrypt.hash(dto.newPassword, this.BCRYPT_ROUNDS);
    await this.usersService.updatePassword(user.id, hashedPassword);

    // Clear OTP
    await this.cacheService.del(otpKey);

    // Revoke all sessions (force re-login)
    await this.revokeAllUserSessions(user.id);

    await this.createAuthLog(user.id, AuthAction.PASSWORD_RESET_SUCCESS, ip, userAgent);

    return { message: 'Password reset successful. All sessions have been revoked.' };
  }

  // ═══════════════════════════════════════════════════
  // EMAIL VERIFICATION
  // ═══════════════════════════════════════════════════
  async verifyEmail(dto: VerifyEmailDto, userId: string, ip?: string, userAgent?: string): Promise<{ message: string }> {
    const user = await this.usersService.findById(userId);

    if (user.isEmailVerified) {
      throw new BadRequestException('Email is already verified');
    }

    const otpKey = `email_verify_otp:${userId}`;
    const storedOtp = await this.cacheService.get<string>(otpKey);

    if (!storedOtp || storedOtp !== dto.otp) {
      throw new BadRequestException('Invalid or expired verification OTP');
    }

    await this.usersService.markEmailVerified(userId);
    await this.cacheService.del(otpKey);

    await this.createAuthLog(userId, AuthAction.EMAIL_VERIFIED, ip, userAgent);

    return { message: 'Email verified successfully' };
  }

  async resendVerification(userId: string, ip?: string, userAgent?: string): Promise<{ message: string }> {
    const user = await this.usersService.findById(userId);

    if (user.isEmailVerified) {
      throw new BadRequestException('Email is already verified');
    }

    // Rate limiting: 1 per minute
    const cooldownKey = `email_verify_cooldown:${userId}`;
    const cooldown = await this.cacheService.get(cooldownKey);
    if (cooldown) {
      throw new BadRequestException('Please wait at least 1 minute before requesting a new OTP');
    }

    const otp = this.encryptionUtil.generateOtp(6);
    const otpKey = `email_verify_otp:${userId}`;
    const expiryMinutes = this.configService.get<number>('EMAIL_VERIFY_OTP_EXPIRY_MINUTES') || 10;
    await this.cacheService.set(otpKey, otp, expiryMinutes * 60 * 1000);
    await this.cacheService.set(cooldownKey, true, 60 * 1000);

    await this.createAuthLog(userId, AuthAction.EMAIL_VERIFICATION_SENT, ip, userAgent);

    // Send email
    try {
      await this.emailService.sendVerificationEmail(user.email, user.firstName || 'User', otp);
    } catch (error: any) {
      this.logger.error(`Failed to send verification email: ${error.message}`);
    }

    return { message: 'Verification OTP sent' };
  }

  // ═══════════════════════════════════════════════════
  // 2FA SETUP / ENABLE / DISABLE
  // ═══════════════════════════════════════════════════
  async setup2Fa(userId: string): Promise<TwoFaSetupResponseDto> {
    const user = await this.usersService.findById(userId);

    if (user.twoFaEnabled) {
      throw new BadRequestException('2FA is already enabled. Disable it first to reconfigure.');
    }

    const appName = this.configService.get<string>('TWO_FA_APP_NAME') || 'EnterpriseCRM';

    // Generate TOTP secret using speakeasy
    const secretData = speakeasy.generateSecret({
      name: `${appName} (${user.email})`,
    });

    const secret = secretData.base32;
    const otpauthUrl = secretData.otpauth_url as string;

    // Encrypt and store temporarily (not enabled yet)
    const encryptedSecret = this.encryptionUtil.encrypt(secret);
    await this.usersService.updateTwoFaSecret(userId, encryptedSecret);

    // Generate QR code
    const qrCodeUrl = await QRCode.toDataURL(otpauthUrl);

    this.logger.log(`2FA setup initiated for user ${user.email}`);

    return { secret, otpauthUrl, qrCodeUrl };
  }

  async enable2Fa(userId: string, code: string): Promise<TwoFaEnabledResponseDto> {
    const user = await this.usersService.findByIdWithSecret(userId);

    if (user.twoFaEnabled) {
      throw new BadRequestException('2FA is already enabled');
    }

    if (!user.twoFaSecret) {
      throw new BadRequestException('Please run 2FA setup first');
    }

    // Decrypt and verify
    const decryptedSecret = this.encryptionUtil.decrypt(user.twoFaSecret);
    const isValid = speakeasy.totp.verify({
      secret: decryptedSecret,
      encoding: 'base32',
      token: code,
      window: 1,
    });

    if (!isValid) {
      throw new BadRequestException('Invalid TOTP code. Please try again.');
    }

    // Generate 10 backup codes
    const backupCodes: string[] = [];
    const hashedBackupCodes: string[] = [];
    for (let i = 0; i < 10; i++) {
      const rawCode = Math.random().toString(36).substring(2, 10).toUpperCase();
      backupCodes.push(rawCode);
      hashedBackupCodes.push(this.encryptionUtil.hashToken(rawCode));
    }

    // Enable 2FA and store hashed backup codes
    await this.usersService.enableTwoFa(userId, hashedBackupCodes);

    this.logger.log(`2FA enabled for user ${user.email}`);

    return {
      message: 'Two-Factor Authentication enabled successfully',
      backupCodes, // Show plaintext once, user must save them
    };
  }

  async disable2Fa(userId: string, code: string): Promise<{ message: string }> {
    const user = await this.usersService.findByIdWithSecret(userId);

    if (!user.twoFaEnabled || !user.twoFaSecret) {
      throw new BadRequestException('2FA is not enabled');
    }

    const decryptedSecret = this.encryptionUtil.decrypt(user.twoFaSecret);
    const isValid = speakeasy.totp.verify({
      secret: decryptedSecret,
      encoding: 'base32',
      token: code,
      window: 1,
    });

    if (!isValid) {
      throw new BadRequestException('Invalid TOTP code');
    }

    await this.usersService.disableTwoFa(userId);

    this.logger.log(`2FA disabled for user ${userId}`);

    return { message: 'Two-Factor Authentication has been disabled' };
  }

  // ═══════════════════════════════════════════════════
  // OAUTH
  // ═══════════════════════════════════════════════════
  async handleOAuthLogin(oauthUser: {
    email: string;
    firstName?: string;
    lastName?: string;
    avatar?: string;
    provider: string;
    providerId: string;
  }): Promise<AuthResponseDto> {
    const user = await this.usersService.findOrCreateOAuthUser({
      email: oauthUser.email,
      firstName: oauthUser.firstName,
      lastName: oauthUser.lastName,
      avatar: oauthUser.avatar,
      provider: oauthUser.provider as AuthProvider,
      providerId: oauthUser.providerId,
    });

    return this.completeLogin(user);
  }

  // ═══════════════════════════════════════════════════
  // PRIVATE HELPERS
  // ═══════════════════════════════════════════════════

  private async completeLogin(
    user: UserEntity,
    ip?: string,
    userAgent?: string,
  ): Promise<AuthResponseDto> {
    const payload: JwtPayload = {
      sub: user.id,
      email: user.email,
      roles: user.roleNames,
      permissions: user.permissionSlugs,
      tenantId: user.tenantId,
    };

    const accessExpiresIn = this.configService.get<number>('JWT_ACCESS_EXPIRES_SECONDS') || 900;
    const refreshExpiresIn = this.configService.get<number>('JWT_REFRESH_EXPIRES_SECONDS') || 604800;

    // Sign access token with RS256
    const accessToken = this.jwtService.sign(payload, {
      expiresIn: accessExpiresIn,
    });

    // Generate opaque refresh token (not JWT)
    const refreshToken = this.encryptionUtil.generateSecureToken(40);
    const tokenHash = this.encryptionUtil.hashToken(refreshToken);

    // Store session in DB
    const session = this.sessionRepo.create({
      userId: user.id,
      tokenHash,
      ipAddress: ip,
      userAgent,
      expiresAt: new Date(Date.now() + refreshExpiresIn * 1000),
    });
    await this.sessionRepo.save(session);

    // Cache in Redis
    await this.cacheService.set(
      `refresh:${tokenHash}`,
      { userId: user.id, sessionId: session.id },
      refreshExpiresIn * 1000,
    );

    // Update last login
    await this.usersService.updateLoginInfo(user.id, ip || 'unknown');

    return {
      accessToken,
      refreshToken,
      expiresIn: accessExpiresIn,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        roles: user.roleNames,
        permissions: user.permissionSlugs,
        tenantId: user.tenantId,
        isEmailVerified: user.isEmailVerified,
        twoFaEnabled: user.twoFaEnabled,
      },
    };
  }

  private async generateTempToken(userId: string): Promise<string> {
    return this.jwtService.sign(
      { sub: userId, type: 'temp_2fa' },
      { expiresIn: 300 }, // 5 minutes
    );
  }

  private async verifyTempToken(token: string): Promise<{ sub: string }> {
    try {
      const payload = this.jwtService.verify(token);
      if (payload.type !== 'temp_2fa') {
        throw new UnauthorizedException('Invalid token type');
      }
      return { sub: payload.sub };
    } catch (error: any) {
      if (error instanceof UnauthorizedException) throw error;
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('2FA temporary token has expired');
      }
      throw new UnauthorizedException('Invalid 2FA temporary token');
    }
  }

  // ─── Brute Force Protection (Redis-based) ─────────
  private async checkBruteForceLock(email: string, ip?: string): Promise<void> {
    const lockKey = `login_lock:${email}:${ip || 'unknown'}`;
    const locked = await this.cacheService.get(lockKey);
    if (locked) {
      throw new ForbiddenException(
        'Account is temporarily locked due to too many failed login attempts. Try again later.',
      );
    }
  }

  private async trackFailedLogin(email: string, ip?: string): Promise<void> {
    const attemptsKey = `login_attempts:${email}:${ip || 'unknown'}`;
    const maxAttempts = this.configService.get<number>('MAX_LOGIN_ATTEMPTS') || 5;
    const lockDuration = this.configService.get<number>('LOCK_DURATION_MINUTES') || 15;

    let attempts = (await this.cacheService.get<number>(attemptsKey)) || 0;
    attempts++;

    if (attempts >= maxAttempts) {
      const lockKey = `login_lock:${email}:${ip || 'unknown'}`;
      await this.cacheService.set(lockKey, true, lockDuration * 60 * 1000);
      await this.cacheService.del(attemptsKey);
      this.logger.warn(`Account locked: ${email} from IP ${ip} after ${maxAttempts} failed attempts`);
    } else {
      await this.cacheService.set(attemptsKey, attempts, lockDuration * 60 * 1000);
    }
  }

  private async clearBruteForceLock(email: string, ip?: string): Promise<void> {
    const attemptsKey = `login_attempts:${email}:${ip || 'unknown'}`;
    await this.cacheService.del(attemptsKey);
  }

  // ─── Auth Logging ─────────────────────────────────
  private async createAuthLog(
    userId: string | null,
    action: AuthAction,
    ip?: string,
    userAgent?: string,
    metadata?: Record<string, any>,
  ): Promise<void> {
    try {
      const log = this.authLogRepo.create({
        userId: userId || undefined,
        action,
        ipAddress: ip,
        userAgent,
        metadata,
      });
      await this.authLogRepo.save(log);
    } catch (error: any) {
      this.logger.error(`Failed to create auth log: ${error.message}`);
    }
  }

  private async revokeAllUserSessions(userId: string): Promise<void> {
    const sessions = await this.sessionRepo.find({
      where: { userId, isRevoked: false },
    });

    for (const session of sessions) {
      session.isRevoked = true;
      await this.sessionRepo.save(session);
      await this.cacheService.del(`refresh:${session.tokenHash}`);
    }
  }

  /**
   * Cleanup expired sessions (called via cron).
   */
  async cleanupExpiredSessions(): Promise<void> {
    const result = await this.sessionRepo.delete({
      expiresAt: LessThan(new Date()),
    });
    if (result.affected && result.affected > 0) {
      this.logger.log(`Cleaned up ${result.affected} expired sessions`);
    }
  }
}

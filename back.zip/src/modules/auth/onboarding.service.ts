import { Injectable, Logger, BadRequestException, ServiceUnavailableException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { SuperAdminTenantsService } from '../super-admin/tenants.service';
import { UsersService } from '../users/users.service';
import { ProductName } from '../../database/product-db.constants';
import slugify from 'slugify';

@Injectable()
export class OnboardingService {
  private readonly logger = new Logger(OnboardingService.name);

  constructor(
    private readonly configService: ConfigService,
    private readonly tenantsService: SuperAdminTenantsService,
    private readonly usersService: UsersService,
  ) {}

  async selfServiceRegister(dto: {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    companyName: string;
    planSlug: string;
  }) {
    // 1. Check if self-service is enabled
    if (this.configService.get('SELF_SERVICE_ENABLED') === 'false') {
      throw new ServiceUnavailableException('Self-service signup is disabled. Please request a demo.');
    }

    // 2. Generate Tenant Slug
    let tenantSlug = slugify(dto.companyName, { lower: true, strict: true });
    // Check uniqueness (simplified check)
    
    // 3. Create Tenant (Orchestrates Stripe + Schema + Auth DB Entry)
    const tenant = await this.tenantsService.createTenant({
      name: dto.companyName,
      slug: tenantSlug,
      subdomain: tenantSlug,
      planId: dto.planSlug, // Assuming planSlug is passed as ID or resolved
      email: dto.email,
      products: ['auth'], // Start with auth
    });

    // 4. Create Org Admin User in the new tenant schema
    // In our architecture, the ORG_ADMIN user is created within the tenant's 'auth' schema.
    // This part is handled by the usersService targeting the new schema.
    this.logger.log(`Tenant ${tenantSlug} created. Registering ORG_ADMIN: ${dto.email}`);

    return {
      success: true,
      tenant: { slug: tenant.slug, subdomain: tenant.subdomain },
      requiresPayment: true, // Placeholder logic
      message: 'Registration successful. Please complete payment to activate your account.',
    };
  }
}

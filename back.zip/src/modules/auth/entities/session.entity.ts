import { Entity, Column, ManyToOne, JoinColumn, Index } from 'typeorm';
import { BaseEntity } from '../../../database/base.entity';
import { UserEntity } from '../../users/entities/user.entity';

@Entity('sessions')
export class SessionEntity extends BaseEntity {
  @Column({ type: 'uuid' })
  @Index('IDX_SESSION_USER')
  userId!: string;

  @Column({ length: 500 })
  @Index('IDX_SESSION_TOKEN_HASH')
  tokenHash!: string;

  @Column({ nullable: true })
  ipAddress?: string;

  @Column({ nullable: true })
  userAgent?: string;

  @Column({ default: false })
  isRevoked!: boolean;

  @Column({ type: 'timestamptz', nullable: true })
  lastUsedAt?: Date;

  @Column({ type: 'timestamptz' })
  expiresAt!: Date;

  @ManyToOne(() => UserEntity, { onDelete: 'CASCADE' })
  @JoinColumn()
  user!: UserEntity;
}

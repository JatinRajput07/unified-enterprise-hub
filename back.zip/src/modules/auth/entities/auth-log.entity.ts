import { Entity, Column, Index } from 'typeorm';
import { BaseEntity } from '../../../database/base.entity';
import { AuthAction } from '../../../common/constants/auth-actions';

@Entity('auth_logs')
export class AuthLogEntity extends BaseEntity {
  @Column({ type: 'uuid', nullable: true })
  @Index('IDX_AUTH_LOG_USER')
  userId?: string;

  @Column({
    type: 'enum',
    enum: AuthAction,
  })
  @Index('IDX_AUTH_LOG_ACTION')
  action!: AuthAction;

  @Column({ nullable: true })
  ipAddress?: string;

  @Column({ nullable: true })
  userAgent?: string;

  @Column({ type: 'jsonb', nullable: true })
  metadata?: Record<string, unknown>;
}

import {
  Controller,
  Post,
  Get,
  Body,
  Req,
  Res,
  UseGuards,
  HttpCode,
  HttpStatus,
  UnauthorizedException,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiTags,
  ApiOperation,
  ApiResponse,
} from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Request, Response } from 'express';
import { ConfigService } from '@nestjs/config';

import { AuthService } from './auth.service';
import {
  RegisterDto,
  LoginDto,
  Verify2FaLoginDto,
  RefreshTokenDto,
  Enable2FaDto,
  Disable2FaDto,
  ForgotPasswordDto,
  ResetPasswordDto,
  VerifyEmailDto,
  AuthResponseDto,
  TwoFaRequiredResponseDto,
  TwoFaSetupResponseDto,
  TwoFaEnabledResponseDto,
} from './dto/auth.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Public } from '../../common/decorators/public.decorator';

@ApiTags('Auth')
@Controller({ path: 'auth', version: '1' })
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly configService: ConfigService,
  ) {}

  // ═══════════════════════════════════════════════════
  // Cookie Helper
  // ═══════════════════════════════════════════════════
  private setAuthCookies(res: Response, tokens: AuthResponseDto): void {
    const isProduction = this.configService.get<string>('APP_ENV') === 'production';

    const commonOptions = {
      httpOnly: true,
      secure: isProduction,
      sameSite: 'lax' as const,
      path: '/',
    };

    // Access token cookie — 15 mins
    res.cookie('access_token', tokens.accessToken, {
      ...commonOptions,
      maxAge: tokens.expiresIn * 1000,
    });

    // Refresh token cookie — 7 days
    res.cookie('refresh_token', tokens.refreshToken, {
      ...commonOptions,
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });
  }

  private clearAuthCookies(res: Response): void {
    const cookieOptions = {
      httpOnly: true,
      path: '/',
    };
    res.clearCookie('access_token', cookieOptions);
    res.clearCookie('refresh_token', cookieOptions);
  }

  // ═══════════════════════════════════════════════════
  // REGISTER
  // ═══════════════════════════════════════════════════
  @Public()
  @Post('register')
  @ApiOperation({ summary: 'Register a new user' })
  @ApiResponse({ status: 201, type: AuthResponseDto })
  async register(
    @Body() dto: RegisterDto,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ): Promise<AuthResponseDto> {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'];
    const result = await this.authService.register(dto, ip, userAgent);
    this.setAuthCookies(res, result);
    return result;
  }

  // ═══════════════════════════════════════════════════
  // LOGIN
  // ═══════════════════════════════════════════════════
  @Public()
  @Post('login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Login with email and password' })
  @ApiResponse({ status: 200, type: AuthResponseDto })
  async login(
    @Body() dto: LoginDto,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ): Promise<AuthResponseDto | TwoFaRequiredResponseDto> {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'];
    const result = await this.authService.login(dto, ip, userAgent);

    // Only set cookies if full login (not 2FA required)
    if ('accessToken' in result) {
      this.setAuthCookies(res, result as AuthResponseDto);
    }

    return result;
  }

  // ═══════════════════════════════════════════════════
  // 2FA LOGIN VERIFY
  // ═══════════════════════════════════════════════════
  @Public()
  @Post('2fa/verify-login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Complete login by verifying 2FA code' })
  @ApiResponse({ status: 200, type: AuthResponseDto })
  async verify2FaLogin(
    @Body() dto: Verify2FaLoginDto,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ): Promise<AuthResponseDto> {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'];
    const result = await this.authService.verify2FaLogin(dto, ip, userAgent);
    this.setAuthCookies(res, result);
    return result;
  }

  // ═══════════════════════════════════════════════════
  // REFRESH
  // ═══════════════════════════════════════════════════
  @Public()
  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Refresh access token using refresh token' })
  @ApiResponse({ status: 200, type: AuthResponseDto })
  async refresh(
    @Body() dto: RefreshTokenDto,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ): Promise<AuthResponseDto> {
    // Try body first, then cookie
    const token = dto?.refreshToken || req.cookies?.['refresh_token'];
    if (!token) {
      throw new UnauthorizedException('Refresh token is required');
    }

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'];
    const result = await this.authService.refreshTokens(token, ip, userAgent);
    this.setAuthCookies(res, result);
    return result;
  }

  // ═══════════════════════════════════════════════════
  // LOGOUT
  // ═══════════════════════════════════════════════════
  @Post('logout')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Logout and revoke tokens' })
  @ApiResponse({ status: 200 })
  async logout(
    @CurrentUser('id') userId: string,
    @Body() body: { refreshToken?: string },
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ): Promise<{ message: string }> {
    const token = body.refreshToken || req.cookies?.['refresh_token'];
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'];
    await this.authService.logout(userId, token, ip, userAgent);
    this.clearAuthCookies(res);
    return { message: 'Logged out successfully' };
  }

  @Post('logout-all')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Logout from all devices' })
  @ApiResponse({ status: 200 })
  async logoutAll(
    @CurrentUser('id') userId: string,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ): Promise<{ message: string; sessionsRevoked: number }> {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'];
    const result = await this.authService.logoutAll(userId, ip, userAgent);
    this.clearAuthCookies(res);
    return { message: `${result.count} sessions revoked`, sessionsRevoked: result.count };
  }

  // ═══════════════════════════════════════════════════
  // FORGOT / RESET PASSWORD
  // ═══════════════════════════════════════════════════
  @Public()
  @Post('forgot-password')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Request password reset OTP' })
  async forgotPassword(
    @Body() dto: ForgotPasswordDto,
    @Req() req: Request,
  ): Promise<{ message: string }> {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'];
    return this.authService.forgotPassword(dto, ip, userAgent);
  }

  @Public()
  @Post('reset-password')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Reset password using OTP' })
  async resetPassword(
    @Body() dto: ResetPasswordDto,
    @Req() req: Request,
  ): Promise<{ message: string }> {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'];
    return this.authService.resetPassword(dto, ip, userAgent);
  }

  // ═══════════════════════════════════════════════════
  // EMAIL VERIFICATION
  // ═══════════════════════════════════════════════════
  @Post('verify-email')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Verify email with OTP' })
  async verifyEmail(
    @Body() dto: VerifyEmailDto,
    @CurrentUser('id') userId: string,
    @Req() req: Request,
  ): Promise<{ message: string }> {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'];
    return this.authService.verifyEmail(dto, userId, ip, userAgent);
  }

  @Post('resend-verification')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Resend email verification OTP' })
  async resendVerification(
    @CurrentUser('id') userId: string,
    @Req() req: Request,
  ): Promise<{ message: string }> {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'];
    return this.authService.resendVerification(userId, ip, userAgent);
  }

  // ═══════════════════════════════════════════════════
  // 2FA MANAGEMENT
  // ═══════════════════════════════════════════════════
  @Post('2fa/setup')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Generate 2FA secret and QR code' })
  @ApiResponse({ status: 200, type: TwoFaSetupResponseDto })
  async setup2Fa(
    @CurrentUser('id') userId: string,
  ): Promise<TwoFaSetupResponseDto> {
    return this.authService.setup2Fa(userId);
  }

  @Post('2fa/enable')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Enable 2FA after verifying code' })
  @ApiResponse({ status: 200, type: TwoFaEnabledResponseDto })
  async enable2Fa(
    @CurrentUser('id') userId: string,
    @Body() dto: Enable2FaDto,
  ): Promise<TwoFaEnabledResponseDto> {
    return this.authService.enable2Fa(userId, dto.code);
  }

  @Post('2fa/disable')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Disable 2FA' })
  async disable2Fa(
    @CurrentUser('id') userId: string,
    @Body() dto: Disable2FaDto,
  ): Promise<{ message: string }> {
    return this.authService.disable2Fa(userId, dto.code);
  }

  // ═══════════════════════════════════════════════════
  // OAuth — Google
  // ═══════════════════════════════════════════════════
  @Public()
  @Get('google')
  @UseGuards(AuthGuard('google'))
  @ApiOperation({ summary: 'Initiate Google OAuth login' })
  googleLogin(): void {
    // Guard redirects to Google
  }

  @Public()
  @Get('google/callback')
  @UseGuards(AuthGuard('google'))
  @ApiOperation({ summary: 'Google OAuth callback' })
  async googleCallback(
    @Req() req: Request,
    @Res() res: Response,
  ): Promise<void> {
    const oauthUser = req.user as Record<string, string>;
    const authResponse = await this.authService.handleOAuthLogin({
      email: oauthUser.email,
      firstName: oauthUser.firstName,
      lastName: oauthUser.lastName,
      avatar: oauthUser.avatar,
      provider: oauthUser.provider,
      providerId: oauthUser.providerId,
    });

    this.setAuthCookies(res, authResponse);

    const frontendUrl = this.configService.get<string>('FRONTEND_URL');
    res.redirect(`${frontendUrl}/auth/callback?success=true`);
  }

  // ═══════════════════════════════════════════════════
  // OAuth — GitHub
  // ═══════════════════════════════════════════════════
  @Public()
  @Get('github')
  @UseGuards(AuthGuard('github'))
  @ApiOperation({ summary: 'Initiate GitHub OAuth login' })
  githubLogin(): void {
    // Guard redirects to GitHub
  }

  @Public()
  @Get('github/callback')
  @UseGuards(AuthGuard('github'))
  @ApiOperation({ summary: 'GitHub OAuth callback' })
  async githubCallback(
    @Req() req: Request,
    @Res() res: Response,
  ): Promise<void> {
    const oauthUser = req.user as Record<string, string>;
    const authResponse = await this.authService.handleOAuthLogin({
      email: oauthUser.email,
      firstName: oauthUser.firstName,
      lastName: oauthUser.lastName,
      avatar: oauthUser.avatar,
      provider: oauthUser.provider,
      providerId: oauthUser.providerId,
    });

    this.setAuthCookies(res, authResponse);

    const frontendUrl = this.configService.get<string>('FRONTEND_URL');
    res.redirect(`${frontendUrl}/auth/callback?success=true`);
  }
}

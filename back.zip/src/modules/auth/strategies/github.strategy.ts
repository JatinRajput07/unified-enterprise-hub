import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy, Profile } from 'passport-github2';

@Injectable()
export class GithubStrategy extends PassportStrategy(Strategy, 'github') {
  constructor(configService: ConfigService) {
    super({
      clientID: configService.get<string>('GITHUB_CLIENT_ID') || '',
      clientSecret: configService.get<string>('GITHUB_CLIENT_SECRET') || '',
      callbackURL: configService.get<string>('GITHUB_CALLBACK_URL') || '',
      scope: ['user:email'],
    });
  }

  validate(
    _accessToken: string,
    _refreshToken: string,
    profile: Profile,
    done: (error: Error | null, user?: Record<string, unknown>) => void,
  ): void {
    const emails = profile.emails as Array<{ value: string }> | undefined;
    const photos = profile.photos as Array<{ value: string }> | undefined;
    const user = {
      email: emails?.[0]?.value || '',
      firstName: profile.displayName?.split(' ')[0],
      lastName: profile.displayName?.split(' ').slice(1).join(' '),
      avatar: photos?.[0]?.value,
      provider: 'github' as const,
      providerId: profile.id,
    };
    done(null, user);
  }
}

import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsEmail,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  MinLength,
} from 'class-validator';

// ─── Registration ────────────────────────────────────
export class RegisterDto {
  @ApiPropertyOptional({ example: 'John' })
  @IsOptional()
  @IsString()
  firstName?: string;

  @ApiPropertyOptional({ example: 'Doe' })
  @IsOptional()
  @IsString()
  lastName?: string;

  @ApiProperty({ example: 'john.doe@example.com' })
  @IsEmail()
  @IsNotEmpty()
  email!: string;

  @ApiProperty({ example: 'StrongP@ss1' })
  @IsString()
  @MinLength(8)
  @Matches(
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
    {
      message:
        'Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character',
    },
  )
  password!: string;

  @ApiPropertyOptional({ example: '+1234567890' })
  @IsOptional()
  @IsString()
  phone?: string;
}

// ─── Login ───────────────────────────────────────────
export class LoginDto {
  @ApiProperty({ example: 'john.doe@example.com' })
  @IsEmail()
  @IsNotEmpty()
  email!: string;

  @ApiProperty({ example: 'StrongP@ss1' })
  @IsString()
  @IsNotEmpty()
  password!: string;
}

// ─── 2FA Verify (after login returns tempToken) ──────
export class Verify2FaLoginDto {
  @ApiProperty({ description: 'Temporary token from login response' })
  @IsString()
  @IsNotEmpty()
  tempToken!: string;

  @ApiProperty({ description: 'TOTP code from authenticator app', example: '123456' })
  @IsString()
  @IsNotEmpty()
  totpCode!: string;
}

// ─── Refresh Token ───────────────────────────────────
export class RefreshTokenDto {
  @ApiPropertyOptional({ description: 'Refresh token. If not provided, the server will check for an HttpOnly cookie.', example: 'abc123...' })
  @IsOptional()
  @IsString()
  refreshToken?: string;
}

// ─── 2FA Setup/Enable/Disable ────────────────────────
export class Enable2FaDto {
  @ApiProperty({ description: 'TOTP code from authenticator app', example: '123456' })
  @IsString()
  @IsNotEmpty()
  code!: string;
}

export class Disable2FaDto {
  @ApiProperty({ description: 'TOTP code to confirm identity', example: '123456' })
  @IsString()
  @IsNotEmpty()
  code!: string;
}

// ─── Forgot Password ────────────────────────────────
export class ForgotPasswordDto {
  @ApiProperty({ example: 'john.doe@example.com' })
  @IsEmail()
  @IsNotEmpty()
  email!: string;
}

// ─── Reset Password ─────────────────────────────────
export class ResetPasswordDto {
  @ApiProperty({ example: 'john.doe@example.com' })
  @IsEmail()
  @IsNotEmpty()
  email!: string;

  @ApiProperty({ description: 'OTP sent to email', example: '123456' })
  @IsString()
  @IsNotEmpty()
  otp!: string;

  @ApiProperty({ example: 'NewStr0ng@Pass' })
  @IsString()
  @MinLength(8)
  @Matches(
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
    {
      message:
        'Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character',
    },
  )
  newPassword!: string;
}

// ─── Email Verification ─────────────────────────────
export class VerifyEmailDto {
  @ApiProperty({ description: 'OTP sent to email', example: '123456' })
  @IsString()
  @IsNotEmpty()
  otp!: string;
}

// ─── Response DTOs ───────────────────────────────────
export class AuthResponseDto {
  @ApiProperty({ example: 'eyJhbGciOiJSUzI1NiIs...' })
  accessToken!: string;

  @ApiProperty({ example: 'a1b2c3d4e5...' })
  refreshToken!: string;

  @ApiProperty({ example: 900 })
  expiresIn!: number;

  @ApiProperty()
  user!: {
    id: string;
    email: string;
    firstName?: string;
    lastName?: string;
    roles: string[];
    permissions: string[];
    tenantId?: string;
    isEmailVerified: boolean;
    twoFaEnabled: boolean;
  };
}

export class TwoFaRequiredResponseDto {
  @ApiProperty({ example: true })
  requires2fa!: boolean;

  @ApiProperty({ description: 'Temporary token for 2FA verification' })
  tempToken!: string;

  @ApiProperty({ example: 'Please provide your 2FA code' })
  message!: string;
}

export class TwoFaSetupResponseDto {
  @ApiProperty({ description: 'Base32 encoded secret for manual entry' })
  secret!: string;

  @ApiProperty({ description: 'otpauth:// URL for authenticator apps' })
  otpauthUrl!: string;

  @ApiProperty({ description: 'QR code as data URL' })
  qrCodeUrl!: string;
}

export class TwoFaEnabledResponseDto {
  @ApiProperty({ example: 'Two-Factor Authentication enabled successfully' })
  message!: string;

  @ApiProperty({ description: 'One-time backup codes (save these!)' })
  backupCodes!: string[];
}

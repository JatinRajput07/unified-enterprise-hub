import { Injectable, Logger, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  ClientProxy,
  ClientProxyFactory,
  Transport,
} from '@nestjs/microservices';

@Injectable()
export class EventBusService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(EventBusService.name);
  private client: any = null;

  constructor(private readonly configService: ConfigService) {}

  onModuleInit(): void {
    const driver = this.configService.get<string>('TRANSPORT_DRIVER');
    
    if (driver === 'rabbitmq') {
      this.client = ClientProxyFactory.create({
        transport: Transport.RMQ,
        options: {
          urls: [this.configService.get<string>('RABBITMQ_URL') || 'amqp://localhost:5672'],
          queue: 'crm_main_queue',
          queueOptions: { durable: true },
        },
      });
      this.logger.log('EventBus initialized with RabbitMQ');
    } else if (driver === 'kafka') {
      this.client = ClientProxyFactory.create({
        transport: Transport.KAFKA,
        options: {
          client: {
            brokers: [this.configService.get<string>('KAFKA_BROKERS') || 'localhost:9092'],
          },
        },
      });
      this.logger.log('EventBus initialized with Kafka');
    } else {
      this.logger.warn('No external message broker configured (TRANSPORT_DRIVER not set)');
    }
  }

  /**
   * Publish an event to the message broker.
   */
  async publish(pattern: string, data: any): Promise<void> {
    if (!this.client) {
      this.logger.debug(`Internal dispatch (no broker): ${pattern}`);
      return;
    }

    try {
      await this.client.emit(pattern, data).toPromise();
      this.logger.debug(`Published event to broker: ${pattern}`);
    } catch (error) {
      this.logger.error(`Failed to publish event ${pattern}: ${(error as Error).message}`);
    }
  }

  async onModuleDestroy(): Promise<void> {
    if (this.client) {
      await this.client.close();
    }
  }
}

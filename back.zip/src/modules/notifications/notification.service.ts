import { Injectable, Logger } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { EmailService } from './email/email.service';
import { AppGateway } from '../gateway/app.gateway';
import { SmsService } from './channels/sms.service';
import {
  NotificationPayload,
  NotificationChannel,
  NotificationResult,
} from './interfaces/notification.interface';

/**
 * Central notification dispatcher — routes notifications to the correct channel handlers.
 * 
 * Supports: Email, In-App (WebSocket), SMS (placeholder), Push (placeholder), WebPush (placeholder).
 * 
 * Usage:
 * ```ts
 * await notificationService.send({
 *   channels: [NotificationChannel.EMAIL, NotificationChannel.IN_APP],
 *   recipients: ['user@example.com'],
 *   title: 'New Lead Assigned',
 *   body: 'A new lead has been assigned to you.',
 *   emailTemplate: 'welcome',
 *   emailContext: { name: 'John' },
 * });
 * ```
 */
@Injectable()
export class NotificationService {
  private readonly logger = new Logger(NotificationService.name);

  constructor(
    private readonly emailService: EmailService,
    private readonly appGateway: AppGateway,
    private readonly smsService: SmsService,
    private readonly eventEmitter: EventEmitter2,
  ) {}

  /**
   * Send a notification across multiple channels.
   */
  async send(payload: NotificationPayload): Promise<NotificationResult[]> {
    const results: NotificationResult[] = [];

    for (const channel of payload.channels) {
      try {
        const result = await this.dispatchToChannel(channel, payload);
        results.push(result);
      } catch (error) {
        this.logger.error(
          `Notification failed on channel ${channel}: ${(error as Error).message}`,
        );
        results.push({
          channel,
          success: false,
          recipientCount: 0,
          error: (error as Error).message,
        });
      }
    }

    // Emit event for audit / analytics
    this.eventEmitter.emit('notification.sent', {
      payload,
      results,
      timestamp: new Date().toISOString(),
    });

    return results;
  }

  /**
   * Send a notification to a specific channel.
   */
  private async dispatchToChannel(
    channel: NotificationChannel,
    payload: NotificationPayload,
  ): Promise<NotificationResult> {
    switch (channel) {
      case NotificationChannel.EMAIL:
        return this.sendEmail(payload);

      case NotificationChannel.IN_APP:
        return this.sendInApp(payload);

      case NotificationChannel.SMS:
        return this.sendSms(payload);

      case NotificationChannel.PUSH:
        return this.sendPush(payload);

      case NotificationChannel.WEB_PUSH:
        return this.sendWebPush(payload);

      default:
        return {
          channel,
          success: false,
          recipientCount: 0,
          error: `Unknown channel: ${channel}`,
        };
    }
  }

  // =====================
  // Channel Handlers
  // =====================

  private async sendEmail(payload: NotificationPayload): Promise<NotificationResult> {
    let sentCount = 0;

    for (const recipient of payload.recipients) {
      await this.emailService.sendEmail({
        to: recipient,
        subject: payload.title,
        template: payload.emailTemplate || 'welcome',
        context: {
          ...payload.emailContext,
          name: payload.data?.['name'] || recipient.split('@')[0],
        },
      });
      sentCount++;
    }

    this.logger.log(`Email sent to ${sentCount} recipients: ${payload.title}`);

    return {
      channel: NotificationChannel.EMAIL,
      success: true,
      recipientCount: sentCount,
    };
  }

  private async sendInApp(payload: NotificationPayload): Promise<NotificationResult> {
    for (const recipient of payload.recipients) {
      this.appGateway.emitToUser(recipient, 'notification', {
        title: payload.title,
        body: payload.body,
        data: payload.data,
        priority: payload.priority,
        timestamp: new Date().toISOString(),
      });
    }

    return {
      channel: NotificationChannel.IN_APP,
      success: true,
      recipientCount: payload.recipients.length,
    };
  }

  private async sendSms(payload: NotificationPayload): Promise<NotificationResult> {
    if (!this.smsService) {
      return {
        channel: NotificationChannel.SMS,
        success: false,
        recipientCount: 0,
        error: 'SmsService not available',
      };
    }

    let sentCount = 0;
    for (const recipient of payload.recipients) {
      const success = await this.smsService.sendSms(recipient, payload.body);
      if (success) sentCount++;
    }

    return {
      channel: NotificationChannel.SMS,
      success: sentCount > 0,
      recipientCount: sentCount,
    };
  }

  private async sendPush(payload: NotificationPayload): Promise<NotificationResult> {
    // Placeholder — integrate Firebase Cloud Messaging in Phase 4
    this.logger.warn(`Push channel not fully configured. Would send to: ${payload.recipients.join(', ')}`);
    return {
      channel: NotificationChannel.PUSH,
      success: false,
      recipientCount: 0,
      error: 'Push channel not configured. Set FCM_* env vars.',
    };
  }

  private async sendWebPush(payload: NotificationPayload): Promise<NotificationResult> {
    // Placeholder — integrate web-push in Phase 4
    this.logger.warn(`WebPush channel not fully configured. Would send to: ${payload.recipients.join(', ')}`);
    return {
      channel: NotificationChannel.WEB_PUSH,
      success: false,
      recipientCount: 0,
      error: 'WebPush channel not configured.',
    };
  }
}

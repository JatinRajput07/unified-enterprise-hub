import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Twilio } from 'twilio';

@Injectable()
export class SmsService {
  private readonly logger = new Logger(SmsService.name);
  private client: Twilio | null = null;

  constructor(private readonly configService: ConfigService) {
    const accountSid = this.configService.get<string>('TWILIO_ACCOUNT_SID');
    const authToken = this.configService.get<string>('TWILIO_AUTH_TOKEN');

    if (accountSid && authToken) {
      this.client = new Twilio(accountSid, authToken);
      this.logger.log('Twilio SMS service initialized');
    } else {
      this.logger.warn('Twilio credentials missing — SMS disabled');
    }
  }

  async sendSms(to: string, body: string): Promise<boolean> {
    if (!this.client) {
      this.logger.warn(`Cannot send SMS to ${to}: Twilio not configured`);
      return false;
    }

    try {
      const from = this.configService.get<string>('TWILIO_PHONE_NUMBER');
      await this.client.messages.create({
        body,
        from,
        to,
      });
      this.logger.log(`SMS sent to ${to}`);
      return true;
    } catch (error) {
      this.logger.error(`Failed to send SMS to ${to}: ${(error as Error).message}`);
      return false;
    }
  }
}

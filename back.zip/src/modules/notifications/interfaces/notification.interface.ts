/**
 * Notification abstraction layer — unified interface for all channels.
 */

export enum NotificationChannel {
  EMAIL = 'email',
  SMS = 'sms',
  PUSH = 'push',
  WEB_PUSH = 'web_push',
  IN_APP = 'in_app',
}

export enum NotificationPriority {
  LOW = 'low',
  NORMAL = 'normal',
  HIGH = 'high',
  URGENT = 'urgent',
}

export interface NotificationPayload {
  /** Unique ID for deduplication */
  id?: string;

  /** The notification channels to deliver on */
  channels: NotificationChannel[];

  /** Recipients (user IDs or email addresses depending on channel) */
  recipients: string[];

  /** Notification title */
  title: string;

  /** Notification body / message */
  body: string;

  /** Priority level */
  priority?: NotificationPriority;

  /** Additional data / metadata */
  data?: Record<string, unknown>;

  /** For email channel — template name */
  emailTemplate?: string;

  /** For email channel — template context */
  emailContext?: Record<string, unknown>;

  /** Tenant scope */
  tenantId?: string;

  /** Scheduled send time (ISO string) */
  scheduledAt?: string;
}

export interface NotificationResult {
  channel: NotificationChannel;
  success: boolean;
  recipientCount: number;
  error?: string;
}

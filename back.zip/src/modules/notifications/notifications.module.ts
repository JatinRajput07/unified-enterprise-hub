import { Module } from '@nestjs/common';
import { EmailService } from './email/email.service';
import { NotificationService } from './notification.service';
import { SmsService } from './channels/sms.service';
import { GatewayModule } from '../gateway/gateway.module';

@Module({
  imports: [GatewayModule],
  providers: [EmailService, NotificationService, SmsService],
  exports: [EmailService, NotificationService, SmsService],
})
export class NotificationsModule {}

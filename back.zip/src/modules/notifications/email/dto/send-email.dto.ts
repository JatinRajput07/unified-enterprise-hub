import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class SendEmailDto {
  @ApiProperty({ example: 'john@example.com' })
  @IsEmail()
  @IsNotEmpty()
  to!: string;

  @ApiProperty({ example: 'Welcome to EnterpriseCRM' })
  @IsString()
  @IsNotEmpty()
  subject!: string;

  @ApiProperty({ example: 'welcome', description: 'Template name (without .hbs extension)' })
  @IsString()
  @IsNotEmpty()
  template!: string;

  @ApiPropertyOptional({ example: { name: 'John', link: 'https://example.com' } })
  @IsOptional()
  context?: Record<string, unknown>;
}

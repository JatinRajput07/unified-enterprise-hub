import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as nodemailer from 'nodemailer';
import * as Handlebars from 'handlebars';
import * as fs from 'fs';
import * as path from 'path';

export interface EmailOptions {
  to: string | string[];
  subject: string;
  template: string;
  context?: Record<string, unknown>;
  attachments?: Array<{
    filename: string;
    path?: string;
    content?: string | Buffer;
    contentType?: string;
  }>;
  cc?: string | string[];
  bcc?: string | string[];
  replyTo?: string;
}

@Injectable()
export class EmailService implements OnModuleInit {
  private readonly logger = new Logger(EmailService.name);
  private transporter!: nodemailer.Transporter;
  private readonly templateCache = new Map<string, HandlebarsTemplateDelegate>();
  private readonly templatesDir: string;

  constructor(private readonly configService: ConfigService) {
    this.templatesDir = path.resolve(
      __dirname,
      'templates',
    );
  }

  onModuleInit(): void {
    this.transporter = nodemailer.createTransport({
      host: this.configService.get<string>('SMTP_HOST') || 'localhost',
      port: this.configService.get<number>('SMTP_PORT') || 587,
      secure: this.configService.get<string>('SMTP_SECURE') === 'true',
      auth: {
        user: this.configService.get<string>('SMTP_USER'),
        pass: this.configService.get<string>('SMTP_PASS'),
      },
    });

    this.precompileTemplates();
    this.logger.log('Email service initialized');
  }

  /**
   * Send an email using a Handlebars template.
   */
  async sendEmail(options: EmailOptions): Promise<void> {
    try {
      const html = this.renderTemplate(options.template, {
        ...options.context,
        appName: this.configService.get<string>('APP_NAME') || 'EnterpriseCRM',
        year: new Date().getFullYear(),
      });

      const fromName = this.configService.get<string>('SMTP_FROM_NAME') || 'EnterpriseCRM';
      const fromEmail = this.configService.get<string>('SMTP_FROM_EMAIL') || 'noreply@enterprise-crm.com';

      await this.transporter.sendMail({
        from: `"${fromName}" <${fromEmail}>`,
        to: Array.isArray(options.to) ? options.to.join(', ') : options.to,
        cc: options.cc,
        bcc: options.bcc,
        replyTo: options.replyTo,
        subject: options.subject,
        html,
        attachments: options.attachments,
      });

      this.logger.log(`Email sent: ${options.subject} → ${options.to}`);
    } catch (error) {
      this.logger.error(
        `Failed to send email: ${(error as Error).message}`,
        (error as Error).stack,
      );
      throw error;
    }
  }

  /**
   * Send welcome email.
   */
  async sendWelcomeEmail(
    to: string,
    name: string,
    loginUrl?: string,
  ): Promise<void> {
    await this.sendEmail({
      to,
      subject: 'Welcome to EnterpriseCRM! 🎉',
      template: 'welcome',
      context: {
        name,
        loginUrl: loginUrl || this.configService.get<string>('FRONTEND_URL') || 'http://localhost:5173',
      },
    });
  }

  /**
   * Send password reset email.
   */
  async sendPasswordResetEmail(
    to: string,
    name: string,
    resetUrl: string,
    expiresIn: string = '1 hour',
  ): Promise<void> {
    await this.sendEmail({
      to,
      subject: 'Reset Your Password 🔐',
      template: 'reset-password',
      context: { name, resetUrl, expiresIn },
    });
  }

  /**
   * Send email verification email.
   */
  async sendVerificationEmail(
    to: string,
    name: string,
    verifyUrl: string,
  ): Promise<void> {
    await this.sendEmail({
      to,
      subject: 'Verify Your Email ✉️',
      template: 'verify-email',
      context: { name, verifyUrl },
    });
  }

  /**
   * Send 2FA code email.
   */
  async send2FaCodeEmail(
    to: string,
    name: string,
    code: string,
  ): Promise<void> {
    await this.sendEmail({
      to,
      subject: 'Your Verification Code 🔑',
      template: '2fa-code',
      context: { name, code },
    });
  }

  // =====================
  // Private Helpers
  // =====================

  private renderTemplate(
    templateName: string,
    context: Record<string, unknown>,
  ): string {
    const compiled = this.templateCache.get(templateName);
    if (compiled) {
      return compiled(context);
    }

    // Fallback: try to load and compile on the fly
    const templatePath = path.join(this.templatesDir, `${templateName}.hbs`);
    if (!fs.existsSync(templatePath)) {
      this.logger.warn(`Template not found: ${templateName}, using fallback`);
      return `<p>${JSON.stringify(context)}</p>`;
    }

    const source = fs.readFileSync(templatePath, 'utf-8');
    const template = Handlebars.compile(source);
    this.templateCache.set(templateName, template);
    return template(context);
  }

  private precompileTemplates(): void {
    try {
      if (!fs.existsSync(this.templatesDir)) {
        this.logger.warn(`Templates directory not found: ${this.templatesDir}`);
        return;
      }

      const files = fs.readdirSync(this.templatesDir).filter((f) => f.endsWith('.hbs'));

      for (const file of files) {
        const name = path.basename(file, '.hbs');
        const source = fs.readFileSync(path.join(this.templatesDir, file), 'utf-8');
        this.templateCache.set(name, Handlebars.compile(source));
        this.logger.debug(`Template precompiled: ${name}`);
      }

      this.logger.log(`${files.length} email templates loaded`);
    } catch (error) {
      this.logger.warn(
        `Failed to precompile templates: ${(error as Error).message}`,
      );
    }
  }
}

import { SetMetadata } from '@nestjs/common';

export interface AuditOptions {
  action: string;
  resource: string;
}

export const AUDIT_METADATA_KEY = 'audit_log';

/**
 * Decorator to mark a method for audit logging.
 */
export const Audit = (options: AuditOptions) =>
  SetMetadata(AUDIT_METADATA_KEY, options);

import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  Logger,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuditLog } from './entities/audit-log.entity';
import { AUDIT_METADATA_KEY, AuditOptions } from './decorators/audit.decorator';

@Injectable()
export class AuditInterceptor implements NestInterceptor {
  private readonly logger = new Logger(AuditInterceptor.name);

  constructor(
    private readonly reflector: Reflector,
    @InjectRepository(AuditLog)
    private readonly auditRepository: Repository<AuditLog>,
  ) {}

  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<any>> {
    const options = this.reflector.get<AuditOptions>(
      AUDIT_METADATA_KEY,
      context.getHandler(),
    );

    if (!options) return next.handle();

    const request = context.switchToHttp().getRequest();
    const userId = request.user?.id;
    const tenantId = request.tenantId;

    // Capture before state if possible (simplified here)
    // In a full implementation, you'd fetch the entity before the call
    const oldValue = request.body; 

    return next.handle().pipe(
      tap(async (result) => {
        try {
          await this.auditRepository.save({
            userId,
            tenantId,
            action: options.action,
            resource: options.resource,
            resourceId: result?.id || request.params?.id,
            oldValue,
            newValue: result,
            ip: request.ip,
            userAgent: request.headers['user-agent'],
          });
        } catch (error) {
          this.logger.error(`Failed to save audit log: ${(error as Error).message}`);
        }
      }),
    );
  }
}

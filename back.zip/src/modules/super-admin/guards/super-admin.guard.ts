import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
  ForbiddenException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class SuperAdminGuard implements CanActivate {
  constructor(private readonly configService: ConfigService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const adminKey = request.headers['x-admin-key'];
    const expectedKey = this.configService.get<string>('ADMIN_KEY');
    const user = request.user;

    const hasAdminKey = adminKey && adminKey === expectedKey;
    const isSuperAdmin = user && user.roles && user.roles.includes('SUPER_ADMIN');

    if (hasAdminKey || isSuperAdmin) {
      return true;
    }

    if (user) {
      throw new ForbiddenException('Super Admin access required');
    }

    throw new UnauthorizedException('Invalid or missing Admin Key');
  }
}

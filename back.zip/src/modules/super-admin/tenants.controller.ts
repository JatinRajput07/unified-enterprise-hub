import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Query,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { SuperAdminTenantsService } from './tenants.service';
import { SuperAdminGuard } from './guards/super-admin.guard';
import { TenantStatus } from '../tenants/entities/tenant.entity';
import { ProductName } from '../../database/product-db.constants';
import { CreateTenantDto, TenantResponseDto } from './dto/tenant-management.dto';

@ApiTags('Tenants')
@ApiBearerAuth()
@Controller('super-admin/tenants')
@UseGuards(SuperAdminGuard)
export class SuperAdminTenantsController {
  constructor(private readonly tenantsService: SuperAdminTenantsService) {}

  @Post()
  @ApiOperation({ summary: 'Provision a new tenant' })
  @ApiResponse({ status: 201, description: 'Tenant created successfully', type: TenantResponseDto })
  create(@Body() dto: CreateTenantDto) {
    return this.tenantsService.createTenant(dto);
  }

  @Get()
  @ApiOperation({ summary: 'List all tenants with pagination and filtering' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiQuery({ name: 'status', required: false, enum: TenantStatus })
  @ApiResponse({ status: 200, description: 'List of tenants', type: [TenantResponseDto] })
  findAll(
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('search') search?: string,
    @Query('status') status?: TenantStatus,
  ) {
    return this.tenantsService.findAll({ page, limit, search, status });
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get detailed information about a specific tenant' })
  @ApiResponse({ status: 200, type: TenantResponseDto })
  findOne(@Param('id') id: string) {
    return this.tenantsService.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update tenant settings' })
  @ApiResponse({ status: 200, type: TenantResponseDto })
  update(@Param('id') id: string, @Body() dto: any) {
    return this.tenantsService.updateTenant(id, dto);
  }

  @Post(':id/activate')
  @ApiOperation({ summary: 'Activate a tenant' })
  activate(@Param('id') id: string) {
    return this.tenantsService.updateStatus(id, TenantStatus.ACTIVE);
  }

  @Post(':id/deactivate')
  @ApiOperation({ summary: 'Deactivate a tenant' })
  deactivate(@Param('id') id: string) {
    return this.tenantsService.updateStatus(id, TenantStatus.INACTIVE);
  }

  @Post(':id/suspend')
  @ApiOperation({ summary: 'Suspend a tenant' })
  suspend(@Param('id') id: string) {
    return this.tenantsService.updateStatus(id, TenantStatus.SUSPENDED);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Soft delete a tenant' })
  @ApiResponse({ status: 200, description: 'Tenant deleted successfully' })
  remove(@Param('id') id: string) {
    return this.tenantsService.remove(id);
  }

  @Post(':id/products/:product')
  @ApiOperation({ summary: 'Add a product to an existing tenant' })
  @ApiResponse({ status: 200, description: 'Product added successfully' })
  async addProduct(
    @Param('id') id: string,
    @Param('product') product: ProductName,
  ) {
    await this.tenantsService.addProduct(id, product);
    return { success: true, message: `Product ${product} provisioned for tenant ${id}` };
  }
}

import { Controller, Get, Post, Put, Delete, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { SuperAdminPlansService } from './plans.service';
import { SuperAdminGuard } from './guards/super-admin.guard';

@ApiTags('Super Admin - Plans')
@ApiBearerAuth()
@Controller('super-admin/plans')
@UseGuards(SuperAdminGuard)
export class SuperAdminPlansController {
  constructor(private readonly service: SuperAdminPlansService) {}

  @Get()
  @ApiOperation({ summary: 'Get all subscription plans' })
  findAll() {
    return this.service.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a specific plan by id' })
  findOne(@Param('id') id: string) {
    return this.service.findOne(id);
  }

  @Post()
  @ApiOperation({ summary: 'Create a new plan' })
  create(@Body() data: any) {
    return this.service.create(data);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update an existing plan' })
  update(@Param('id') id: string, @Body() data: any) {
    return this.service.update(id, data);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a plan' })
  remove(@Param('id') id: string) {
    return this.service.remove(id);
  }
}

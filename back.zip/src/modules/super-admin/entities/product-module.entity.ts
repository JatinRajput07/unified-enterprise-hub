import { Entity, Column, PrimaryColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('product_modules', { schema: 'public' })
export class ProductModuleEntity {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  id!: string; // e.g. "sales", "finance"

  @Column({ type: 'varchar', length: 100 })
  name!: string;

  @Column({ type: 'varchar', length: 50, default: 'active' })
  status!: string; // 'active', 'maintenance', 'beta', 'deprecated'

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  monthlyPrice!: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  annualPrice!: number;

  @Column({ type: 'varchar', length: 100 })
  schemaName!: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @Column({ type: 'text', nullable: true })
  maintenanceMsg?: string;

  @Column({ type: 'text', nullable: true })
  changelog?: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt!: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt!: Date;
}

import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, ManyToOne, JoinColumn, Index } from 'typeorm';
import { TenantEntity } from '../../tenants/entities/tenant.entity';
import { ProductName } from '../../../database/product-db.constants';

@Entity('tenant_product_subscriptions', { schema: 'public' })
export class TenantProductSubscription {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ name: 'tenant_id', type: 'uuid' })
  @Index()
  tenantId!: string;

  @ManyToOne(() => TenantEntity)
  @JoinColumn({ name: 'tenant_id' })
  tenant!: TenantEntity;

  @Column({
    name: 'product_name',
    type: 'varchar',
  })
  productName!: ProductName;

  @Column({ default: 'active' })
  status!: string; // active, inactive

  @CreateDateColumn({ name: 'subscribed_at' })
  subscribedAt!: Date;

  @Column({ name: 'expires_at', type: 'timestamptz', nullable: true })
  expiresAt?: Date;

  @CreateDateColumn({ name: 'created_at' })
  createdAt!: Date;
}

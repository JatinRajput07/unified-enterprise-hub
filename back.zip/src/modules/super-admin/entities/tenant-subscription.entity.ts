import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn, Index } from 'typeorm';
import { TenantEntity } from '../../tenants/entities/tenant.entity';
import { Plan } from '../../tenants/entities/plan.entity';

@Entity('tenant_subscriptions', { schema: 'public' })
export class TenantSubscription {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ name: 'tenant_id', type: 'uuid' })
  @Index()
  tenantId!: string;

  @ManyToOne(() => TenantEntity)
  @JoinColumn({ name: 'tenant_id' })
  tenant!: TenantEntity;

  @Column({ name: 'plan_id', type: 'uuid' })
  planId!: string;

  @ManyToOne(() => Plan)
  @JoinColumn({ name: 'plan_id' })
  plan!: Plan;

  @Column({ name: 'stripe_subscription_id', unique: true })
  stripeSubscriptionId!: string;

  @Column({ name: 'stripe_customer_id' })
  stripeCustomerId!: string;

  @Column()
  status!: string; // active, past_due, cancelled, trialing

  @Column()
  interval!: string; // monthly, yearly

  @Column({ name: 'current_period_start', type: 'timestamptz' })
  currentPeriodStart!: Date;

  @Column({ name: 'current_period_end', type: 'timestamptz' })
  currentPeriodEnd!: Date;

  @Column({ name: 'cancel_at_period_end', default: false })
  cancelAtPeriodEnd!: boolean;

  @Column({ name: 'trial_end', type: 'timestamptz', nullable: true })
  trialEnd?: Date;

  @CreateDateColumn({ name: 'created_at' })
  createdAt!: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt!: Date;
}

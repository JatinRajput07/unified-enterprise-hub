import { Injectable, Logger, ConflictException, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TenantEntity, TenantStatus } from '../tenants/entities/tenant.entity';
import { Plan } from '../tenants/entities/plan.entity';
import { BillingService } from '../billing/billing.service';
import { SchemaProvisionerService } from '../../database/schema-provisioner.service';
import { ProductName } from '../../database/product-db.constants';
import { TenantSeedService } from '../../database/tenant-seed.service';
import { TenantConnectionService } from '../../database/tenant-connection.service';
import { TenantProductSubscription } from './entities/tenant-product-subscription.entity';

@Injectable()
export class SuperAdminTenantsService {
  private readonly logger = new Logger(SuperAdminTenantsService.name);

  constructor(
    @InjectRepository(TenantEntity)
    private readonly tenantRepository: Repository<TenantEntity>,
    @InjectRepository(Plan)
    private readonly planRepository: Repository<Plan>,
    private readonly billingService: BillingService,
    private readonly schemaProvisioner: SchemaProvisionerService,
    private readonly seedService: TenantSeedService,
    private readonly connectionService: TenantConnectionService,
    @InjectRepository(TenantProductSubscription)
    private readonly productSubRepository: Repository<TenantProductSubscription>,
  ) {}

  async createTenant(dto: {
    name: string;
    slug: string;
    subdomain: string;
    planId: string;
    email: string;
    products?: ProductName[];
  }): Promise<TenantEntity> {
    this.logger.log(`Creating tenant: ${dto.slug}`);

    // 1. Validate uniqueness
    const existing = await this.tenantRepository.findOne({
      where: [{ slug: dto.slug }, { subdomain: dto.subdomain }],
    });
    if (existing) {
      throw new ConflictException('Tenant with this slug or subdomain already exists');
    }

    // 2. Validate Plan
    const plan = await this.planRepository.findOne({ where: { id: dto.planId, isActive: true } });
    if (!plan) {
      throw new NotFoundException('Plan not found or inactive');
    }

    // 3. Orchestration with Rollback Strategy
    let tenant: TenantEntity | null = null;
    try {
      // Step A: Create Tenant Record
      tenant = this.tenantRepository.create({
        ...dto,
        status: TenantStatus.PENDING,
        maxUsers: plan.maxUsers,
      });
      tenant = await this.tenantRepository.save(tenant);

      // Step B: Create Stripe Customer
      const stripeCustomer = await this.billingService.createCustomer(dto.email, dto.name, {
        tenantId: tenant.id,
        tenantSlug: dto.slug,
      });
      tenant.stripeCustomerId = stripeCustomer.id;
      await this.tenantRepository.save(tenant);

      // Step C: Provision Base Schema (Auth)
      await this.schemaProvisioner.provisionSchemas(dto.slug, ['auth']);

      // Step D: Seed Initial Data
      this.logger.debug(`Seeding default data for ${dto.slug}...`);
      const authDataSource = await this.connectionService.getConnection('auth', dto.slug);
      await this.seedService.seedInitialData(authDataSource);
      this.logger.log(`Initial data seeded for ${dto.slug}`);

      // Step E: Provision requested products
      if (dto.products && dto.products.length > 0) {
        const allowedProducts = dto.products.filter(p => plan.modules && plan.modules.includes(p));
        if (allowedProducts.length > 0) {
          await this.schemaProvisioner.provisionSchemas(dto.slug, allowedProducts);
        }
      }

      // Step F: Finalize
      tenant.status = TenantStatus.ACTIVE;
      return await this.tenantRepository.save(tenant);

    } catch (error) {
      this.logger.error(`Tenant creation failed for ${dto.slug}: ${(error as Error).message}`);
      
      if (tenant) {
        this.logger.warn(`Initiating rollback for tenant ${dto.slug}...`);
        try {
          await this.schemaProvisioner.deprovisionSchemas(dto.slug, ['auth', ...(dto.products || [])]);
          await this.tenantRepository.delete(tenant.id);
          this.logger.log(`Rollback for ${dto.slug} complete`);
        } catch (rollbackError) {
          this.logger.error(`Rollback FAILED for ${dto.slug}: ${(rollbackError as Error).message}`);
        }
      }
      
      throw new BadRequestException(`Failed to create tenant: ${(error as Error).message}`);
    }
  }

  async findAll(options: { page?: number; limit?: number; search?: string; status?: TenantStatus }) {
    const { page = 1, limit = 10, search, status } = options;
    const query = this.tenantRepository.createQueryBuilder('tenant')
      .leftJoinAndSelect('tenant.plan', 'plan')
      .skip((page - 1) * limit)
      .take(limit);

    if (search) {
      query.andWhere('(tenant.name ILIKE :search OR tenant.slug ILIKE :search)', { search: `%${search}%` });
    }

    if (status) {
      query.andWhere('tenant.status = :status', { status });
    }

    const [items, total] = await query.getManyAndCount();
    return { items, total, page, limit };
  }

  async findOne(id: string): Promise<TenantEntity> {
    const tenant = await this.tenantRepository.findOne({
      where: { id },
      relations: ['plan'],
    });
    if (!tenant) throw new NotFoundException('Tenant not found');
    return tenant;
  }

  async updateTenant(id: string, dto: any): Promise<TenantEntity> {
    const tenant = await this.findOne(id);
    Object.assign(tenant, dto);
    return this.tenantRepository.save(tenant);
  }

  async updateStatus(id: string, status: TenantStatus): Promise<TenantEntity> {
    const tenant = await this.findOne(id);
    tenant.status = status;
    return this.tenantRepository.save(tenant);
  }

  async remove(id: string): Promise<void> {
    const tenant = await this.findOne(id);
    await this.tenantRepository.softRemove(tenant);
  }

  async addProduct(tenantId: string, productName: ProductName): Promise<void> {
    const tenant = await this.findOne(tenantId);
    
    // 1. Provision schema
    await this.schemaProvisioner.provisionSchemas(tenant.slug, [productName]);
    
    // 2. Create product subscription record
    let sub = await this.productSubRepository.findOne({ where: { tenantId, productName } });
    if (!sub) {
      sub = this.productSubRepository.create({
        tenantId,
        productName,
        status: 'active',
        subscribedAt: new Date(),
      });
    } else {
      sub.status = 'active';
    }
    await this.productSubRepository.save(sub);
  }
}

import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ProductModuleEntity } from './entities/product-module.entity';

@Injectable()
export class ProductModulesService {
  constructor(
    @InjectRepository(ProductModuleEntity)
    private readonly repo: Repository<ProductModuleEntity>,
  ) {}

  async findAll() {
    return this.repo.find({ order: { name: 'ASC' } });
  }

  async findOne(id: string) {
    const module = await this.repo.findOne({ where: { id } });
    if (!module) throw new NotFoundException('Module not found');
    return module;
  }

  async create(data: Partial<ProductModuleEntity>) {
    const module = this.repo.create(data);
    return this.repo.save(module);
  }

  async update(id: string, data: Partial<ProductModuleEntity>) {
    const module = await this.findOne(id);
    Object.assign(module, data);
    return this.repo.save(module);
  }

  async remove(id: string) {
    const module = await this.findOne(id);
    return this.repo.remove(module);
  }
}

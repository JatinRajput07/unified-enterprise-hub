import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Plan } from '../tenants/entities/plan.entity';
import { TenantEntity } from '../tenants/entities/tenant.entity';
import { TenantSubscription } from './entities/tenant-subscription.entity';
import { TenantProductSubscription } from './entities/tenant-product-subscription.entity';
import { ProductModuleEntity } from './entities/product-module.entity';
import { UserEntity } from '../users/entities/user.entity';
import { RoleEntity } from '../roles/entities/role.entity';
import { SuperAdminTenantsService } from './tenants.service';
import { SuperAdminTenantsController } from './tenants.controller';
import { SuperAdminStatsController } from './stats.controller';
import { ProductModulesService } from './product-modules.service';
import { ProductModulesController } from './product-modules.controller';
import { SuperAdminPlansService } from './plans.service';
import { SuperAdminPlansController } from './plans.controller';
import { SuperAdminSeeder } from '../../database/seeds/super-admin.seed';
import { BillingModule } from '../billing/billing.module';
import { DatabaseCoreModule } from '../../database/database-core.module';
import { UsersModule } from '../users/users.module';
import { RolesModule } from '../roles/roles.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Plan,
      TenantEntity,
      TenantSubscription,
      TenantProductSubscription,
      ProductModuleEntity,
      UserEntity,
      RoleEntity,
    ]),
    BillingModule,
    DatabaseCoreModule,
    UsersModule,
    RolesModule,
  ],
  controllers: [
    SuperAdminTenantsController,
    SuperAdminStatsController,
    ProductModulesController,
    SuperAdminPlansController,
  ],
  providers: [
    SuperAdminTenantsService,
    ProductModulesService,
    SuperAdminPlansService,
    SuperAdminSeeder,
  ],
  exports: [
    SuperAdminTenantsService,
    ProductModulesService,
    SuperAdminPlansService,
  ],
})
export class SuperAdminModule {}

import { Controller, Get, Post, Put, Delete, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ProductModulesService } from './product-modules.service';
import { SuperAdminGuard } from './guards/super-admin.guard';

@ApiTags('Super Admin - Product Modules')
@ApiBearerAuth()
@Controller('super-admin/modules')
@UseGuards(SuperAdminGuard)
export class ProductModulesController {
  constructor(private readonly service: ProductModulesService) {}

  @Get()
  @ApiOperation({ summary: 'Get all product modules' })
  findAll() {
    return this.service.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a product module by id' })
  findOne(@Param('id') id: string) {
    return this.service.findOne(id);
  }

  @Post()
  @ApiOperation({ summary: 'Create a new product module' })
  create(@Body() data: any) {
    return this.service.create(data);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update a product module' })
  update(@Param('id') id: string, @Body() data: any) {
    return this.service.update(id, data);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a product module' })
  remove(@Param('id') id: string) {
    return this.service.remove(id);
  }
}

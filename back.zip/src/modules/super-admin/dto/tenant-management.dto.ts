import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsString, IsEmail, IsArray, IsOptional, IsEnum, IsUUID } from 'class-validator';
import { TenantStatus } from '../../tenants/entities/tenant.entity';
import { PRODUCT_DB_NAMES, ProductName } from '../../../database/product-db.constants';

export class CreateTenantDto {
  @ApiProperty({ example: 'Acme Corp' })
  @IsString()
  name!: string;

  @ApiProperty({ example: 'acme' })
  @IsString()
  slug!: string;

  @ApiProperty({ example: 'acme.enterprise-crm.com' })
  @IsString()
  subdomain!: string;

  @ApiProperty({ example: 'basic_plan_uuid' })
  @IsUUID()
  planId!: string;

  @ApiProperty({ example: 'admin@acme.com' })
  @IsEmail()
  email!: string;

  @ApiPropertyOptional({ enum: Object.values(PRODUCT_DB_NAMES), isArray: true })
  @IsArray()
  @IsEnum(PRODUCT_DB_NAMES, { each: true })
  @IsOptional()
  products?: ProductName[];
}

export class UpdateTenantStatusDto {
  @ApiProperty({ enum: TenantStatus })
  @IsEnum(TenantStatus)
  status!: TenantStatus;
}

export class TenantResponseDto {
  @ApiProperty()
  id!: string;

  @ApiProperty()
  name!: string;

  @ApiProperty()
  slug!: string;

  @ApiProperty()
  subdomain!: string;

  @ApiProperty({ enum: TenantStatus })
  status!: TenantStatus;

  @ApiProperty()
  createdAt!: Date;
}

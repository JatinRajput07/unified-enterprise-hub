import { Controller, Get, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { SuperAdminGuard } from './guards/super-admin.guard';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TenantEntity, TenantStatus } from '../tenants/entities/tenant.entity';
import { TenantProductSubscription } from './entities/tenant-product-subscription.entity';

@ApiTags('Super Admin')
@ApiBearerAuth()
@Controller('super-admin/stats')
@UseGuards(SuperAdminGuard)
export class SuperAdminStatsController {
  constructor(
    @InjectRepository(TenantEntity)
    private readonly tenantRepo: Repository<TenantEntity>,
    @InjectRepository(TenantProductSubscription)
    private readonly productSubRepo: Repository<TenantProductSubscription>,
  ) {}

  @Get('overview')
  @ApiOperation({ summary: 'Get platform-wide business overview' })
  @ApiResponse({ 
    status: 200, 
    description: 'Returns MRR, active tenants, and revenue metrics',
    schema: {
      type: 'object',
      properties: {
        totalTenants: { type: 'number' },
        activeTenants: { type: 'number' },
        mrr: { type: 'number' },
        arr: { type: 'number' },
      }
    }
  })
  async getOverview() {
    const totalTenants = await this.tenantRepo.count();
    const activeTenants = await this.tenantRepo.count({ where: { status: TenantStatus.ACTIVE } });
    
    return {
      totalTenants,
      activeTenants,
      mrr: activeTenants * 99,
      arr: activeTenants * 99 * 12,
      totalRevenue30d: 0,
      newTenantsThisMonth: 0,
      churnedThisMonth: 0,
    };
  }

  @Get('usage')
  @ApiOperation({ summary: 'Get product adoption and usage statistics' })
  @ApiResponse({ status: 200, description: 'Returns usage count per product' })
  async getUsage() {
    const productUsage = await this.productSubRepo
      .createQueryBuilder('sub')
      .select('sub.product_name', 'product')
      .addSelect('COUNT(*)', 'count')
      .groupBy('sub.product_name')
      .getRawMany();

    return {
      productUsage,
      activeProducts: productUsage.map(p => p.product),
    };
  }
}

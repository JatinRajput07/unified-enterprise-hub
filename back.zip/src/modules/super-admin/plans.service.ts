import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Plan } from '../tenants/entities/plan.entity';

@Injectable()
export class SuperAdminPlansService {
  constructor(
    @InjectRepository(Plan)
    private readonly repo: Repository<Plan>,
  ) {}

  async findAll() {
    return this.repo.find({
      order: { sortOrder: 'ASC', createdAt: 'DESC' },
    });
  }

  async findOne(id: string) {
    const plan = await this.repo.findOne({ where: { id } });
    if (!plan) throw new NotFoundException('Plan not found');
    return plan;
  }

  async create(data: Partial<Plan>) {
    const exists = await this.repo.findOne({ where: { slug: data.slug } });
    if (exists) {
      throw new BadRequestException(`Plan with slug '${data.slug}' already exists`);
    }
    const sanitized = this.sanitizeJsonbFields(data);
    const plan = this.repo.create(sanitized);
    return this.repo.save(plan);
  }

  async update(id: string, data: Partial<Plan>) {
    const plan = await this.findOne(id);
    if (data.slug && data.slug !== plan.slug) {
      const exists = await this.repo.findOne({ where: { slug: data.slug } });
      if (exists) {
        throw new BadRequestException(`Plan with slug '${data.slug}' already exists`);
      }
    }
    const sanitized = this.sanitizeJsonbFields(data);
    Object.assign(plan, sanitized);
    return this.repo.save(plan);
  }

  async remove(id: string) {
    const plan = await this.findOne(id);
    return this.repo.softRemove(plan);
  }

  /**
   * Ensures JSONB array fields (modules, features) are always stored
   * as proper JSON arrays, never as indexed objects like {"0":"a","1":"b"}.
   */
  private sanitizeJsonbFields(data: Partial<Plan>): Partial<Plan> {
    const result = { ...data };

    if (result.modules !== undefined) {
      result.modules = this.toStringArray(result.modules);
    }

    if (result.features !== undefined) {
      result.features = this.toStringArray(result.features);
    }

    return result;
  }

  /**
   * Converts any format to a clean string array:
   * - Array → kept as-is (filtered for strings only)
   * - Indexed object {"0":"a","1":"b"} → ["a","b"]
   * - Boolean object {pms:true,hrms:false} → ["pms"]
   * - null/undefined → []
   */
  private toStringArray(value: unknown): string[] {
    if (!value) return [];

    if (Array.isArray(value)) {
      return value.filter((v): v is string => typeof v === 'string' && v.length > 0);
    }

    if (typeof value === 'object') {
      const entries = Object.entries(value as Record<string, unknown>);

      // Check if it's a boolean map like {pms: true, hrms: false}
      const isBooleanMap = entries.every(([, v]) => typeof v === 'boolean');
      if (isBooleanMap) {
        return entries.filter(([, v]) => v === true).map(([k]) => k);
      }

      // Otherwise it's an indexed object like {"0": "finance", "1": "hrms"}
      return entries
        .map(([, v]) => v)
        .filter((v): v is string => typeof v === 'string' && v.length > 0);
    }

    return [];
  }
}

import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { TenantConnectionService } from '../../../../database/tenant-connection.service';
import { Contact } from '../entities/contact.entity';

@Injectable()
export class ContactsService {
  private readonly logger = new Logger(ContactsService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('sales', tenantSlug);
    return ds.getRepository(Contact);
  }

  async create(dto: Partial<Contact>, tenantSlug: string): Promise<Contact> {
    const repo = await this.getRepo(tenantSlug);
    const contact = repo.create(dto);
    return repo.save(contact);
  }

  async findAll(tenantSlug: string, filters: { limit?: number; offset?: number }) {
    const repo = await this.getRepo(tenantSlug);
    const { limit = 10, offset = 0 } = filters;

    const [items, total] = await repo.findAndCount({
      skip: offset,
      take: limit,
      order: { createdAt: 'DESC' },
    });

    return { items, total, limit, offset };
  }

  async findOne(id: string, tenantSlug: string): Promise<Contact> {
    const repo = await this.getRepo(tenantSlug);
    const contact = await repo.findOne({ where: { id } });
    if (!contact) throw new NotFoundException('Contact not found');
    return contact;
  }
}

import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { TenantConnectionService } from '../../../../database/tenant-connection.service';
import { Lead, LeadStatus } from '../entities/lead.entity';
import { Contact } from '../entities/contact.entity';
import { Deal, DealStatus } from '../entities/deal.entity';
import { Stage } from '../entities/stage.entity';

@Injectable()
export class LeadsService {
  private readonly logger = new Logger(LeadsService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('sales', tenantSlug);
    return ds.getRepository(Lead);
  }

  async create(dto: Partial<Lead>, tenantSlug: string): Promise<Lead> {
    const repo = await this.getRepo(tenantSlug);
    const lead = repo.create(dto);
    return repo.save(lead);
  }

  async findAll(tenantSlug: string, filters: { status?: LeadStatus; limit?: number; offset?: number }) {
    const repo = await this.getRepo(tenantSlug);
    const { status, limit = 10, offset = 0 } = filters;

    const query = repo.createQueryBuilder('l')
      .where('l.deleted_at IS NULL');

    if (status) {
      query.andWhere('l.status = :status', { status });
    }

    const [items, total] = await query
      .skip(offset)
      .take(limit)
      .orderBy('l.created_at', 'DESC')
      .getManyAndCount();

    return { items, total, limit, offset };
  }

  async findOne(id: string, tenantSlug: string): Promise<Lead> {
    const repo = await this.getRepo(tenantSlug);
    const lead = await repo.findOne({ where: { id } });
    if (!lead) throw new NotFoundException('Lead not found');
    return lead;
  }

  async convertToDeal(leadId: string, tenantSlug: string, options: { stageId: string; dealValue?: number }) {
    const leadRepo = await this.getRepo(tenantSlug);
    const contactRepo = await this.tenantConn.getConnection('sales', tenantSlug).then(ds => ds.getRepository(Contact));
    const dealRepo = await this.tenantConn.getConnection('sales', tenantSlug).then(ds => ds.getRepository(Deal));

    const lead = await this.findOne(leadId, tenantSlug);
    if (lead.status === LeadStatus.WON) {
      throw new Error('Lead already converted');
    }

    // 1. Create Contact
    const contact = contactRepo.create({
      name: lead.name,
      email: lead.email,
      phone: lead.phone,
      companyName: lead.companyName,
      source: lead.source,
    });
    await contactRepo.save(contact);

    // 2. Create Deal
    const deal = dealRepo.create({
      title: `${lead.companyName || lead.name} - Deal`,
      value: options.dealValue || 0,
      status: DealStatus.OPEN,
      contactId: contact.id,
      stageId: options.stageId,
      assignedToUserId: lead.assignedToUserId,
    });
    await dealRepo.save(deal);

    // 3. Update Lead Status
    lead.status = LeadStatus.WON;
    await leadRepo.save(lead);

    return { contact, deal };
  }
}

import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { TenantConnectionService } from '../../../../database/tenant-connection.service';
import { Deal, DealStatus } from '../entities/deal.entity';

@Injectable()
export class DealsService {
  private readonly logger = new Logger(DealsService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('sales', tenantSlug);
    return ds.getRepository(Deal);
  }

  async create(dto: Partial<Deal>, tenantSlug: string): Promise<Deal> {
    const repo = await this.getRepo(tenantSlug);
    const deal = repo.create(dto);
    return repo.save(deal);
  }

  async findAll(tenantSlug: string, filters: { status?: DealStatus; limit?: number; offset?: number }) {
    const repo = await this.getRepo(tenantSlug);
    const { status, limit = 10, offset = 0 } = filters;

    const query = repo.createQueryBuilder('d')
      .leftJoinAndSelect('d.contact', 'contact')
      .where('d.deleted_at IS NULL');

    if (status) {
      query.andWhere('d.status = :status', { status });
    }

    const [items, total] = await query
      .skip(offset)
      .take(limit)
      .orderBy('d.created_at', 'DESC')
      .getManyAndCount();

    return { items, total, limit, offset };
  }

  async findOne(id: string, tenantSlug: string): Promise<Deal> {
    const repo = await this.getRepo(tenantSlug);
    const deal = await repo.findOne({ where: { id }, relations: ['contact'] });
    if (!deal) throw new NotFoundException('Deal not found');
    return deal;
  }

  async updateStatus(id: string, status: DealStatus, tenantSlug: string): Promise<Deal> {
    const repo = await this.getRepo(tenantSlug);
    const deal = await this.findOne(id, tenantSlug);
    deal.status = status;
    if (status === DealStatus.WON || status === DealStatus.LOST) {
      deal.closedAt = new Date();
    }
    return repo.save(deal);
  }
}

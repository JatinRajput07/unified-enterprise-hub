import { Entity, Column, Index } from 'typeorm';
import { BaseEntity } from '../../../../database/base.entity';

export enum LeadStatus {
  NEW = 'new',
  CONTACTED = 'contacted',
  QUALIFIED = 'qualified',
  PROPOSAL = 'proposal',
  NEGOTIATION = 'negotiation',
  WON = 'won',
  LOST = 'lost',
}

@Entity('leads')
export class Lead extends BaseEntity {
  @Column()
  name!: string;

  @Column()
  @Index()
  email!: string;

  @Column({ nullable: true })
  phone?: string;

  @Column({ nullable: true })
  companyName?: string;

  @Column({ default: 'website' })
  source!: string;

  @Column({
    type: 'enum',
    enum: LeadStatus,
    default: LeadStatus.NEW,
  })
  status!: LeadStatus;

  @Column({ nullable: true })
  assignedToUserId?: string;

  @Column({ type: 'int', default: 0 })
  score!: number;

  @Column({ type: 'text', nullable: true })
  notes?: string;

  @Column({ type: 'timestamptz', nullable: true })
  lastContactedAt?: Date;
}


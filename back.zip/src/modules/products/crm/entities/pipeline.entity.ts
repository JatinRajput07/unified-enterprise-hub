import { Entity, Column, PrimaryGeneratedColumn, OneToMany } from 'typeorm';
import { BaseEntity } from '../../../../database/base.entity';
import { Stage } from './stage.entity';

@Entity('pipelines')
export class Pipeline extends BaseEntity {
  @Column()
  name!: string;

  @Column({ unique: true })
  slug!: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @OneToMany(() => Stage, (stage) => stage.pipeline)
  stages!: Stage[];
}

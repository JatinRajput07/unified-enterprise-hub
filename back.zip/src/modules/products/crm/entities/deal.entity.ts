import { Entity, Column, Index, ManyToOne, JoinColumn } from 'typeorm';
import { BaseEntity } from '../../../../database/base.entity';
import { Contact } from './contact.entity';

export enum DealStatus {
  OPEN = 'open',
  WON = 'won',
  LOST = 'lost',
}

@Entity('deals')
export class Deal extends BaseEntity {
  @Column()
  title!: string;

  @Column({ type: 'decimal', precision: 12, scale: 2, default: 0 })
  value!: number;

  @Column({
    type: 'enum',
    enum: DealStatus,
    default: DealStatus.OPEN,
  })
  status!: DealStatus;

  @Column({ name: 'contact_id', type: 'uuid' })
  contactId!: string;

  @ManyToOne(() => Contact)
  @JoinColumn({ name: 'contact_id' })
  contact!: Contact;

  @Column({ name: 'stage_id', type: 'uuid' })
  stageId!: string;

  @Column({ nullable: true })
  assignedToUserId?: string;

  @Column({ type: 'timestamptz', nullable: true })
  closedAt?: Date;
}

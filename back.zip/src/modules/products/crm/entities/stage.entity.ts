import { Entity, Column, ManyToOne, JoinColumn } from 'typeorm';
import { BaseEntity } from '../../../../database/base.entity';
import { Pipeline } from './pipeline.entity';

@Entity('pipeline_stages')
export class Stage extends BaseEntity {
  @Column()
  name!: string;

  @Column({ type: 'int', default: 0 })
  sortOrder!: number;

  @Column({ type: 'int', default: 0 })
  probability!: number;

  @Column({ name: 'pipeline_id', type: 'uuid' })
  pipelineId!: string;

  @ManyToOne(() => Pipeline, (pipeline) => pipeline.stages)
  @JoinColumn({ name: 'pipeline_id' })
  pipeline!: Pipeline;
}

import { Entity, Column, Index, ManyToOne, JoinColumn } from 'typeorm';
import { BaseEntity } from '../../../../database/base.entity';

@Entity('contacts')
export class Contact extends BaseEntity {
  @Column()
  name!: string;

  @Column()
  @Index()
  email!: string;

  @Column({ nullable: true })
  phone?: string;

  @Column({ nullable: true })
  companyName?: string;

  @Column({ nullable: true })
  jobTitle?: string;

  @Column({ default: 'manual' })
  source!: string;

  @Column({ type: 'jsonb', nullable: true })
  metadata?: any;
}

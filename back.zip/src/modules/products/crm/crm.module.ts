import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Lead } from './entities/lead.entity';
import { Contact } from './entities/contact.entity';
import { Deal } from './entities/deal.entity';
import { Pipeline } from './entities/pipeline.entity';
import { Stage } from './entities/stage.entity';
import { LeadsService } from './services/leads.service';
import { ContactsService } from './services/contacts.service';
import { DealsService } from './services/deals.service';
import { CRMController } from './crm.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([Lead, Contact, Deal, Pipeline, Stage]),
  ],
  providers: [LeadsService, ContactsService, DealsService],
  controllers: [CRMController],
  exports: [LeadsService, ContactsService, DealsService],
})
export class CRMModule {}

import { Controller, Get, Post, Body, Param, Query, Patch } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { LeadsService } from './services/leads.service';
import { ContactsService } from './services/contacts.service';
import { DealsService } from './services/deals.service';
import { LeadStatus } from './entities/lead.entity';
import { DealStatus } from './entities/deal.entity';
import { RequiresProductPermission } from '../../org/product-access/product-permission.decorator';

@ApiTags('CRM')
@ApiBearerAuth()
@Controller('crm')
export class CRMController {
  constructor(
    private readonly leadsService: LeadsService,
    private readonly contactsService: ContactsService,
    private readonly dealsService: DealsService,
  ) {}

  // --- LEADS ---
  @Post('leads')
  @ApiOperation({ summary: 'Create a new lead' })
  @RequiresProductPermission('sales', 'leads:create')
  createLead(@Body() dto: any, @Query('tenantSlug') tenantSlug: string) {
    return this.leadsService.create(dto, tenantSlug);
  }

  @Get('leads')
  @ApiOperation({ summary: 'Get all leads' })
  @RequiresProductPermission('sales', 'leads:read')
  findAllLeads(
    @Query('tenantSlug') tenantSlug: string,
    @Query('status') status?: LeadStatus,
  ) {
    return this.leadsService.findAll(tenantSlug, { status });
  }

  @Post('leads/:id/convert')
  @ApiOperation({ summary: 'Convert lead to contact and deal' })
  @RequiresProductPermission('sales', 'leads:convert')
  convertLead(
    @Param('id') id: string,
    @Body() dto: { stageId: string; dealValue?: number },
    @Query('tenantSlug') tenantSlug: string,
  ) {
    return this.leadsService.convertToDeal(id, tenantSlug, dto);
  }

  // --- CONTACTS ---
  @Post('contacts')
  @ApiOperation({ summary: 'Create a new contact' })
  @RequiresProductPermission('sales', 'contacts:create')
  createContact(@Body() dto: any, @Query('tenantSlug') tenantSlug: string) {
    return this.contactsService.create(dto, tenantSlug);
  }

  @Get('contacts')
  @ApiOperation({ summary: 'Get all contacts' })
  @RequiresProductPermission('sales', 'contacts:read')
  findAllContacts(@Query('tenantSlug') tenantSlug: string) {
    return this.contactsService.findAll(tenantSlug, {});
  }

  // --- DEALS ---
  @Post('deals')
  @ApiOperation({ summary: 'Create a new deal' })
  @RequiresProductPermission('sales', 'deals:create')
  createDeal(@Body() dto: any, @Query('tenantSlug') tenantSlug: string) {
    return this.dealsService.create(dto, tenantSlug);
  }

  @Get('deals')
  @ApiOperation({ summary: 'Get all deals' })
  @RequiresProductPermission('sales', 'deals:read')
  findAllDeals(
    @Query('tenantSlug') tenantSlug: string,
    @Query('status') status?: DealStatus,
  ) {
    return this.dealsService.findAll(tenantSlug, { status });
  }

  @Patch('deals/:id/status')
  @ApiOperation({ summary: 'Update deal status' })
  @RequiresProductPermission('sales', 'deals:manage')
  updateDealStatus(
    @Param('id') id: string,
    @Body() dto: { status: DealStatus },
    @Query('tenantSlug') tenantSlug: string,
  ) {
    return this.dealsService.updateStatus(id, dto.status, tenantSlug);
  }
}

import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { TenantConnectionService } from '../../../../database/tenant-connection.service';
import { Invoice, InvoiceStatus } from '../entities/invoice.entity';

@Injectable()
export class InvoicesService {
  private readonly logger = new Logger(InvoicesService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('finance', tenantSlug);
    return ds.getRepository(Invoice);
  }

  async create(dto: Partial<Invoice>, tenantSlug: string): Promise<Invoice> {
    const repo = await this.getRepo(tenantSlug);
    const invoice = repo.create(dto);
    return repo.save(invoice);
  }

  async findAll(tenantSlug: string, filters: { status?: InvoiceStatus; limit?: number; offset?: number }) {
    const repo = await this.getRepo(tenantSlug);
    const { status, limit = 10, offset = 0 } = filters;

    const query = repo.createQueryBuilder('i')
      .where('i.deleted_at IS NULL');

    if (status) {
      query.andWhere('i.status = :status', { status });
    }

    const [items, total] = await query
      .skip(offset)
      .take(limit)
      .orderBy('i.created_at', 'DESC')
      .getManyAndCount();

    return { items, total, limit, offset };
  }

  async markPaid(id: string, reference: string, tenantSlug: string): Promise<Invoice> {
    const repo = await this.getRepo(tenantSlug);
    const invoice = await repo.findOne({ where: { id } });
    if (!invoice) throw new NotFoundException('Invoice not found');

    invoice.status = InvoiceStatus.PAID;
    invoice.paidAt = new Date();
    invoice.paymentReference = reference;

    return repo.save(invoice);
  }
}

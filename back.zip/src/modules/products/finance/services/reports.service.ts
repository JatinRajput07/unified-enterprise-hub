import { Injectable, Logger } from '@nestjs/common';
import { TenantConnectionService } from '../../../../database/tenant-connection.service';
import { Invoice, InvoiceStatus } from '../entities/invoice.entity';

@Injectable()
export class FinanceReportsService {
  private readonly logger = new Logger(FinanceReportsService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  async getRevenueSummary(tenantSlug: string, year: number) {
    const ds = await this.tenantConn.getConnection('finance', tenantSlug);
    const repo = ds.getRepository(Invoice);

    const data = await repo.createQueryBuilder('i')
      .select(`EXTRACT(MONTH FROM i.created_at)`, 'month')
      .addSelect('SUM(i.total_amount)', 'revenue')
      .where('i.status = :status', { status: InvoiceStatus.PAID })
      .andWhere(`EXTRACT(YEAR FROM i.created_at) = :year`, { year })
      .groupBy('month')
      .orderBy('month', 'ASC')
      .getRawMany();

    return data;
  }
}

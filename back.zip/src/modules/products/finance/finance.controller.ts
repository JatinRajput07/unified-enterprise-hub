import { Controller, Get, Post, Body, Param, Query, Patch } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { InvoicesService } from './services/invoices.service';
import { FinanceReportsService } from './services/reports.service';
import { InvoiceStatus } from './entities/invoice.entity';
import { RequiresProductPermission } from '../../org/product-access/product-permission.decorator';

@ApiTags('Finance')
@ApiBearerAuth()
@Controller('finance')
export class FinanceController {
  constructor(
    private readonly invoicesService: InvoicesService,
    private readonly reportsService: FinanceReportsService,
  ) {}

  @Post('invoices')
  @ApiOperation({ summary: 'Create a new invoice' })
  @RequiresProductPermission('finance', 'invoices:create')
  createInvoice(@Body() dto: any, @Query('tenantSlug') tenantSlug: string) {
    return this.invoicesService.create(dto, tenantSlug);
  }

  @Get('invoices')
  @ApiOperation({ summary: 'List all invoices' })
  @RequiresProductPermission('finance', 'invoices:read')
  findAllInvoices(
    @Query('tenantSlug') tenantSlug: string,
    @Query('status') status?: InvoiceStatus,
  ) {
    return this.invoicesService.findAll(tenantSlug, { status });
  }

  @Patch('invoices/:id/pay')
  @ApiOperation({ summary: 'Record payment for invoice' })
  @RequiresProductPermission('finance', 'invoices:manage')
  markPaid(
    @Param('id') id: string,
    @Body() dto: { reference: string },
    @Query('tenantSlug') tenantSlug: string,
  ) {
    return this.invoicesService.markPaid(id, dto.reference, tenantSlug);
  }

  @Get('reports/revenue')
  @ApiOperation({ summary: 'Get annual revenue summary' })
  @RequiresProductPermission('finance', 'reports:read')
  getRevenue(
    @Query('tenantSlug') tenantSlug: string,
    @Query('year') year: number = new Date().getFullYear(),
  ) {
    return this.reportsService.getRevenueSummary(tenantSlug, year);
  }
}

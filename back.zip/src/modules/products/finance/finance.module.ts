import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Invoice } from './entities/invoice.entity';
import { Budget } from './entities/budget.entity';
import { InvoicesService } from './services/invoices.service';
import { FinanceReportsService } from './services/reports.service';
import { FinanceController } from './finance.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([Invoice, Budget]),
  ],
  providers: [InvoicesService, FinanceReportsService],
  controllers: [FinanceController],
  exports: [InvoicesService, FinanceReportsService],
})
export class FinanceModule {}

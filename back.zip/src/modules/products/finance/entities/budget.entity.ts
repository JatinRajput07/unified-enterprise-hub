import { Entity, Column } from 'typeorm';
import { BaseEntity } from '../../../../database/base.entity';

@Entity('budgets')
export class Budget extends BaseEntity {
  @Column()
  name!: string;

  @Column({ nullable: true })
  departmentId?: string;

  @Column({ type: 'int' })
  fiscalYear!: number;

  @Column({ type: 'int', nullable: true })
  fiscalMonth?: number;

  @Column({ type: 'decimal', precision: 12, scale: 2 })
  allocatedAmount!: number;

  @Column({ type: 'decimal', precision: 12, scale: 2, default: 0 })
  spentAmount!: number;

  @Column()
  category!: string;
}


import { Controller, Get, Post, Body, Param, Query, Patch } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { EmployeesService } from './services/employees.service';
import { LeavesService } from './services/leaves.service';
import { PayrollService } from './services/payroll.service';
import { EmployeeStatus } from './entities/employee.entity';
import { LeaveStatus } from './entities/leave.entity';
import { RequiresProductPermission } from '../../org/product-access/product-permission.decorator';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';

@ApiTags('HRMS')
@ApiBearerAuth()
@Controller('hrms')
export class HRMSController {
  constructor(
    private readonly employeesService: EmployeesService,
    private readonly leavesService: LeavesService,
    private readonly payrollService: PayrollService,
  ) {}

  // --- EMPLOYEES ---
  @Post('employees')
  @ApiOperation({ summary: 'Create a new employee record' })
  @RequiresProductPermission('hrms', 'employees:create')
  createEmployee(@Body() dto: any, @Query('tenantSlug') tenantSlug: string) {
    return this.employeesService.create(dto, tenantSlug);
  }

  @Get('employees')
  @ApiOperation({ summary: 'List all employees' })
  @RequiresProductPermission('hrms', 'employees:read')
  findAllEmployees(
    @Query('tenantSlug') tenantSlug: string,
    @Query('status') status?: EmployeeStatus,
  ) {
    return this.employeesService.findAll(tenantSlug, { status });
  }

  // --- LEAVES ---
  @Post('leaves')
  @ApiOperation({ summary: 'Request a leave' })
  @RequiresProductPermission('hrms', 'leaves:create')
  requestLeave(@Body() dto: any, @Query('tenantSlug') tenantSlug: string) {
    return this.leavesService.create(dto, tenantSlug);
  }

  @Get('leaves')
  @ApiOperation({ summary: 'Get all leave requests' })
  @RequiresProductPermission('hrms', 'leaves:read')
  findAllLeaves(
    @Query('tenantSlug') tenantSlug: string,
    @Query('status') status?: LeaveStatus,
  ) {
    return this.leavesService.findAll(tenantSlug, { status });
  }

  @Patch('leaves/:id/status')
  @ApiOperation({ summary: 'Approve or reject leave request' })
  @RequiresProductPermission('hrms', 'leaves:manage')
  updateLeaveStatus(
    @Param('id') id: string,
    @Body() dto: { status: LeaveStatus },
    @CurrentUser('id') adminId: string,
    @Query('tenantSlug') tenantSlug: string,
  ) {
    return this.leavesService.updateStatus(id, dto.status, adminId, tenantSlug);
  }

  // --- PAYROLL ---
  @Post('payroll')
  @ApiOperation({ summary: 'Generate payroll record' })
  @RequiresProductPermission('hrms', 'payroll:manage')
  generatePayroll(@Body() dto: any, @Query('tenantSlug') tenantSlug: string) {
    return this.payrollService.generate(dto, tenantSlug);
  }

  @Get('payroll')
  @ApiOperation({ summary: 'Get payroll records' })
  @RequiresProductPermission('hrms', 'payroll:read')
  findAllPayroll(
    @Query('tenantSlug') tenantSlug: string,
    @Query('month') month?: number,
    @Query('year') year?: number,
  ) {
    return this.payrollService.findAll(tenantSlug, { month, year });
  }

  @Patch('payroll/:id/pay')
  @ApiOperation({ summary: 'Mark payroll as paid' })
  @RequiresProductPermission('hrms', 'payroll:manage')
  payPayroll(@Param('id') id: string, @Query('tenantSlug') tenantSlug: string) {
    return this.payrollService.markAsPaid(id, tenantSlug);
  }
}

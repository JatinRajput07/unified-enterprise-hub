import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Employee } from './entities/employee.entity';
import { Leave } from './entities/leave.entity';
import { Payroll } from './entities/payroll.entity';
import { EmployeesService } from './services/employees.service';
import { LeavesService } from './services/leaves.service';
import { PayrollService } from './services/payroll.service';
import { HRMSController } from './hrms.controller';
import { SearchModule } from '../../search/search.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Employee, Leave, Payroll]),
    SearchModule,
  ],
  providers: [EmployeesService, LeavesService, PayrollService],
  controllers: [HRMSController],
  exports: [EmployeesService, LeavesService, PayrollService],
})
export class HRMSModule {}

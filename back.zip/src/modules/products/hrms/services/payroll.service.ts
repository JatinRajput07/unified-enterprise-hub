import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { TenantConnectionService } from '../../../../database/tenant-connection.service';
import { Payroll, PayrollStatus } from '../entities/payroll.entity';

@Injectable()
export class PayrollService {
  private readonly logger = new Logger(PayrollService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('hrms', tenantSlug);
    return ds.getRepository(Payroll);
  }

  async generate(dto: any, tenantSlug: string): Promise<Payroll> {
    const repo = await this.getRepo(tenantSlug);
    // Simple logic: netPay = basicSalary + bonus - deductions
    const basic = Number(dto.basicSalary || 0);
    const bonus = Number(dto.bonus || 0);
    const deductions = Number(dto.deductions || 0);
    const netPay = basic + bonus - deductions;

    const payroll = repo.create({
      ...dto,
      basicSalary: basic,
      netPay: netPay,
      status: PayrollStatus.DRAFT,
    });
    return repo.save(payroll) as any;
  }

  async findAll(tenantSlug: string, filters: { month?: number; year?: number }) {
    const repo = await this.getRepo(tenantSlug);
    const { month, year } = filters;

    const query = repo.createQueryBuilder('p')
      .leftJoinAndSelect('p.employee', 'emp');

    if (month) query.andWhere('p.month = :month', { month });
    if (year) query.andWhere('p.year = :year', { year });

    return query.orderBy('p.year', 'DESC').addOrderBy('p.month', 'DESC').getMany();
  }

  async markAsPaid(id: string, tenantSlug: string) {
    const repo = await this.getRepo(tenantSlug);
    const payroll = await repo.findOne({ where: { id } });
    if (!payroll) throw new NotFoundException('Payroll record not found');

    payroll.status = PayrollStatus.PAID;
    payroll.paidAt = new Date();

    return repo.save(payroll);
  }
}

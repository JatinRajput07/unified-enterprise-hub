import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { TenantConnectionService } from '../../../../database/tenant-connection.service';
import { Employee, EmployeeStatus } from '../entities/employee.entity';
import { SearchService } from '../../../search/search.service';

@Injectable()
export class EmployeesService {
  private readonly logger = new Logger(EmployeesService.name);

  constructor(
    private readonly tenantConn: TenantConnectionService,
    private readonly searchService: SearchService,
  ) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('hrms', tenantSlug);
    return ds.getRepository(Employee);
  }

  async create(dto: Partial<Employee>, tenantSlug: string): Promise<Employee> {
    const repo = await this.getRepo(tenantSlug);
    const employee = repo.create(dto);
    const saved = await repo.save(employee);

    // Index in ElasticSearch (Asynchronous)
    try {
      await this.searchService.indexDocument(
        `employees_${tenantSlug}`,
        saved.id,
        { ...saved, tenantSlug }
      );
    } catch (error) {
      this.logger.error(`Failed to index employee ${saved.id} in ES: ${(error as Error).message}`);
    }

    return saved;
  }

  async findAll(tenantSlug: string, filters: { departmentId?: string; status?: EmployeeStatus; limit?: number; offset?: number }) {
    const repo = await this.getRepo(tenantSlug);
    const { departmentId, status, limit = 10, offset = 0 } = filters;

    const query = repo.createQueryBuilder('e')
      .where('e.deleted_at IS NULL');

    if (departmentId) {
      query.andWhere('e.department_id = :departmentId', { departmentId });
    }

    if (status) {
      query.andWhere('e.status = :status', { status });
    }

    const [items, total] = await query
      .skip(offset)
      .take(limit)
      .orderBy('e.created_at', 'DESC')
      .getManyAndCount();

    return { items, total, limit, offset };
  }

  async findOne(id: string, tenantSlug: string): Promise<Employee> {
    const repo = await this.getRepo(tenantSlug);
    const employee = await repo.findOne({ where: { id } });
    if (!employee) throw new NotFoundException('Employee not found');
    return employee;
  }
}

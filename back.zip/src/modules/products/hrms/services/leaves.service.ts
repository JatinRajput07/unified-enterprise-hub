import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { TenantConnectionService } from '../../../../database/tenant-connection.service';
import { Leave, LeaveStatus } from '../entities/leave.entity';

@Injectable()
export class LeavesService {
  private readonly logger = new Logger(LeavesService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('hrms', tenantSlug);
    return ds.getRepository(Leave);
  }

  async create(dto: Partial<Leave>, tenantSlug: string): Promise<Leave> {
    const repo = await this.getRepo(tenantSlug);
    const leave = repo.create({
      ...dto,
      status: LeaveStatus.PENDING,
    });
    return repo.save(leave);
  }

  async findAll(tenantSlug: string, filters: { employeeId?: string; status?: LeaveStatus }) {
    const repo = await this.getRepo(tenantSlug);
    const { employeeId, status } = filters;

    const query = repo.createQueryBuilder('l')
      .leftJoinAndSelect('l.employee', 'emp');

    if (employeeId) {
      query.andWhere('l.employee_id = :employeeId', { employeeId });
    }
    if (status) {
      query.andWhere('l.status = :status', { status });
    }

    return query.orderBy('l.created_at', 'DESC').getMany();
  }

  async updateStatus(id: string, status: LeaveStatus, approvedById: string, tenantSlug: string) {
    const repo = await this.getRepo(tenantSlug);
    const leave = await repo.findOne({ where: { id } });
    if (!leave) throw new NotFoundException('Leave request not found');

    leave.status = status;
    leave.approvedByEmployeeId = approvedById;
    leave.approvedAt = new Date();

    return repo.save(leave);
  }
}

import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn, Index, Unique } from 'typeorm';
import { Employee } from './employee.entity';

export enum PayrollStatus {
  DRAFT = 'draft',
  PROCESSED = 'processed',
  PAID = 'paid',
}

@Entity('payroll')
@Unique(['employeeId', 'month', 'year'])
export class Payroll {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ name: 'employee_id' })
  @Index()
  employeeId!: string;

  @ManyToOne(() => Employee)
  @JoinColumn({ name: 'employee_id' })
  employee!: Employee;

  @Column({ type: 'int' })
  month!: number;

  @Column({ type: 'int' })
  year!: number;

  @Column({ name: 'basic_salary', type: 'decimal', precision: 12, scale: 2 })
  basicSalary!: number;

  @Column({ type: 'decimal', precision: 12, scale: 2, default: 0 })
  hra!: number;

  @Column({ type: 'jsonb', name: 'other_allowances', nullable: true })
  otherAllowances?: Record<string, number>;

  @Column({ name: 'pf_deduction', type: 'decimal', precision: 12, scale: 2, default: 0 })
  pfDeduction!: number;

  @Column({ name: 'tax_deduction', type: 'decimal', precision: 12, scale: 2, default: 0 })
  taxDeduction!: number;

  @Column({ type: 'jsonb', name: 'other_deductions', nullable: true })
  otherDeductions?: Record<string, number>;

  @Column({ name: 'net_pay', type: 'decimal', precision: 12, scale: 2 })
  netPay!: number;

  @Column({
    type: 'enum',
    enum: PayrollStatus,
    default: PayrollStatus.DRAFT,
  })
  status!: PayrollStatus;

  @Column({ name: 'paid_at', type: 'timestamptz', nullable: true })
  paidAt?: Date;

  @Column({ name: 'payment_reference', nullable: true })
  paymentReference?: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt!: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt!: Date;
}

import { Entity, Column, Index, ManyToOne, JoinColumn } from 'typeorm';
import { BaseEntity } from '../../../../database/base.entity';
import { UserEntity } from '../../../users/entities/user.entity';

export enum EmployeeStatus {
  ACTIVE = 'active',
  ONBOARDING = 'onboarding',
  SUSPENDED = 'suspended',
  TERMINATED = 'terminated',
}

@Entity('employees')
export class Employee extends BaseEntity {
  @Column({ name: 'user_id', type: 'uuid' })
  @Index()
  userId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'user_id' })
  user!: UserEntity;

  @Column()
  employeeId!: string; // Company specific ID

  @Column({
    type: 'enum',
    enum: EmployeeStatus,
    default: EmployeeStatus.ONBOARDING,
  })
  status!: EmployeeStatus;

  @Column({ nullable: true })
  designation?: string;

  @Column({ name: 'department_id', type: 'uuid', nullable: true })
  departmentId?: string;

  @Column({ type: 'date', nullable: true })
  joiningDate?: string;

  @Column({ type: 'decimal', precision: 12, scale: 2, default: 0 })
  baseSalary!: number;

  @Column({ type: 'jsonb', nullable: true })
  bankDetails?: any;
}

import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { TenantConnectionService } from '../../../../database/tenant-connection.service';
import { Project, ProjectStatus } from '../entities/project.entity';

@Injectable()
export class ProjectsService {
  private readonly logger = new Logger(ProjectsService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('pms', tenantSlug);
    return ds.getRepository(Project);
  }

  async create(dto: Partial<Project>, tenantSlug: string): Promise<Project> {
    const repo = await this.getRepo(tenantSlug);
    const project = repo.create(dto);
    return repo.save(project);
  }

  async findAll(tenantSlug: string, filters: { status?: ProjectStatus; limit?: number; offset?: number }) {
    const repo = await this.getRepo(tenantSlug);
    const { status, limit = 10, offset = 0 } = filters;

    const query = repo.createQueryBuilder('p')
      .where('p.deleted_at IS NULL');

    if (status) {
      query.andWhere('p.status = :status', { status });
    }

    const [items, total] = await query
      .skip(offset)
      .take(limit)
      .orderBy('p.created_at', 'DESC')
      .getManyAndCount();

    return { items, total, limit, offset };
  }

  async findOne(id: string, tenantSlug: string): Promise<Project> {
    const repo = await this.getRepo(tenantSlug);
    const project = await repo.findOne({ where: { id } });
    if (!project) throw new NotFoundException('Project not found');
    return project;
  }
}

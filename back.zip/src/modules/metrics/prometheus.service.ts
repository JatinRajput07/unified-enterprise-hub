import { Injectable, OnModuleInit } from '@nestjs/common';
import { Registry, Gauge, Counter, Histogram, collectDefaultMetrics } from 'prom-client';

@Injectable()
export class PrometheusService implements OnModuleInit {
  private readonly registry: Registry;

  // New Metrics from Phase 10
  public readonly tenantActiveTotal: Gauge<string>;
  public readonly tenantProductSubscriptionsTotal: Gauge<string>;
  public readonly schemaProvisioningDuration: Histogram<string>;
  public readonly schemaProvisioningFailures: Counter<string>;
  public readonly productApiRequests: Counter<string>;
  public readonly billingWebhookEvents: Counter<string>;

  constructor() {
    this.registry = new Registry();
    this.registry.setDefaultLabels({ app: 'enterprise-crm' });
    collectDefaultMetrics({ register: this.registry });

    this.tenantActiveTotal = new Gauge({
      name: 'tenant_active_total',
      help: 'Total number of active tenants',
      registers: [this.registry],
    });

    this.tenantProductSubscriptionsTotal = new Gauge({
      name: 'tenant_product_subscriptions_total',
      help: 'Total subscriptions per product',
      labelNames: ['product'],
      registers: [this.registry],
    });

    this.schemaProvisioningDuration = new Histogram({
      name: 'schema_provisioning_duration_seconds',
      help: 'Time taken to provision schemas for a tenant',
      registers: [this.registry],
    });

    this.schemaProvisioningFailures = new Counter({
      name: 'schema_provisioning_failures_total',
      help: 'Total number of failed schema provisions',
      labelNames: ['product'],
      registers: [this.registry],
    });

    this.productApiRequests = new Counter({
      name: 'product_api_requests_total',
      help: 'Product-specific API request tracking',
      labelNames: ['product', 'tenantSlug', 'endpoint', 'status'],
      registers: [this.registry],
    });

    this.billingWebhookEvents = new Counter({
      name: 'billing_webhook_events_total',
      help: 'Total billing webhook events processed',
      labelNames: ['event_type', 'status'],
      registers: [this.registry],
    });
  }

  onModuleInit() {
    // Initialization if needed
  }

  async getMetrics(): Promise<string> {
    return this.registry.metrics();
  }
}

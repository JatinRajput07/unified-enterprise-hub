import {
  Injectable,
  CanActivate,
  ExecutionContext,
  NotFoundException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { FeatureFlagService } from './feature-flags.service';

@Injectable()
export class FeatureFlagGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly featureFlagService: FeatureFlagService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const flagName = this.reflector.get<string>(
      'feature-flag',
      context.getHandler(),
    );

    if (!flagName) return true;

    const request = context.switchToHttp().getRequest();
    const isEnabled = await this.featureFlagService.isEnabled(flagName, {
      userId: request.user?.id,
      tenantId: request.tenantId,
    });

    if (!isEnabled) {
      throw new NotFoundException(`Feature ${flagName} is not available`);
    }

    return true;
  }
}

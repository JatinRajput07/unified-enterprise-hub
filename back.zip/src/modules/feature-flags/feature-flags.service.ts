import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

export interface FeatureFlag {
  name: string;
  enabled: boolean;
  percentage?: number; // 0 to 100
  rules?: any;
}

@Injectable()
export class FeatureFlagService implements OnModuleInit {
  private readonly logger = new Logger(FeatureFlagService.name);
  private redis!: Redis;

  constructor(private readonly configService: ConfigService) {}

  onModuleInit(): void {
    const redisUrl = this.configService.get<string>('REDIS_URL') || 'redis://localhost:6379';
    this.redis = new Redis(redisUrl);
  }

  /**
   * Check if a feature flag is enabled for a specific context.
   */
  async isEnabled(
    flagName: string,
    context: { userId?: string; tenantId?: string } = {},
  ): Promise<boolean> {
    const key = `flag:global:${flagName}`;
    const tenantKey = context.tenantId ? `flag:${context.tenantId}:${flagName}` : null;

    // Try tenant-specific flag first
    if (tenantKey) {
      const tenantFlag = await this.getFlag(tenantKey);
      if (tenantFlag !== null) return this.evaluateFlag(tenantFlag, context);
    }

    // Fallback to global flag
    const globalFlag = await this.getFlag(key);
    if (globalFlag !== null) return this.evaluateFlag(globalFlag, context);

    // Default to false if not found
    return false;
  }

  private async getFlag(key: string): Promise<FeatureFlag | null> {
    const data = await this.redis.get(key);
    if (!data) return null;
    return JSON.parse(data) as FeatureFlag;
  }

  private evaluateFlag(flag: FeatureFlag, context: { userId?: string }): boolean {
    if (!flag.enabled) return false;
    
    // Percentage rollout logic
    if (flag.percentage !== undefined && flag.percentage < 100) {
      if (!context.userId) return false;
      // Simple hash-based percentage rollout
      const hash = this.stringToHash(context.userId);
      return (hash % 100) < flag.percentage;
    }

    return true;
  }

  private stringToHash(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash);
  }

  async setFlag(tenantId: string | 'global', flag: FeatureFlag): Promise<void> {
    const key = `flag:${tenantId}:${flag.name}`;
    await this.redis.set(key, JSON.stringify(flag));
    this.logger.log(`Feature flag updated: ${key} = ${flag.enabled} (${flag.percentage || 100}%)`);
  }
}

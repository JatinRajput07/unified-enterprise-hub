import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TenantEntity, TenantStatus } from '../tenants/entities/tenant.entity';
import { CacheService } from '../../common/cache/cache.service';
import { Cron, CronExpression } from '@nestjs/schedule';

@Injectable()
export class UsageTrackingService {
  private readonly logger = new Logger(UsageTrackingService.name);

  constructor(
    @InjectRepository(TenantEntity)
    private readonly tenantRepo: Repository<TenantEntity>,
    private readonly cacheService: CacheService,
  ) {}

  /**
   * Hourly job to flush usage data from Redis to the database.
   */
  @Cron(CronExpression.EVERY_HOUR)
  async flushUsageToDb() {
    this.logger.log('Starting hourly usage data flush...');
    
    const tenants = await this.tenantRepo.find({ where: { status: TenantStatus.ACTIVE } });
    
    for (const tenant of tenants) {
      const aiSpendKey = `usage:${tenant.slug}:ai_spend`;
      const storageKey = `usage:${tenant.slug}:storage_bytes`;
      
      const aiSpend = await this.cacheService.get<number>(aiSpendKey) || 0;
      const storageBytes = await this.cacheService.get<number>(storageKey) || 0;
      
      if (aiSpend > 0 || storageBytes > 0) {
        // In a real app, we would update a 'tenant_usage_logs' table
        this.logger.debug(`Flushing usage for ${tenant.slug}: AI=$${aiSpend}, Storage=${storageBytes} bytes`);
        
        // Reset counters in Redis after flush (or keep as rolling total)
        // await this.cacheService.set(aiSpendKey, 0);
      }
    }
    
    this.logger.log('Usage data flush completed.');
  }
}

import { Module, Global } from '@nestjs/common';
import { BillingService } from './billing.service';
import { BillingController } from './billing.controller';
import { StripeService } from './stripe.service';
import { UsageTrackingService } from './usage-tracking.service';
import { ScheduleModule } from '@nestjs/schedule';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TenantEntity } from '../tenants/entities/tenant.entity';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([TenantEntity]),
    ScheduleModule.forRoot(),
  ],
  providers: [BillingService, StripeService, UsageTrackingService],
  controllers: [BillingController],
  exports: [BillingService, StripeService],
})
export class BillingModule {}

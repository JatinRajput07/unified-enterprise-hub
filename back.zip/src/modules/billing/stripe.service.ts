import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';

@Injectable()
export class StripeService {
  private stripe: any;
  private readonly logger = new Logger(StripeService.name);

  constructor(private configService: ConfigService) {
    this.stripe = new Stripe(this.configService.get('STRIPE_SECRET_KEY') || 'sk_test_placeholder', {
      apiVersion: '2025-01-27' as any,
    });
  }

  async createCustomer(email: string, name: string, metadata?: Record<string, string>) {
    return this.stripe.customers.create({ 
      email, 
      name,
      metadata
    });
  }

  async createSubscription(customerId: string, priceId: string) {
    return this.stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
    });
  }
}

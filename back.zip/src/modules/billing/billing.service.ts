import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TenantEntity, TenantStatus } from '../tenants/entities/tenant.entity';
import { SchemaProvisionerService } from '../../database/schema-provisioner.service';
import { StripeService } from './stripe.service';

@Injectable()
export class BillingService {
  private readonly logger = new Logger(BillingService.name);

  constructor(
    @InjectRepository(TenantEntity)
    private readonly tenantRepo: Repository<TenantEntity>,
    private readonly stripeService: StripeService,
    private readonly schemaProvisioner: SchemaProvisionerService,
  ) {}

  async createCustomer(email: string, name: string, metadata?: Record<string, string>) {
    return this.stripeService.createCustomer(email, name, metadata);
  }

  async handleSubscriptionCreated(event: any) {
    const subscription = event.data.object;
    const customerId = subscription.customer;
    
    const tenant = await this.tenantRepo.findOne({ where: { stripeCustomerId: customerId } as any });
    if (!tenant) return;

    this.logger.log(`Subscription created for tenant: ${tenant.slug}`);
    
    // Activate tenant and provision schemas
  }

  async handleSubscriptionDeleted(event: any) {
    const subscription = event.data.object;
    const customerId = subscription.customer;

    const tenant = await this.tenantRepo.findOne({ where: { stripeCustomerId: customerId } as any });
    if (!tenant) return;

    this.logger.warn(`Subscription deleted for tenant: ${tenant.slug}. Suspending account.`);
    
    // 1. Suspend Tenant
    tenant.status = TenantStatus.SUSPENDED;
    await this.tenantRepo.save(tenant);
  }

  async handlePaymentFailed(event: any) {
    const invoice = event.data.object;
    this.logger.error(`Payment failed for invoice: ${invoice.id}`);
  }
}

import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import {
  HealthCheckService,
  HealthCheck,
  TypeOrmHealthIndicator,
  HealthCheckResult,
  HealthIndicatorResult,
} from '@nestjs/terminus';
import { Public } from '../../common/decorators/public.decorator';
import { SearchService } from '../search/search.service';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

import { TenantConnectionService } from '../../database/tenant-connection.service';

@ApiTags('Health')
@Controller('health')
export class HealthController {
  private readonly redis: Redis;

  constructor(
    private readonly health: HealthCheckService,
    private readonly db: TypeOrmHealthIndicator,
    private readonly searchService: SearchService,
    private readonly configService: ConfigService,
    private readonly tenantConn: TenantConnectionService,
  ) {
    this.redis = new Redis(
      this.configService.get<string>('REDIS_URL') || 'redis://localhost:6379',
    );
  }

  @Public()
  @Get()
  @HealthCheck()
  @ApiOperation({ summary: 'Basic health check' })
  check(): Promise<HealthCheckResult> {
    return this.health.check([
      () => this.db.pingCheck('database'),
    ]);
  }

  @Public()
  @Get('ready')
  @HealthCheck()
  @ApiOperation({ summary: 'Readiness check (all dependencies)' })
  readiness(): Promise<HealthCheckResult> {
    return this.health.check([
      () => this.db.pingCheck('database'),
      () => this.checkRedis(),
    ]);
  }

  @Public()
  @Get('detailed')
  @HealthCheck()
  @ApiOperation({ summary: 'Detailed health check with all services' })
  detailed(): Promise<HealthCheckResult> {
    return this.health.check([
      () => this.db.pingCheck('database'),
      () => this.checkRedis(),
      () => this.checkElasticSearch(),
      () => this.checkMemory(),
      () => this.checkProductDatabases(),
      () => this.checkTenantPool(),
    ]);
  }

  private async checkRedis(): Promise<HealthIndicatorResult> {
    try {
      await this.redis.ping();
      return { redis: { status: 'up' } };
    } catch {
      return { redis: { status: 'down' } };
    }
  }

  private async checkElasticSearch(): Promise<HealthIndicatorResult> {
    try {
      const isUp = await this.searchService.ping();
      return { elasticsearch: { status: isUp ? 'up' : 'down' } };
    } catch {
      return { elasticsearch: { status: 'down' } };
    }
  }

  private async checkMemory(): Promise<HealthIndicatorResult> {
    const memUsage = process.memoryUsage();
    const heapUsedMB = Math.round(memUsage.heapUsed / 1024 / 1024);
    const heapTotalMB = Math.round(memUsage.heapTotal / 1024 / 1024);
    const rssMB = Math.round(memUsage.rss / 1024 / 1024);

    return {
      memory: {
        status: heapUsedMB < 512 ? 'up' : 'down',
        heapUsedMB,
        heapTotalMB,
        rssMB,
      },
    };
  }

  private async checkProductDatabases(): Promise<HealthIndicatorResult> {
    const products = ['hrms', 'sales', 'pms', 'finance'];
    const results: any = {};
    
    for (const p of products) {
      try {
        // We ping with a dummy slug to check connectivity
        await this.tenantConn.getConnection(p as any, 'system_health_check');
        results[p] = { status: 'up' };
      } catch (e: any) {
        results[p] = { status: 'down', error: e.message };
      }
    }

    return { productDatabases: results };
  }

  private async checkTenantPool(): Promise<HealthIndicatorResult> {
    const stats = this.tenantConn.getPoolStats();
    return {
      tenantConnectionPool: {
        status: 'up',
        ...stats
      }
    };
  }
}

import { Module } from '@nestjs/common';
import { TerminusModule } from '@nestjs/terminus';
import { HealthController } from './health.controller';
import { SearchModule } from '../search/search.module';

@Module({
  imports: [TerminusModule, SearchModule],
  controllers: [HealthController],
})
export class HealthModule {}

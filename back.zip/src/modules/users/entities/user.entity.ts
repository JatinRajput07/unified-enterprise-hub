import {
  Entity,
  Column,
  ManyToMany,
  JoinTable,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { BaseEntity } from '../../../database/base.entity';
import { RoleEntity } from '../../roles/entities/role.entity';
import { TenantEntity } from '../../tenants/entities/tenant.entity';

export enum AuthProvider {
  LOCAL = 'local',
  GOOGLE = 'google',
  GITHUB = 'github',
}

@Entity('users')
export class UserEntity extends BaseEntity {
  @Column({ length: 255, nullable: true })
  @Index('IDX_USER_FIRST_NAME')
  firstName?: string;

  @Column({ length: 255, nullable: true })
  lastName?: string;

  @Column({ length: 255, unique: true })
  @Index('IDX_USER_EMAIL', { unique: true })
  email!: string;

  @Column({ length: 255, nullable: true, select: false })
  password?: string;

  @Column({ length: 20, nullable: true })
  phone?: string;

  @Column({ length: 500, nullable: true })
  avatar?: string;

  @Column({ default: true })
  isActive!: boolean;

  @Column({ default: false })
  isEmailVerified!: boolean;

  @Column({
    type: 'enum',
    enum: AuthProvider,
    default: AuthProvider.LOCAL,
  })
  authProvider!: AuthProvider;

  @Column({ nullable: true })
  providerId?: string;

  // 2FA fields
  @Column({ default: false })
  twoFaEnabled!: boolean;

  @Column({ nullable: true, select: false })
  twoFaSecret?: string; // AES-256 encrypted TOTP secret

  @Column({ type: 'jsonb', nullable: true, select: false })
  twoFaBackupCodes?: string[]; // Hashed backup codes

  // Login tracking
  @Column({ type: 'timestamptz', nullable: true })
  lastLoginAt?: Date;

  @Column({ nullable: true })
  lastLoginIp?: string;

  // Tenant relationship
  @Column({ type: 'uuid', nullable: true })
  tenantId?: string;

  @ManyToOne(() => TenantEntity, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn()
  tenant?: TenantEntity;

  // Roles relationship (many-to-many)
  @ManyToMany(() => RoleEntity, { eager: true })
  @JoinTable({ name: 'user_roles' })
  roles!: RoleEntity[];

  /**
   * Helper to get flat list of permission slugs from all roles.
   */
  get permissionSlugs(): string[] {
    if (!this.roles) return [];
    const perms = new Set<string>();
    for (const role of this.roles) {
      if (role.permissions) {
        for (const perm of role.permissions) {
          perms.add(perm.slug);
        }
      }
    }
    return Array.from(perms);
  }

  /**
   * Helper to get flat list of role names.
   */
  get roleNames(): string[] {
    if (!this.roles) return [];
    return this.roles.map((r) => r.name);
  }
}

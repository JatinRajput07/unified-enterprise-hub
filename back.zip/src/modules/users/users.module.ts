import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersService } from './users.service';
import { UsersController } from './users.controller';
import { ProfileController } from './profile.controller';
import { UserEntity } from './entities/user.entity';
import { UserSubscriber } from './users.subscriber';
import { SearchModule } from '../search/search.module';
import { RolesModule } from '../roles/roles.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([UserEntity]),
    SearchModule,
    RolesModule,
  ],
  controllers: [UsersController, ProfileController],
  providers: [UsersService, UserSubscriber],
  exports: [UsersService],
})
export class UsersModule {}

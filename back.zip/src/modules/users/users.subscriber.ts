import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import {
  EntitySubscriberInterface,
  EventSubscriber,
  InsertEvent,
  UpdateEvent,
  RemoveEvent,
  DataSource,
} from 'typeorm';
import { UserEntity } from './entities/user.entity';
import { SearchService } from '../search/search.service';
import { UserIndexMapping } from '../search/indices/users.index';

@EventSubscriber()
@Injectable()
export class UserSubscriber implements EntitySubscriberInterface<UserEntity>, OnModuleInit {
  private readonly logger = new Logger(UserSubscriber.name);

  constructor(
    private readonly dataSource: DataSource,
    private readonly searchService: SearchService,
  ) {}

  onModuleInit() {
    this.dataSource.subscribers.push(this);
    this.ensureIndex();
  }

  listenTo() {
    return UserEntity;
  }

  async afterInsert(event: InsertEvent<UserEntity>) {
    await this.syncToElasticSearch(event.entity);
  }

  async afterUpdate(event: UpdateEvent<UserEntity>) {
    if (event.entity) {
      await this.syncToElasticSearch(event.entity as UserEntity);
    }
  }

  async afterRemove(event: RemoveEvent<UserEntity>) {
    if (event.entityId) {
      await this.searchService.deleteDocument('users', event.entityId.toString());
    }
  }

  private async syncToElasticSearch(user: UserEntity) {
    try {
      await this.searchService.indexDocument('users', user.id, {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        fullName: `${user.firstName} ${user.lastName}`,
        tenantId: user.tenantId,
        isActive: user.isActive,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      });
    } catch (error) {
      this.logger.error(`Failed to sync user ${user.id} to ES: ${(error as Error).message}`);
    }
  }

  private async ensureIndex() {
    try {
      await this.searchService.ensureIndex('users', UserIndexMapping);
    } catch (error) {
      this.logger.warn(`Could not ensure index 'users': ${(error as Error).message}`);
    }
  }
}

import { Controller, Get, Patch, Body, UseGuards, Req } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { ProductAccessService } from '../org/product-access/product-access.service';
import { MembersService } from '../org/members/members.service';
import { UsersService } from './users.service';

@ApiTags('Profile')
@ApiBearerAuth()
@Controller('me')
export class ProfileController {
  constructor(
    private readonly productAccessService: ProductAccessService,
    private readonly membersService: MembersService,
    private readonly usersService: UsersService,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Get current user profile' })
  async getProfile(@CurrentUser('id') userId: string) {
    return this.usersService.findById(userId);
  }

  @Get('access')
  @ApiOperation({ summary: 'Get current user product access summary' })
  async getAccessSummary(
    @CurrentUser('id') userId: string,
    @Req() req: any,
  ) {
    const tenantSlug = req.tenantSlug || req.headers['x-tenant-slug'];
    return this.productAccessService.getUserAccessSummary(userId, tenantSlug);
  }

  @Get('departments')
  @ApiOperation({ summary: 'Get current user departments' })
  async getDepartments(
    @CurrentUser('id') userId: string,
    @Req() req: any,
  ) {
    const tenantSlug = req.tenantSlug || req.headers['x-tenant-slug'];
    return this.membersService.getUserDepartments(userId, tenantSlug);
  }

  @Get('teams')
  @ApiOperation({ summary: 'Get current user teams' })
  async getTeams(
    @CurrentUser('id') userId: string,
    @Req() req: any,
  ) {
    const tenantSlug = req.tenantSlug || req.headers['x-tenant-slug'];
    return this.membersService.getUserTeams(userId, tenantSlug);
  }

  @Patch('profile')
  @ApiOperation({ summary: 'Update own profile' })
  async updateProfile(
    @CurrentUser('id') userId: string,
    @Body() dto: { firstName?: string; lastName?: string; avatar?: string },
  ) {
    return this.usersService.update(userId, dto);
  }
}

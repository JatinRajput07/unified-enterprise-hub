import {
  Injectable,
  Logger,
  NotFoundException,
  ConflictException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserEntity, AuthProvider } from './entities/user.entity';
import { CreateUserDto, UpdateUserDto, UserResponseDto } from './dto/user.dto';
import { RolesService } from '../roles/roles.service';
import { hashPassword } from '../../common/utils/crypto.util';

@Injectable()
export class UsersService {
  private readonly logger = new Logger(UsersService.name);

  constructor(
    @InjectRepository(UserEntity)
    private readonly userRepository: Repository<UserEntity>,
    private readonly rolesService: RolesService,
  ) {}

  async create(dto: CreateUserDto, tenantId?: string): Promise<UserResponseDto> {
    const existing = await this.userRepository.findOne({
      where: { email: dto.email },
    });

    if (existing) {
      throw new ConflictException('User with this email already exists');
    }

    const hashedPassword = await hashPassword(dto.password);

    // Assign default USER role
    const defaultRole = await this.rolesService.findRoleByName('USER');

    const user = this.userRepository.create({
      firstName: dto.firstName,
      lastName: dto.lastName,
      email: dto.email,
      password: hashedPassword,
      phone: dto.phone,
      authProvider: AuthProvider.LOCAL,
      tenantId,
      roles: defaultRole ? [defaultRole] : [],
    });

    const saved = await this.userRepository.save(user);
    this.logger.log(`User created: ${saved.id} (${saved.email})`);
    return this.toResponseDto(saved);
  }

  async findById(id: string): Promise<UserEntity> {
    const user = await this.userRepository.findOne({
      where: { id },
      relations: ['roles', 'roles.permissions'],
    });
    if (!user) {
      throw new NotFoundException(`User not found: ${id}`);
    }
    return user;
  }

  async findByEmail(email: string): Promise<UserEntity | null> {
    return this.userRepository.findOne({
      where: { email },
      relations: ['roles', 'roles.permissions'],
      select: [
        'id', 'firstName', 'lastName', 'email', 'password',
        'isActive', 'isEmailVerified', 'authProvider', 'providerId',
        'twoFaEnabled', 'twoFaSecret', 'tenantId', 'createdAt', 'updatedAt',
      ],
    });
  }

  /**
   * Find user with secret fields (twoFaSecret, twoFaBackupCodes) for 2FA operations.
   */
  async findByIdWithSecret(id: string): Promise<UserEntity> {
    const user = await this.userRepository.findOne({
      where: { id },
      select: [
        'id', 'email', 'twoFaEnabled', 'twoFaSecret', 'twoFaBackupCodes',
        'isActive', 'isEmailVerified',
      ],
    });
    if (!user) {
      throw new NotFoundException(`User not found: ${id}`);
    }
    return user;
  }

  async findByProviderId(
    provider: AuthProvider,
    providerId: string,
  ): Promise<UserEntity | null> {
    return this.userRepository.findOne({
      where: { authProvider: provider, providerId },
      relations: ['roles', 'roles.permissions'],
    });
  }

  async update(id: string, dto: UpdateUserDto): Promise<UserResponseDto> {
    const user = await this.findById(id);
    Object.assign(user, dto);
    const saved = await this.userRepository.save(user);
    return this.toResponseDto(saved);
  }

  async updateLoginInfo(id: string, ip: string): Promise<void> {
    await this.userRepository.update(id, {
      lastLoginAt: new Date(),
      lastLoginIp: ip,
    });
  }

  async updatePassword(id: string, hashedPassword: string): Promise<void> {
    await this.userRepository.update(id, { password: hashedPassword });
  }

  async markEmailVerified(id: string): Promise<void> {
    await this.userRepository.update(id, { isEmailVerified: true });
  }

  async updateTwoFaSecret(id: string, encryptedSecret: string): Promise<void> {
    await this.userRepository.update(id, { twoFaSecret: encryptedSecret });
  }

  async updateBackupCodes(id: string, hashedBackupCodes: string[]): Promise<void> {
    await this.userRepository.update(id, { twoFaBackupCodes: hashedBackupCodes });
  }

  async enableTwoFa(id: string, hashedBackupCodes: string[]): Promise<void> {

    await this.userRepository.update(id, {
      twoFaEnabled: true,
      twoFaBackupCodes: hashedBackupCodes,
    });
  }

  async disableTwoFa(id: string): Promise<void> {
    await this.userRepository.update(id, {
      twoFaEnabled: false,
      twoFaSecret: undefined,
      twoFaBackupCodes: undefined,
    });
  }

  async findOrCreateOAuthUser(profile: {
    email: string;
    firstName?: string;
    lastName?: string;
    avatar?: string;
    provider: AuthProvider;
    providerId: string;
  }): Promise<UserEntity> {
    let user = await this.findByProviderId(profile.provider, profile.providerId);

    if (!user) {
      // Check if user exists with same email
      user = await this.userRepository.findOne({
        where: { email: profile.email },
        relations: ['roles', 'roles.permissions'],
      });

      if (user) {
        // Link existing user to OAuth provider
        user.authProvider = profile.provider;
        user.providerId = profile.providerId;
        if (!user.avatar && profile.avatar) {
          user.avatar = profile.avatar;
        }
        user.isEmailVerified = true;
        await this.userRepository.save(user);
      } else {
        // Create new user
        const defaultRole = await this.rolesService.findRoleByName('USER');
        user = this.userRepository.create({
          email: profile.email,
          firstName: profile.firstName,
          lastName: profile.lastName,
          avatar: profile.avatar,
          authProvider: profile.provider,
          providerId: profile.providerId,
          isEmailVerified: true,
          roles: defaultRole ? [defaultRole] : [],
        });
        user = await this.userRepository.save(user);
        this.logger.log(`OAuth user created: ${user.id} via ${profile.provider}`);
      }
    }

    return user;
  }

  async softDelete(id: string): Promise<void> {
    const user = await this.findById(id);
    await this.userRepository.softRemove(user);
    this.logger.log(`User soft deleted: ${id}`);
  }

  /**
   * Maps UserEntity to UserResponseDto (never exposes password/secrets).
   */
  toResponseDto(user: UserEntity): UserResponseDto {
    return {
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      phone: user.phone,
      avatar: user.avatar,
      isActive: user.isActive,
      isEmailVerified: user.isEmailVerified,
      authProvider: user.authProvider,
      twoFaEnabled: user.twoFaEnabled,
      roles: user.roleNames,
      permissions: user.permissionSlugs,
      tenantId: user.tenantId,
      createdAt: user.createdAt,
    };
  }
}


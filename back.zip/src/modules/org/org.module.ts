import { Module, Global } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Department } from './entities/department.entity';
import { Team } from './entities/team.entity';
import { ProductRole } from './entities/product-role.entity';
import { UserDepartment } from './entities/user-department.entity';
import { UserTeam } from './entities/user-team.entity';
import { DepartmentsService } from './departments/departments.service';
import { DepartmentsController } from './departments/departments.controller';
import { ProductAccessService } from './product-access/product-access.service';
import { ProductAccessController } from './product-access/product-access.controller';
import { ProductPermissionGuard } from './product-access/product-permission.guard';
import { MembersController } from './members/members.controller';
import { MembersService } from './members/members.service';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([Department, Team, ProductRole, UserDepartment, UserTeam]),
  ],
  controllers: [
    DepartmentsController,
    ProductAccessController,
    MembersController,
  ],
  providers: [
    DepartmentsService,
    ProductAccessService,
    ProductPermissionGuard,
    MembersService,
  ],
  exports: [
    DepartmentsService,
    ProductAccessService,
    ProductPermissionGuard,
    MembersService,
  ],
})
export class OrgModule {}

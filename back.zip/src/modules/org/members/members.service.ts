import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { ObjectLiteral } from 'typeorm';
import { TenantConnectionService } from '../../../database/tenant-connection.service';
import { UserDepartment } from '../entities/user-department.entity';
import { UserTeam } from '../entities/user-team.entity';
import { Department } from '../entities/department.entity';
import { Team } from '../entities/team.entity';
import { UserEntity } from '../../users/entities/user.entity';

@Injectable()
export class MembersService {
  private readonly logger = new Logger(MembersService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  private async getAuthRepo<T extends ObjectLiteral>(entity: any, tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('auth', tenantSlug);
    return ds.getRepository<T>(entity);
  }

  async assignDepartment(userId: string, departmentId: string, isPrimary: boolean, tenantSlug: string) {
    const deptRepo = await this.getAuthRepo<Department>(Department, tenantSlug);
    const userRepo = await this.getAuthRepo<UserEntity>(UserEntity, tenantSlug);
    const userDeptRepo = await this.getAuthRepo<UserDepartment>(UserDepartment, tenantSlug);

    const department = await deptRepo.findOne({ where: { id: departmentId } });
    if (!department) throw new NotFoundException('Department not found');

    const user = await userRepo.findOne({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');

    if (isPrimary) {
      // Set existing primary to false
      await userDeptRepo.update({ userId, isPrimary: true }, { isPrimary: false });
    }

    const assignment = userDeptRepo.create({
      userId,
      departmentId,
      isPrimary,
    });

    return userDeptRepo.save(assignment);
  }

  async removeDepartment(userId: string, departmentId: string, tenantSlug: string) {
    const userDeptRepo = await this.getAuthRepo<UserDepartment>(UserDepartment, tenantSlug);
    await userDeptRepo.delete({ userId, departmentId });
  }

  async assignTeam(userId: string, teamId: string, tenantSlug: string) {
    const teamRepo = await this.getAuthRepo<Team>(Team, tenantSlug);
    const userTeamRepo = await this.getAuthRepo<UserTeam>(UserTeam, tenantSlug);

    const team = await teamRepo.findOne({ where: { id: teamId } });
    if (!team) throw new NotFoundException('Team not found');

    const assignment = userTeamRepo.create({ userId, teamId });
    return userTeamRepo.save(assignment);
  }

  async removeTeam(userId: string, teamId: string, tenantSlug: string) {
    const userTeamRepo = await this.getAuthRepo<UserTeam>(UserTeam, tenantSlug);
    await userTeamRepo.delete({ userId, teamId });
  }

  async getUserDepartments(userId: string, tenantSlug: string) {
    const userDeptRepo = await this.getAuthRepo<UserDepartment>(UserDepartment, tenantSlug);
    return userDeptRepo.find({
      where: { userId },
      relations: ['department'],
    });
  }

  async getUserTeams(userId: string, tenantSlug: string) {
    const userTeamRepo = await this.getAuthRepo<UserTeam>(UserTeam, tenantSlug);
    return userTeamRepo.find({
      where: { userId },
      relations: ['team'],
    });
  }
}

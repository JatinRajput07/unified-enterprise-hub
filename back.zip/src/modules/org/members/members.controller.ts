import { Controller, Get, Post, Body, Param, Delete, Query, UseGuards } from '@nestjs/common';
import { MembersService } from './members.service';
import { RequiresProductPermission } from '../product-access/product-permission.decorator';

@Controller('org/members')
export class MembersController {
  constructor(private readonly membersService: MembersService) {}

  @Post(':userId/departments')
  @RequiresProductPermission('auth', 'members:manage')
  assignDepartment(
    @Param('userId') userId: string,
    @Body() dto: { departmentId: string; isPrimary?: boolean },
    @Query('tenantSlug') tenantSlug: string,
  ) {
    return this.membersService.assignDepartment(userId, dto.departmentId, !!dto.isPrimary, tenantSlug);
  }

  @Delete(':userId/departments/:departmentId')
  @RequiresProductPermission('auth', 'members:manage')
  removeDepartment(
    @Param('userId') userId: string,
    @Param('departmentId') departmentId: string,
    @Query('tenantSlug') tenantSlug: string,
  ) {
    return this.membersService.removeDepartment(userId, departmentId, tenantSlug);
  }

  @Post(':userId/teams')
  @RequiresProductPermission('auth', 'members:manage')
  assignTeam(
    @Param('userId') userId: string,
    @Body() dto: { teamId: string },
    @Query('tenantSlug') tenantSlug: string,
  ) {
    return this.membersService.assignTeam(userId, dto.teamId, tenantSlug);
  }

  @Delete(':userId/teams/:teamId')
  @RequiresProductPermission('auth', 'members:manage')
  removeTeam(
    @Param('userId') userId: string,
    @Param('teamId') teamId: string,
    @Query('tenantSlug') tenantSlug: string,
  ) {
    return this.membersService.removeTeam(userId, teamId, tenantSlug);
  }

  @Get(':userId/summary')
  getUserSummary(
    @Param('userId') userId: string,
    @Query('tenantSlug') tenantSlug: string,
  ) {
    return Promise.all([
      this.membersService.getUserDepartments(userId, tenantSlug),
      this.membersService.getUserTeams(userId, tenantSlug),
    ]).then(([departments, teams]) => ({ departments, teams }));
  }
}

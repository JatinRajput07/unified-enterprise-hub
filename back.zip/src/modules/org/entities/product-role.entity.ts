import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, ManyToOne, JoinColumn, Index, Unique } from 'typeorm';
import { UserEntity } from '../../users/entities/user.entity';
import { ProductName } from '../../../database/product-db.constants';

@Entity('product_roles')
@Unique(['userId', 'productName', 'revokedAt'])
export class ProductRole {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ name: 'user_id', type: 'uuid' })
  @Index()
  userId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'user_id' })
  user!: UserEntity;

  @Column({
    name: 'product_name',
    type: 'varchar',
  })
  productName!: ProductName;

  @Column({ name: 'role_name' })
  roleName!: string;

  @Column({ type: 'text', array: true, name: 'custom_permissions', nullable: true })
  customPermissions?: string[];

  @Column({ name: 'granted_by_user_id', type: 'uuid' })
  grantedByUserId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'granted_by_user_id' })
  grantedBy!: UserEntity;

  @CreateDateColumn({ name: 'granted_at' })
  grantedAt!: Date;

  @Column({ name: 'revoked_at', type: 'timestamptz', nullable: true })
  @Index()
  revokedAt?: Date;
}

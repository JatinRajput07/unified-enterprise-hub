import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Query } from '@nestjs/common';
import { DepartmentsService } from './departments.service';
import { RequiresProductPermission } from '../product-access/product-permission.decorator';

@Controller('org/departments')
export class DepartmentsController {
  constructor(private readonly departmentsService: DepartmentsService) {}

  @Post()
  @RequiresProductPermission('auth', 'departments:manage')
  create(@Body() dto: any, @Query('tenantSlug') tenantSlug: string) {
    return this.departmentsService.create(dto, tenantSlug);
  }

  @Get()
  @RequiresProductPermission('auth', 'departments:read')
  findAll(@Query('tenantSlug') tenantSlug: string) {
    return this.departmentsService.findAllAsTree(tenantSlug);
  }

  @Get(':id')
  @RequiresProductPermission('auth', 'departments:read')
  findOne(@Param('id') id: string, @Query('tenantSlug') tenantSlug: string) {
    return this.departmentsService.findOne(id, tenantSlug);
  }
}

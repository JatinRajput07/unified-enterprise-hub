import { Injectable, Logger, ConflictException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, IsNull } from 'typeorm';
import { Department } from '../entities/department.entity';
import { TenantConnectionService } from '../../../database/tenant-connection.service';

@Injectable()
export class DepartmentsService {
  private readonly logger = new Logger(DepartmentsService.name);

  constructor(private readonly tenantConn: TenantConnectionService) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('auth', tenantSlug);
    return ds.getRepository(Department);
  }

  async create(dto: { name: string; slug: string; description?: string; parentId?: string }, tenantSlug: string) {
    const repo = await this.getRepo(tenantSlug);
    
    const existing = await repo.findOne({ where: { slug: dto.slug } });
    if (existing) throw new ConflictException('Department slug already exists');

    if (dto.parentId) {
      const parent = await repo.findOne({ where: { id: dto.parentId } });
      if (!parent) throw new NotFoundException('Parent department not found');
    }

    const dept = repo.create({
      ...dto,
      parentDepartmentId: dto.parentId,
    });

    return repo.save(dept);
  }

  async findAllAsTree(tenantSlug: string) {
    const repo = await this.getRepo(tenantSlug);
    const all = await repo.find();
    
    const idMap: Record<string, any> = {};
    all.forEach(d => {
      idMap[d.id] = { ...d, children: [] };
    });

    const tree: any[] = [];
    all.forEach(d => {
      if (d.parentDepartmentId) {
        idMap[d.parentDepartmentId].children.push(idMap[d.id]);
      } else {
        tree.push(idMap[d.id]);
      }
    });

    return tree;
  }

  async findOne(id: string, tenantSlug: string) {
    const repo = await this.getRepo(tenantSlug);
    const dept = await repo.findOne({ where: { id }, relations: ['parent'] });
    if (!dept) throw new NotFoundException('Department not found');
    return dept;
  }
}

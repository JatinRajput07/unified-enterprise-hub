import { Controller, Get, Post, Body, Param, Delete, Query, UseGuards } from '@nestjs/common';
import { ProductAccessService } from './product-access.service';
import { ProductName } from '../../../database/product-db.constants';
import { RequiresProductPermission } from './product-permission.decorator';

@Controller('org/users/:userId/product-access')
export class ProductAccessController {
  constructor(private readonly productAccessService: ProductAccessService) {}

  @Post()
  @RequiresProductPermission('auth', 'access:manage')
  grantAccess(
    @Param('userId') userId: string,
    @Body() dto: { product: ProductName; roleName: string; customPermissions?: string[] },
    @Query('tenantSlug') tenantSlug: string,
    @Body('grantedByUserId') grantedByUserId: string, // Simplified
  ) {
    return this.productAccessService.grantAccess({
      targetUserId: userId,
      product: dto.product,
      roleName: dto.roleName,
      customPermissions: dto.customPermissions,
      grantedByUserId,
      tenantSlug,
    });
  }

  @Delete(':product')
  @RequiresProductPermission('auth', 'access:manage')
  revokeAccess(
    @Param('userId') userId: string,
    @Param('product') product: ProductName,
    @Query('tenantSlug') tenantSlug: string,
  ) {
    return this.productAccessService.revokeAccess(userId, product, tenantSlug);
  }
}

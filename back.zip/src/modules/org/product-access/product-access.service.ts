import { Injectable, Logger, ForbiddenException } from '@nestjs/common';
import { DataSource, IsNull } from 'typeorm';
import { TenantConnectionService } from '../../../database/tenant-connection.service';
import { CacheService } from '../../../common/cache/cache.service';
import { ProductRole } from '../entities/product-role.entity';
import { ProductName } from '../../../database/product-db.constants';
import { PRODUCT_ROLES } from './product-roles.constants';
import { TenantEntity } from '../../tenants/entities/tenant.entity';
import { TenantProductSubscription } from '../../super-admin/entities/tenant-product-subscription.entity';
import { NotFoundException } from '@nestjs/common';

@Injectable()
export class ProductAccessService {
  private readonly logger = new Logger(ProductAccessService.name);

  constructor(
    private readonly tenantConn: TenantConnectionService,
    private readonly cacheService: CacheService,
  ) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('auth', tenantSlug);
    return ds.getRepository(ProductRole);
  }

  /**
   * Check if a user has a specific permission for a product.
   */
  async checkPermission(
    userId: string,
    product: ProductName,
    permission: string,
    tenantSlug: string,
  ): Promise<boolean> {
    const cacheKey = `perm:${tenantSlug}:${userId}:${product}`;
    
    // 1. Try Cache
    let permissions = await this.cacheService.get<string[]>(cacheKey);
    
    if (!permissions) {
      // 2. Fetch from DB
      const repo = await this.getRepo(tenantSlug);
      const activeRole = await repo.findOne({
        where: { userId, productName: product, revokedAt: IsNull() },
      });

      if (!activeRole) {
        permissions = [];
      } else {
        // Expand role permissions
        const defaultPerms = (PRODUCT_ROLES as any)[product]?.[activeRole.roleName] || [];
        permissions = [...defaultPerms, ...(activeRole.customPermissions || [])];
      }

      // 3. Set Cache (5 mins)
      await this.cacheService.set(cacheKey, permissions, 300);
    }

    // 4. Wildcard Check
    if (permissions.includes('*') || permissions.includes(`${permission.split(':')[0]}:*`)) {
      return true;
    }

    return permissions.includes(permission);
  }

  async grantAccess(params: {
    targetUserId: string;
    product: ProductName;
    roleName: string;
    customPermissions?: string[];
    grantedByUserId: string;
    tenantSlug: string;
  }): Promise<void> {
    const repo = await this.getRepo(params.tenantSlug);

    // 1. Verify if tenant has active subscription to this product
    const authPublicDs = await this.tenantConn.getConnection('auth', 'public');
    const tenantRepo = authPublicDs.getRepository(TenantEntity);
    const tenant = await tenantRepo.findOne({ where: { slug: params.tenantSlug } });
    
    if (!tenant) throw new NotFoundException('Tenant not found');

    const subRepo = authPublicDs.getRepository(TenantProductSubscription);
    const subscription = await subRepo.findOne({
      where: { tenantId: tenant.id, productName: params.product, status: 'active' },
    });

    if (!subscription) {
      throw new ForbiddenException(`Tenant does not have an active subscription for ${params.product}`);
    }

    // Revoke existing access
    await repo.update(
      { userId: params.targetUserId, productName: params.product, revokedAt: IsNull() },
      { revokedAt: new Date() },
    );

    // Grant new access
    const newRole = repo.create({
      userId: params.targetUserId,
      productName: params.product,
      roleName: params.roleName,
      customPermissions: params.customPermissions,
      grantedByUserId: params.grantedByUserId,
    });

    await repo.save(newRole);

    // Invalidate cache
    await this.cacheService.del(`perm:${params.tenantSlug}:${params.targetUserId}:${params.product}`);
  }

  async revokeAccess(userId: string, product: ProductName, tenantSlug: string): Promise<void> {
    const repo = await this.getRepo(tenantSlug);
    await repo.update(
      { userId, productName: product, revokedAt: IsNull() },
      { revokedAt: new Date() },
    );
    await this.cacheService.del(`perm:${tenantSlug}:${userId}:${product}`);
  }

  async getUserAccessSummary(userId: string, tenantSlug: string) {
    const repo = await this.getRepo(tenantSlug);
    const activeRoles = await repo.find({
      where: { userId, revokedAt: IsNull() },
      relations: ['grantedBy'],
    });

    return activeRoles.map(role => ({
      product: role.productName,
      roleName: role.roleName,
      permissions: [
        ...((PRODUCT_ROLES as any)[role.productName]?.[role.roleName] || []),
        ...(role.customPermissions || []),
      ],
      grantedBy: {
        id: role.grantedBy?.id,
        name: `${role.grantedBy?.firstName} ${role.grantedBy?.lastName}`,
      },
      grantedAt: role.grantedAt,
    }));
  }
}

import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ProductAccessService } from './product-access.service';
import { PRODUCT_KEY, PERMISSION_KEY } from './product-permission.decorator';
import { ProductName } from '../../../database/product-db.constants';

@Injectable()
export class ProductPermissionGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    private productAccessService: ProductAccessService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const product = this.reflector.get<ProductName>(PRODUCT_KEY, context.getHandler());
    const permission = this.reflector.get<string>(PERMISSION_KEY, context.getHandler());

    if (!product || !permission) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;
    const tenantSlug = request.tenantSlug;

    if (!user || !tenantSlug) {
      return false;
    }

    // 1. ORG_ADMIN Bypass
    if (user.role === 'ORG_ADMIN') {
      return true;
    }

    // 2. Check Product-Level Permission
    const hasPermission = await this.productAccessService.checkPermission(
      user.id,
      product,
      permission,
      tenantSlug,
    );

    if (!hasPermission) {
      throw new ForbiddenException(`Insufficient permissions for product: ${product}`);
    }

    return true;
  }
}

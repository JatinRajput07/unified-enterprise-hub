export const PRODUCT_ROLES = {
  hrms: {
    hr_admin:    ['employees:*','leaves:*','payroll:*','departments:read','reports:read'],
    hr_manager:  ['employees:read','employees:update','leaves:approve','leaves:read','payroll:read'],
    hr_viewer:   ['employees:read','leaves:read'],
  },
  sales: {
    crm_admin:   ['leads:*','deals:*','contacts:*','pipeline:*','reports:*'],
    sales_rep:   ['leads:create','leads:read','leads:update','deals:read','deals:update','contacts:read'],
    crm_viewer:  ['leads:read','deals:read','contacts:read'],
  },
  pms: {
    pms_admin:   ['projects:*','tasks:*','timesheets:*','reports:*'],
    project_lead:['projects:read','tasks:*','timesheets:read'],
    member:      ['tasks:read','tasks:update','timesheets:create','timesheets:read'],
  },
  finance: {
    finance_admin:  ['invoices:*','budget:*','payroll:*','reports:*'],
    accountant:     ['invoices:*','budget:read','payroll:read'],
    finance_viewer: ['invoices:read','budget:read'],
  },
} as const;

export type ProductRoleName<T extends keyof typeof PRODUCT_ROLES> = keyof (typeof PRODUCT_ROLES)[T];

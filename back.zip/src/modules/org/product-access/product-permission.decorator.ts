import { SetMetadata, applyDecorators, UseGuards } from '@nestjs/common';
import { ProductName } from '../../../database/product-db.constants';

export const PRODUCT_KEY = 'product';
export const PERMISSION_KEY = 'permission';

/**
 * Decorator to require a specific product and permission.
 */
export const RequiresProductPermission = (product: ProductName, permission: string) => {
  return applyDecorators(
    SetMetadata(PRODUCT_KEY, product),
    SetMetadata(PERMISSION_KEY, permission),
  );
};

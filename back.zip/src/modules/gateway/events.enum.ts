/**
 * Centralized socket event name constants.
 * All event names used across gateway modules should be defined here.
 */
export enum SocketEvents {
  // Connection
  CONNECTION = 'connection',
  DISCONNECT = 'disconnect',
  ERROR = 'error',

  // Presence
  USER_ONLINE = 'user:online',
  USER_OFFLINE = 'user:offline',
  PRESENCE_UPDATE = 'presence:update',
  HEARTBEAT = 'heartbeat',

  // Notifications
  NOTIFICATION = 'notification',
  NOTIFICATION_READ = 'notification:read',

  // WebRTC Signaling
  WEBRTC_OFFER = 'webrtc:offer',
  WEBRTC_ANSWER = 'webrtc:answer',
  WEBRTC_ICE_CANDIDATE = 'webrtc:ice-candidate',
  WEBRTC_ROOM_JOIN = 'webrtc:room:join',
  WEBRTC_ROOM_LEAVE = 'webrtc:room:leave',
  WEBRTC_ROOM_FULL = 'webrtc:room:full',
  WEBRTC_PEER_JOINED = 'webrtc:peer:joined',
  WEBRTC_PEER_LEFT = 'webrtc:peer:left',

  // Generic
  MESSAGE = 'message',
  BROADCAST = 'broadcast',
  ENTITY_CREATED = 'entity:created',
  ENTITY_UPDATED = 'entity:updated',
  ENTITY_DELETED = 'entity:deleted',
}

export enum SocketRooms {
  USER = 'user',
  TENANT = 'tenant',
  RESOURCE = 'resource',
}

/**
 * Build a room name for a user
 */
export function userRoom(userId: string): string {
  return `${SocketRooms.USER}:${userId}`;
}

/**
 * Build a room name for a tenant
 */
export function tenantRoom(tenantId: string): string {
  return `${SocketRooms.TENANT}:${tenantId}`;
}

/**
 * Build a room name for a specific resource
 */
export function resourceRoom(resourceType: string, resourceId: string): string {
  return `${SocketRooms.RESOURCE}:${resourceType}:${resourceId}`;
}

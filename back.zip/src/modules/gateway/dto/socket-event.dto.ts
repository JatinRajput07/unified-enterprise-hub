import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class SocketMessageDto {
  @IsString()
  @IsNotEmpty()
  event!: string;

  @IsNotEmpty()
  data!: unknown;

  @IsOptional()
  @IsString()
  room?: string;
}

export class HeartbeatDto {
  @IsString()
  @IsNotEmpty()
  userId!: string;

  @IsOptional()
  @IsString()
  tenantId?: string;
}

export interface SocketUserData {
  id: string;
  email: string;
  roles: string[];
  permissions: string[];
  tenantId?: string;
}

import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

const PRESENCE_TTL = 60; // seconds — heartbeat must renew within this window

@Injectable()
export class PresenceService {
  private readonly logger = new Logger(PresenceService.name);
  private readonly redis: Redis;

  constructor(private readonly configService: ConfigService) {
    this.redis = new Redis(
      this.configService.get<string>('REDIS_URL') || 'redis://localhost:6379',
    );
  }

  /**
   * Mark a user as online for a given tenant.
   */
  async setOnline(userId: string, tenantId?: string): Promise<void> {
    const key = this.presenceKey(tenantId);
    await this.redis.hset(key, userId, Date.now().toString());
    await this.redis.expire(key, PRESENCE_TTL * 10); // key-level TTL
    this.logger.debug(`User online: ${userId} (tenant: ${tenantId || 'global'})`);
  }

  /**
   * Mark a user as offline.
   */
  async setOffline(userId: string, tenantId?: string): Promise<void> {
    const key = this.presenceKey(tenantId);
    await this.redis.hdel(key, userId);
    this.logger.debug(`User offline: ${userId} (tenant: ${tenantId || 'global'})`);
  }

  /**
   * Heartbeat — update the user's last seen timestamp.
   */
  async heartbeat(userId: string, tenantId?: string): Promise<void> {
    const key = this.presenceKey(tenantId);
    await this.redis.hset(key, userId, Date.now().toString());
  }

  /**
   * Get all online users for a tenant.
   */
  async getOnlineUsers(tenantId?: string): Promise<string[]> {
    const key = this.presenceKey(tenantId);
    const presence = await this.redis.hgetall(key);
    const now = Date.now();
    const onlineUsers: string[] = [];

    for (const [userId, timestamp] of Object.entries(presence)) {
      // Consider user online if heartbeat was within TTL window
      if (now - parseInt(timestamp, 10) < PRESENCE_TTL * 1000) {
        onlineUsers.push(userId);
      } else {
        // Stale entry — clean up
        await this.redis.hdel(key, userId);
      }
    }

    return onlineUsers;
  }

  /**
   * Check if a specific user is online.
   */
  async isOnline(userId: string, tenantId?: string): Promise<boolean> {
    const key = this.presenceKey(tenantId);
    const timestamp = await this.redis.hget(key, userId);
    if (!timestamp) return false;

    const now = Date.now();
    return now - parseInt(timestamp, 10) < PRESENCE_TTL * 1000;
  }

  private presenceKey(tenantId?: string): string {
    return tenantId ? `presence:${tenantId}` : 'presence:global';
  }

  async onModuleDestroy(): Promise<void> {
    await this.redis.quit();
  }
}

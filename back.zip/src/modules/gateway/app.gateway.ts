import {
  WebSocketGateway,
  WebSocketServer,
  OnGatewayConnection,
  OnGatewayDisconnect,
  OnGatewayInit,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Logger, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { Server, Socket } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import Redis from 'ioredis';
import { PresenceService } from './presence.service';
import { SocketEvents, userRoom, tenantRoom } from './events.enum';
import { SocketUserData } from './dto/socket-event.dto';

/**
 * Rate limit tracker for socket events per user.
 */
interface RateLimitEntry {
  count: number;
  resetAt: number;
}

@WebSocketGateway({
  cors: {
    origin: '*',
    credentials: true,
  },
  namespace: '/',
  transports: ['websocket', 'polling'],
})
export class AppGateway
  implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server!: Server;

  private readonly logger = new Logger(AppGateway.name);
  private readonly rateLimits = new Map<string, RateLimitEntry>();
  private readonly RATE_LIMIT_WINDOW = 60000; // 1 minute
  private readonly RATE_LIMIT_MAX = 100; // max events per window

  constructor(
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    private readonly presenceService: PresenceService,
  ) {}

  async afterInit(server: Server): Promise<void> {
    // Setup Redis adapter for multi-instance scaling
    try {
      const redisUrl = this.configService.get<string>('REDIS_URL') || 'redis://localhost:6379';
      const pubClient = new Redis(redisUrl);
      const subClient = pubClient.duplicate();

      server.adapter(createAdapter(pubClient, subClient) as ReturnType<typeof createAdapter>);
      this.logger.log('Socket.io Redis adapter connected');
    } catch (error) {
      this.logger.warn(
        `Failed to connect Redis adapter, falling back to in-memory: ${(error as Error).message}`,
      );
    }

    this.logger.log('WebSocket Gateway initialized');
  }

  async handleConnection(client: Socket): Promise<void> {
    try {
      const user = this.authenticateSocket(client);
      client.data.user = user;

      // Join user-specific room
      await client.join(userRoom(user.id));

      // Join tenant room if applicable
      if (user.tenantId) {
        await client.join(tenantRoom(user.tenantId));
      }

      // Update presence
      await this.presenceService.setOnline(user.id, user.tenantId);

      // Notify tenant room
      if (user.tenantId) {
        client.to(tenantRoom(user.tenantId)).emit(SocketEvents.USER_ONLINE, {
          userId: user.id,
          timestamp: new Date().toISOString(),
        });
      }

      this.logger.log(`Client connected: ${client.id} (user: ${user.id})`);
    } catch {
      this.logger.warn(`Unauthorized connection attempt: ${client.id}`);
      client.emit(SocketEvents.ERROR, { message: 'Authentication failed' });
      client.disconnect();
    }
  }

  async handleDisconnect(client: Socket): Promise<void> {
    const user = client.data.user as SocketUserData | undefined;
    if (!user) return;

    // Update presence
    await this.presenceService.setOffline(user.id, user.tenantId);

    // Notify tenant room
    if (user.tenantId) {
      client.to(tenantRoom(user.tenantId)).emit(SocketEvents.USER_OFFLINE, {
        userId: user.id,
        timestamp: new Date().toISOString(),
      });
    }

    // Clean up rate limit entries
    this.rateLimits.delete(client.id);

    this.logger.log(`Client disconnected: ${client.id} (user: ${user.id})`);
  }

  @SubscribeMessage(SocketEvents.HEARTBEAT)
  async handleHeartbeat(
    @ConnectedSocket() client: Socket,
  ): Promise<{ status: string }> {
    const user = client.data.user as SocketUserData;
    if (user) {
      await this.presenceService.heartbeat(user.id, user.tenantId);
    }
    return { status: 'ok' };
  }

  @SubscribeMessage(SocketEvents.MESSAGE)
  handleMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { room?: string; event: string; payload: unknown },
  ): void {
    const user = client.data.user as SocketUserData;
    if (!user) return;

    // Rate limiting
    if (!this.checkRateLimit(client.id)) {
      client.emit(SocketEvents.ERROR, {
        message: 'Rate limit exceeded. Please slow down.',
      });
      return;
    }

    if (data.room) {
      client.to(data.room).emit(data.event, {
        ...data.payload as Record<string, unknown>,
        senderId: user.id,
        timestamp: new Date().toISOString(),
      });
    }
  }

  // =====================
  // Public methods for other modules to emit events
  // =====================

  /**
   * Emit an event to a specific user.
   */
  emitToUser(userId: string, event: string, data: unknown): void {
    this.server.to(userRoom(userId)).emit(event, data);
  }

  /**
   * Emit an event to all users in a tenant.
   */
  emitToTenant(tenantId: string, event: string, data: unknown): void {
    this.server.to(tenantRoom(tenantId)).emit(event, data);
  }

  /**
   * Broadcast an event to all connected clients.
   */
  broadcast(event: string, data: unknown): void {
    this.server.emit(event, data);
  }

  // =====================
  // Private Helpers
  // =====================

  private authenticateSocket(client: Socket): SocketUserData {
    const token =
      client.handshake.auth?.token ||
      client.handshake.headers?.authorization?.replace('Bearer ', '');

    if (!token) {
      throw new UnauthorizedException('No token provided');
    }

    const secret = this.configService.get<string>('JWT_SECRET');
    const payload = this.jwtService.verify(token, { secret });

    return {
      id: payload.sub,
      email: payload.email,
      roles: payload.roles || [],
      permissions: payload.permissions || [],
      tenantId: payload.tenantId,
    };
  }

  private checkRateLimit(clientId: string): boolean {
    const now = Date.now();
    const entry = this.rateLimits.get(clientId);

    if (!entry || now > entry.resetAt) {
      this.rateLimits.set(clientId, {
        count: 1,
        resetAt: now + this.RATE_LIMIT_WINDOW,
      });
      return true;
    }

    entry.count++;
    return entry.count <= this.RATE_LIMIT_MAX;
  }
}

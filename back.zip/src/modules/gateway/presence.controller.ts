import { Controller, Get, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiResponse } from '@nestjs/swagger';
import { PresenceService } from '../gateway/presence.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('Presence')
@ApiBearerAuth()
@Controller({ path: 'presence', version: '1' })
export class PresenceController {
  constructor(private readonly presenceService: PresenceService) {}

  @Get('online')
  @ApiOperation({ summary: 'Get all online users for the current tenant' })
  @ApiResponse({ status: 200, description: 'List of online user IDs' })
  async getOnlineUsers(
    @CurrentUser('tenantId') tenantId?: string,
  ): Promise<string[]> {
    return this.presenceService.getOnlineUsers(tenantId);
  }

  @Get('online/count')
  @ApiOperation({ summary: 'Get count of online users for the current tenant' })
  async getOnlineCount(
    @CurrentUser('tenantId') tenantId?: string,
  ): Promise<{ count: number }> {
    const users = await this.presenceService.getOnlineUsers(tenantId);
    return { count: users.length };
  }
}

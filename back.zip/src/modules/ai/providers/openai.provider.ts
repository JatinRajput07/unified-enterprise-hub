import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { IAIProvider, AIResponse } from '../interfaces/ai-provider.interface';

@Injectable()
export class OpenAIProvider implements IAIProvider {
  private readonly logger = new Logger(OpenAIProvider.name);
  private client: OpenAI | null = null;

  constructor(private readonly configService: ConfigService) {
    const apiKey = this.configService.get<string>('OPENAI_API_KEY');
    if (apiKey) {
      this.client = new OpenAI({ apiKey });
    }
  }

  async complete(
    prompt: string,
    options: any = {},
  ): Promise<AIResponse> {
    if (!this.client) throw new Error('OpenAI client not initialized');

    const start = Date.now();
    const response = await this.client.chat.completions.create({
      model: options.model || 'gpt-4o-mini',
      messages: [
        ...(options.systemMessage ? [{ role: 'system' as const, content: options.systemMessage }] : []),
        { role: 'user', content: prompt },
      ],
      temperature: options.temperature || 0.7,
      max_tokens: options.maxTokens || 1000,
    });
    const end = Date.now();

    const usage = response.usage!;
    return {
      content: response.choices[0].message.content || '',
      model: response.model,
      inputTokens: usage.prompt_tokens,
      outputTokens: usage.completion_tokens,
      cost: this.calculateCost(response.model, usage.prompt_tokens, usage.completion_tokens),
      latency: end - start,
    };
  }

  private calculateCost(model: string, input: number, output: number): number {
    // Pricing for gpt-4o-mini (approximate)
    if (model.includes('gpt-4o-mini')) {
      return (input / 1000000) * 0.15 + (output / 1000000) * 0.6;
    }
    return 0;
  }
}

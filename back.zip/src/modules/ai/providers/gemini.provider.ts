import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { IAIProvider, AIResponse } from '../interfaces/ai-provider.interface';

@Injectable()
export class GeminiProvider implements IAIProvider {
  private readonly logger = new Logger(GeminiProvider.name);
  private genAI: GoogleGenerativeAI | null = null;

  constructor(private readonly configService: ConfigService) {
    const apiKey = this.configService.get<string>('GEMINI_API_KEY');
    if (apiKey) {
      this.genAI = new GoogleGenerativeAI(apiKey);
    }
  }

  async complete(
    prompt: string,
    options: any = {},
  ): Promise<AIResponse> {
    if (!this.genAI) throw new Error('Gemini client not initialized');

    const start = Date.now();
    const model = this.genAI.getGenerativeModel({ 
      model: options.model || 'gemini-1.5-flash',
      systemInstruction: options.systemMessage,
    });

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    const end = Date.now();

    // Gemini 1.5 flash usage calculation (placeholder as it's free for now or varies)
    return {
      content: text,
      model: options.model || 'gemini-1.5-flash',
      inputTokens: prompt.length / 4, // Rough approximation
      outputTokens: text.length / 4,
      cost: 0,
      latency: end - start,
    };
  }
}

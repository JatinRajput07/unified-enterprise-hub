import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { OpenAIProvider } from './providers/openai.provider';
import { GeminiProvider } from './providers/gemini.provider';
import { IAIProvider, AIResponse } from './interfaces/ai-provider.interface';
import { AIUsageLog } from './entities/ai-log.entity';

@Injectable()
export class AIService {
  private readonly logger = new Logger(AIService.name);
  private provider: IAIProvider;

  constructor(
    private readonly configService: ConfigService,
    private readonly openai: OpenAIProvider,
    private readonly gemini: GeminiProvider,
    @InjectRepository(AIUsageLog)
    private readonly logRepository: Repository<AIUsageLog>,
  ) {
    const driver = this.configService.get<string>('AI_DRIVER') || 'gemini';
    this.provider = driver === 'openai' ? this.openai : this.gemini;
    this.logger.log(`AI Service initialized with driver: ${driver}`);
  }

  async chat(
    userId: string,
    tenantId: string,
    prompt: string,
    options: {
      promptKey?: string;
      systemMessage?: string;
      temperature?: number;
      maxTokens?: number;
    } = {},
  ): Promise<string> {
    // Check cost limits (simplified)
    await this.checkCostLimit(tenantId);

    try {
      const response = await this.provider.complete(prompt, options);

      // Log usage
      await this.logRepository.save({
        userId,
        tenantId,
        model: response.model,
        inputTokens: response.inputTokens,
        outputTokens: response.outputTokens,
        cost: response.cost,
        latency: response.latency,
        promptKey: options.promptKey,
      });

      return response.content;
    } catch (error) {
      this.logger.error(`AI call failed: ${(error as Error).message}`);
      throw error;
    }
  }

  private async checkCostLimit(tenantId: string) {
    // In a real app, aggregation query on AIUsageLog for current month
    // For now, it's a placeholder
    const monthlyLimit = this.configService.get<number>('AI_MONTHLY_LIMIT_USD') || 50;
    // this.logger.debug(`Checking AI limit for tenant ${tenantId} (Limit: ${monthlyLimit})`);
  }
}

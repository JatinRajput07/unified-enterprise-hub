import { Entity, Column, ManyToOne, JoinColumn, Index } from 'typeorm';
import { BaseEntity } from '../../../database/base.entity';
import { UserEntity } from '../../users/entities/user.entity';
import { TenantEntity } from '../../tenants/entities/tenant.entity';

@Entity('ai_usage_logs')
export class AIUsageLog extends BaseEntity {
  @Column({ name: 'user_id', type: 'uuid' })
  @Index()
  userId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'user_id' })
  user!: UserEntity;

  @Column({ name: 'tenant_id', type: 'uuid' })
  @Index()
  tenantId!: string;

  @ManyToOne(() => TenantEntity)
  @JoinColumn({ name: 'tenant_id' })
  tenant!: TenantEntity;

  @Column()
  model!: string;

  @Column({ name: 'input_tokens', type: 'int' })
  inputTokens!: number;

  @Column({ name: 'output_tokens', type: 'int' })
  outputTokens!: number;

  @Column({ type: 'decimal', precision: 10, scale: 6 })
  cost!: number;

  @Column({ type: 'int' }) // in ms
  latency!: number;

  @Column({ nullable: true })
  promptKey?: string;

  @Column({ type: 'text', nullable: true })
  metadata?: string;
}

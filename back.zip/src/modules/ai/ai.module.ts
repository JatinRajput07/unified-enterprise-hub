import { Module, Global } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AIService } from './ai.service';
import { OpenAIProvider } from './providers/openai.provider';
import { GeminiProvider } from './providers/gemini.provider';
import { AIUsageLog } from './entities/ai-log.entity';

@Global()
@Module({
  imports: [TypeOrmModule.forFeature([AIUsageLog])],
  providers: [AIService, OpenAIProvider, GeminiProvider],
  exports: [AIService],
})
export class AIModule {}

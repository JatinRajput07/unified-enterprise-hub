export interface AIResponse {
  content: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
  cost: number;
  latency: number;
}

export interface IAIProvider {
  complete(
    prompt: string,
    options?: {
      temperature?: number;
      maxTokens?: number;
      systemMessage?: string;
    },
  ): Promise<AIResponse>;
}

import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, DeleteDateColumn } from 'typeorm';

@Entity('plans', { schema: 'public' })
export class Plan {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  name!: string;

  @Column({ unique: true })
  slug!: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @Column({ type: 'decimal', precision: 10, scale: 2, name: 'price_monthly' })
  priceMonthly!: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, name: 'price_yearly' })
  priceYearly!: number;

  @Column({ name: 'stripe_product_id', nullable: true })
  stripeProductId?: string;

  @Column({ name: 'stripe_price_id_monthly', nullable: true })
  stripePriceIdMonthly?: string;

  @Column({ name: 'stripe_price_id_yearly', nullable: true })
  stripePriceIdYearly?: string;

  @Column({ type: 'jsonb', nullable: true })
  features?: string[];

  @Column({ type: 'jsonb', nullable: true })
  modules?: string[];

  @Column({ name: 'max_users', type: 'int', default: 5 })
  maxUsers!: number;

  @Column({ name: 'max_storage_gb', type: 'int', default: 1 })
  maxStorageGb!: number;

  @Column({ name: 'ai_cost_limit_usd', type: 'decimal', precision: 10, scale: 2, default: 0 })
  aiCostLimitUsd!: number;

  @Column({ name: 'is_active', default: true })
  isActive!: boolean;

  @Column({ name: 'is_publicly_visible', default: true })
  isPubliclyVisible!: boolean;

  @Column({ name: 'sort_order', type: 'int', default: 0 })
  sortOrder!: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt!: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt!: Date;

  @DeleteDateColumn({ name: 'deleted_at' })
  deletedAt?: Date;
}

import { Injectable, NestMiddleware, Logger } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { TenantsService } from './tenants.service';

/**
 * Middleware that extracts tenant context from the request.
 * Priority order:
 * 1. X-Tenant-ID header
 * 2. Subdomain from Host header
 */
@Injectable()
export class TenantMiddleware implements NestMiddleware {
  private readonly logger = new Logger(TenantMiddleware.name);

  constructor(private readonly tenantsService: TenantsService) {}

  async use(req: Request, _res: Response, next: NextFunction): Promise<void> {
    let tenant = null;

    // 1. Check X-Tenant-ID header
    const tenantId = req.headers['x-tenant-id'] as string;
    if (tenantId) {
      try {
        tenant = await this.tenantsService.findById(tenantId);
      } catch {
        this.logger.debug(`Tenant not found by ID: ${tenantId}`);
      }
    }

    // 2. Try subdomain extraction from Host header
    if (!tenant) {
      const host = req.headers.host;
      if (host) {
        const subdomain = this.extractSubdomain(host);
        if (subdomain) {
          tenant = await this.tenantsService.findBySubdomain(subdomain);
        }
      }
    }

    // Attach tenant to request
    if (tenant) {
      (req as any).tenant = tenant;
      (req as any).tenantId = tenant.id;
      (req as any).tenantSlug = tenant.slug;
    }

    next();
  }

  private extractSubdomain(host: string): string | null {
    // Remove port
    const hostname = host.split(':')[0];
    const parts = hostname.split('.');

    // Need at least 3 parts for a subdomain (sub.domain.tld)
    if (parts.length >= 3) {
      return parts[0];
    }

    return null;
  }
}

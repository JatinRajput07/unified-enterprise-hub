import { Injectable, NotFoundException, ConflictException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TenantEntity, TenantStatus } from './entities/tenant.entity';

@Injectable()
export class TenantsService {
  private readonly logger = new Logger(TenantsService.name);

  constructor(
    @InjectRepository(TenantEntity)
    private readonly tenantRepository: Repository<TenantEntity>,
  ) {}

  async create(data: {
    name: string;
    slug: string;
    subdomain: string;
    customDomain?: string;
    planId: string;
    settings?: any;
  }): Promise<TenantEntity> {
    const existing = await this.tenantRepository.findOne({
      where: [{ subdomain: data.subdomain }, { slug: data.slug }],
    });

    if (existing) {
      throw new ConflictException(`Tenant with subdomain "${data.subdomain}" or slug "${data.slug}" already exists`);
    }

    const tenant = this.tenantRepository.create({
      name: data.name,
      slug: data.slug,
      subdomain: data.subdomain,
      customDomain: data.customDomain,
      planId: data.planId,
      status: TenantStatus.PENDING,
      settings: data.settings || {},
    });

    const saved = await this.tenantRepository.save(tenant);
    this.logger.log(`Tenant created: ${saved.id} (${saved.subdomain})`);
    return saved;
  }

  async findById(id: string): Promise<TenantEntity> {
    const tenant = await this.tenantRepository.findOne({ where: { id } });
    if (!tenant) {
      throw new NotFoundException(`Tenant not found: ${id}`);
    }
    return tenant;
  }

  async findBySubdomain(subdomain: string): Promise<TenantEntity | null> {
    return this.tenantRepository.findOne({ where: { subdomain } });
  }

  async findBySlug(slug: string): Promise<TenantEntity | null> {
    return this.tenantRepository.findOne({ where: { slug } });
  }

  async findByDomain(customDomain: string): Promise<TenantEntity | null> {
    return this.tenantRepository.findOne({ where: { customDomain } });
  }

  async update(
    id: string,
    data: Partial<TenantEntity>,
  ): Promise<TenantEntity> {
    const tenant = await this.findById(id);
    Object.assign(tenant, data);
    return this.tenantRepository.save(tenant);
  }

  async softDelete(id: string): Promise<void> {
    const tenant = await this.findById(id);
    await this.tenantRepository.softRemove(tenant);
    this.logger.log(`Tenant soft deleted: ${id}`);
  }

  async findAll(): Promise<TenantEntity[]> {
    return this.tenantRepository.find({ where: { status: TenantStatus.ACTIVE } });
  }
}

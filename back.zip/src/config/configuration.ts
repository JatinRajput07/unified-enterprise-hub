import * as Joi from 'joi';

export const validationSchema = Joi.object({
  // Application
  APP_PORT: Joi.number().default(3000),
  APP_ENV: Joi.string()
    .valid('development', 'staging', 'production', 'test')
    .default('development'),
  APP_NAME: Joi.string().default('EnterpriseCRM'),
  APP_URL: Joi.string().uri().default('http://localhost:3000'),

  // Database (Primary)
  DB_HOST: Joi.string().required(),
  DB_PORT: Joi.number().default(5432),
  DB_NAME: Joi.string().required(),
  DB_USER: Joi.string().required(),
  DB_PASS: Joi.string().required(),

  // Redis
  REDIS_URL: Joi.string().required(),

  // JWT RS256
  JWT_PRIVATE_KEY_PATH: Joi.string().required(),
  JWT_PUBLIC_KEY_PATH: Joi.string().required(),
  JWT_ACCESS_EXPIRES_SECONDS: Joi.number().default(900),
  JWT_REFRESH_EXPIRES_SECONDS: Joi.number().default(604800),

  // Encryption
  ENCRYPTION_KEY: Joi.string().length(32).required(),
  ENCRYPTION_IV: Joi.string().length(16).required(),

  // Brute Force
  MAX_LOGIN_ATTEMPTS: Joi.number().default(5),
  LOCK_DURATION_MINUTES: Joi.number().default(15),

  // OTP
  OTP_EXPIRY_MINUTES: Joi.number().default(15),
  EMAIL_VERIFY_OTP_EXPIRY_MINUTES: Joi.number().default(10),

  // OAuth - Google
  GOOGLE_CLIENT_ID: Joi.string().allow('').optional(),
  GOOGLE_CLIENT_SECRET: Joi.string().allow('').optional(),
  GOOGLE_CALLBACK_URL: Joi.string().allow('').optional(),

  // OAuth - GitHub
  GITHUB_CLIENT_ID: Joi.string().allow('').optional(),
  GITHUB_CLIENT_SECRET: Joi.string().allow('').optional(),
  GITHUB_CALLBACK_URL: Joi.string().allow('').optional(),

  // Frontend
  FRONTEND_URL: Joi.string().uri().default('http://localhost:5173'),

  // CORS
  ALLOWED_ORIGINS: Joi.string().default('http://localhost:5173'),

  // 2FA
  TWO_FA_APP_NAME: Joi.string().default('EnterpriseCRM'),

  // Swagger
  SWAGGER_ENABLED: Joi.boolean().default(true),

  // Logging
  LOG_LEVEL: Joi.string()
    .valid('error', 'warn', 'info', 'debug', 'verbose')
    .default('debug'),
  LOG_DIR: Joi.string().default('logs'),

  // Rate Limiting
  THROTTLE_TTL: Joi.number().default(60000),
  THROTTLE_LIMIT: Joi.number().default(100),
});

export const configuration = () => ({
  app: {
    port: parseInt(process.env.APP_PORT || '3000', 10),
    env: process.env.APP_ENV || 'development',
    name: process.env.APP_NAME || 'EnterpriseCRM',
    url: process.env.APP_URL || 'http://localhost:3000',
  },
  database: {
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT || '5432', 10),
    name: process.env.DB_NAME,
    user: process.env.DB_USER,
    pass: process.env.DB_PASS,
  },
  redis: {
    url: process.env.REDIS_URL,
  },
  jwt: {
    privateKeyPath: process.env.JWT_PRIVATE_KEY_PATH,
    publicKeyPath: process.env.JWT_PUBLIC_KEY_PATH,
    accessExpiresIn: parseInt(process.env.JWT_ACCESS_EXPIRES_SECONDS || '900', 10),
    refreshExpiresIn: parseInt(process.env.JWT_REFRESH_EXPIRES_SECONDS || '604800', 10),
  },
  security: {
    encryptionKey: process.env.ENCRYPTION_KEY,
    encryptionIv: process.env.ENCRYPTION_IV,
    maxLoginAttempts: parseInt(process.env.MAX_LOGIN_ATTEMPTS || '5', 10),
    lockDurationMinutes: parseInt(process.env.LOCK_DURATION_MINUTES || '15', 10),
    otpExpiryMinutes: parseInt(process.env.OTP_EXPIRY_MINUTES || '15', 10),
    emailVerifyOtpExpiryMinutes: parseInt(process.env.EMAIL_VERIFY_OTP_EXPIRY_MINUTES || '10', 10),
  },
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackUrl: process.env.GOOGLE_CALLBACK_URL,
  },
  github: {
    clientId: process.env.GITHUB_CLIENT_ID,
    clientSecret: process.env.GITHUB_CLIENT_SECRET,
    callbackUrl: process.env.GITHUB_CALLBACK_URL,
  },
  frontend: {
    url: process.env.FRONTEND_URL || 'http://localhost:5173',
  },
  cors: {
    origins: (process.env.ALLOWED_ORIGINS || 'http://localhost:5173')
      .split(',')
      .map((origin) => origin.trim()),
  },
  twoFa: {
    appName: process.env.TWO_FA_APP_NAME || 'EnterpriseCRM',
  },
  swagger: {
    enabled: process.env.SWAGGER_ENABLED === 'true',
  },
  logging: {
    level: process.env.LOG_LEVEL || 'debug',
    dir: process.env.LOG_DIR || 'logs',
  },
  throttle: {
    ttl: parseInt(process.env.THROTTLE_TTL || '60000', 10),
    limit: parseInt(process.env.THROTTLE_LIMIT || '100', 10),
  },
});

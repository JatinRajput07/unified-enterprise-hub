import { registerAs } from '@nestjs/config';

export type ProductName = 'auth' | 'sales' | 'hrms' | 'pms' | 'finance';

export const databaseConfig = registerAs('database', () => ({
  auth: {
    host: process.env.AUTH_DB_HOST || process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.AUTH_DB_PORT || process.env.DB_PORT || '5432', 10),
    name: process.env.AUTH_DB_NAME || 'auth_db',
    user: process.env.AUTH_DB_USER || process.env.DB_USER || 'postgres',
    pass: process.env.AUTH_DB_PASS || process.env.DB_PASS || 'postgres',
    poolMax: parseInt(process.env.AUTH_DB_POOL_MAX || '20', 10),
  },
  sales: {
    host: process.env.SALES_DB_HOST || process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.SALES_DB_PORT || process.env.DB_PORT || '5432', 10),
    name: process.env.SALES_DB_NAME || 'sales_db',
    user: process.env.SALES_DB_USER || process.env.DB_USER || 'postgres',
    pass: process.env.SALES_DB_PASS || process.env.DB_PASS || 'postgres',
  },
  hrms: {
    host: process.env.HRMS_DB_HOST || process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.HRMS_DB_PORT || process.env.DB_PORT || '5432', 10),
    name: process.env.HRMS_DB_NAME || 'hrms_db',
    user: process.env.HRMS_DB_USER || process.env.DB_USER || 'postgres',
    pass: process.env.HRMS_DB_PASS || process.env.DB_PASS || 'postgres',
  },
  pms: {
    host: process.env.PMS_DB_HOST || process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.PMS_DB_PORT || process.env.DB_PORT || '5432', 10),
    name: process.env.PMS_DB_NAME || 'pms_db',
    user: process.env.PMS_DB_USER || process.env.DB_USER || 'postgres',
    pass: process.env.PMS_DB_PASS || process.env.DB_PASS || 'postgres',
  },
  finance: {
    host: process.env.FINANCE_DB_HOST || process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.FINANCE_DB_PORT || process.env.DB_PORT || '5432', 10),
    name: process.env.FINANCE_DB_NAME || 'finance_db',
    user: process.env.FINANCE_DB_USER || process.env.DB_USER || 'postgres',
    pass: process.env.FINANCE_DB_PASS || process.env.DB_PASS || 'postgres',
  },
  synchronize: process.env.APP_ENV !== 'production',
  logging: process.env.APP_ENV === 'development',
}));

export const readonlyDatabaseConfig = registerAs('readonlyDatabase', () => ({
  host: process.env.READONLY_DB_HOST || process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.READONLY_DB_PORT || process.env.DB_PORT || '5432', 10),
  name: process.env.READONLY_DB_NAME || 'readonly_db',
  user: process.env.READONLY_DB_USER || process.env.DB_USER || 'postgres',
  pass: process.env.READONLY_DB_PASS || process.env.DB_PASS || 'postgres',
}));

# Enterprise CRM SaaS Production Runbook

## 1. Multi-Tenant Infrastructure

### Adding a New Product Database
1. Update `src/database/product-db.constants.ts` to include the new product name.
2. Add corresponding `database.<product>` entries in `database.config.ts`.
3. Update `TenantConnectionService` entity map for the new product.
4. Deploy with new environment variables for the new DB host/pass.

### Manual Tenant Schema Provisioning
If a Stripe webhook failed to trigger provisioning:
```bash
npm run cli:provision -- --tenant=<slug> --products=hrms,sales,finance
```

## 2. Emergency Procedures

### Tenant Suspension
To manually suspend a tenant and block API access:
1. Update `tenants` table: `UPDATE tenants SET status = 'suspended' WHERE slug = 'tenant-slug';`
2. Clear Redis cache: `redis-cli DEL "tenant:tenant-slug"`

### Connection Pool Exhaustion
If the API logs "Too many connections":
1. Identify the hogging tenant via `GET /health/detailed`.
2. Check `tenantConnectionPool` stats.
3. Restart pods to force-clear the `TenantConnectionService` in-memory Map.

## 3. Maintenance

### Consistency Checks
The system runs a CronJob every 6 hours (`tenant-schema-consistency-check`) to verify that all active subscriptions have corresponding physical schemas in product databases.

### Schema Updates
When adding new tables to a product:
1. Since we use `synchronize: false` for tenants, you must use the `SchemaProvisionerService` to apply migrations or use `synchronize: true` temporarily during maintenance windows via a CLI flag.

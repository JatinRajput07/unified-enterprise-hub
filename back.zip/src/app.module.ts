import { Module, MiddlewareConsumer, NestModule } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { APP_GUARD, APP_FILTER, APP_INTERCEPTOR, APP_PIPE } from '@nestjs/core';
import { ThrottlerModule } from '@nestjs/throttler';
import { ThrottlerStorageRedisService } from 'nestjs-throttler-storage-redis';
import { BullModule } from '@nestjs/bullmq';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { ScheduleModule } from '@nestjs/schedule';
import Redis from 'ioredis';
import { SnakeNamingStrategy } from './common/utils/snake-naming.strategy';

// Config
import { configuration, validationSchema } from './config/configuration';
import { appConfig } from './config/app.config';
import { databaseConfig, readonlyDatabaseConfig } from './config/database.config';
import { redisConfig } from './config/redis.config';
import { jwtConfig } from './config/jwt.config';

// Entities that MUST exist in the main Auth/Registry connection
import { TenantEntity } from './modules/tenants/entities/tenant.entity';
import { Plan } from './modules/tenants/entities/plan.entity';
import { TenantSubscription } from './modules/super-admin/entities/tenant-subscription.entity';
import { TenantProductSubscription } from './modules/super-admin/entities/tenant-product-subscription.entity';
import { RoleEntity } from './modules/roles/entities/role.entity';
import { PermissionEntity } from './modules/roles/entities/permission.entity';
import { UserEntity } from './modules/users/entities/user.entity';
import { SessionEntity } from './modules/auth/entities/session.entity';
import { AuthLogEntity } from './modules/auth/entities/auth-log.entity';

import { ProductModuleEntity } from './modules/super-admin/entities/product-module.entity';

// Common
import { GlobalExceptionFilter } from './common/filters/global-exception.filter';
import { ResponseTransformInterceptor } from './common/interceptors/response-transform.interceptor';
import { LoggingInterceptor } from './common/interceptors/logging.interceptor';
import { TimeoutInterceptor } from './common/interceptors/timeout.interceptor';
import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { EnhancedThrottlerGuard } from './common/guards/throttler.guard';
import { RequestIdMiddleware } from './common/middleware/request-id.middleware';
import { DeprecationMiddleware } from './common/middleware/deprecation.middleware';
import { CacheModule } from './common/cache/cache.module';
import { CacheInterceptor } from './common/cache/cache.interceptor';
import { SanitizationPipe } from './common/pipes/sanitization.pipe';

// Feature Modules
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { RolesModule } from './modules/roles/roles.module';
import { TenantsModule } from './modules/tenants/tenants.module';
import { GatewayModule } from './modules/gateway/gateway.module';
import { WebRtcModule } from './modules/webrtc/webrtc.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { SearchModule } from './modules/search/search.module';
import { HealthModule } from './modules/health/health.module';
import { QueueModule } from './modules/queue/queue.module';
import { StorageModule } from './modules/storage/storage.module';
import { FeatureFlagsModule } from './modules/feature-flags/feature-flags.module';
import { TransportModule } from './modules/transport/transport.module';
import { AIModule } from './modules/ai/ai.module';
import { AuditModule } from './modules/audit/audit.module';
import { BillingModule } from './modules/billing/billing.module';
import { AutomationModule } from './modules/automation/automation.module';
import { AuditInterceptor } from './modules/audit/audit.interceptor';
import { SuperAdminModule } from './modules/super-admin/super-admin.module';
import { DatabaseCoreModule } from './database/database-core.module';
import { OrgModule } from './modules/org/org.module';
import { ProductPermissionGuard } from './modules/org/product-access/product-permission.guard';

// Product Modules
import { HRMSModule } from './modules/products/hrms/hrms.module';
import { CRMModule } from './modules/products/crm/crm.module';
import { FinanceModule } from './modules/products/finance/finance.module';

import { MetricsModule } from './modules/metrics/metrics.module';

@Module({
  imports: [
    MetricsModule,
    ConfigModule.forRoot({
      isGlobal: true,
      load: [configuration, appConfig, databaseConfig, readonlyDatabaseConfig, redisConfig, jwtConfig],
      validationSchema,
    }),

    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        type: 'postgres',
        host: configService.get<string>('database.auth.host'),
        port: configService.get<number>('database.auth.port'),
        username: configService.get<string>('database.auth.user'),
        password: configService.get<string>('database.auth.pass'),
        database: configService.get<string>('database.auth.name'),
        // Only load registry and identity entities. 
        // Product entities (Leads, Invoices, etc.) are NOT here.
        entities: [
          TenantEntity, Plan, TenantSubscription, TenantProductSubscription, ProductModuleEntity,
          UserEntity, RoleEntity, PermissionEntity, SessionEntity, AuthLogEntity
        ],
        synchronize: configService.get<boolean>('database.synchronize'),
        logging: configService.get<boolean>('database.logging'),
        namingStrategy: new SnakeNamingStrategy(),
        extra: {
          max: configService.get<number>('database.auth.poolMax'),
          min: 2,
        },
      }),
      inject: [ConfigService],
    }),

    // Infrastructure
    CacheModule,
    ThrottlerModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        throttlers: [{ ttl: 60000, limit: 100 }],
        storage: new ThrottlerStorageRedisService(new Redis(configService.get<string>('REDIS_URL')!)),
      }),
      inject: [ConfigService],
    }),
    BullModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        connection: { url: configService.get<string>('REDIS_URL')! },
      }),
      inject: [ConfigService],
    }),
    QueueModule,
    EventEmitterModule.forRoot({ wildcard: true }),
    ScheduleModule.forRoot(),

    // Core Modules
    StorageModule,
    FeatureFlagsModule,
    TransportModule,
    AuditModule,
    AIModule,
    BillingModule,
    AutomationModule,
    DatabaseCoreModule,
    SuperAdminModule,
    OrgModule,
    HRMSModule,
    CRMModule,
    FinanceModule,
    AuthModule,
    UsersModule,
    RolesModule,
    TenantsModule,
    GatewayModule,
    WebRtcModule,
    NotificationsModule,
    SearchModule,
    HealthModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: EnhancedThrottlerGuard },
    { provide: APP_FILTER, useClass: GlobalExceptionFilter },
    { provide: APP_PIPE, useClass: SanitizationPipe },
    { provide: APP_INTERCEPTOR, useClass: ResponseTransformInterceptor },
    { provide: APP_INTERCEPTOR, useClass: LoggingInterceptor },
    { provide: APP_INTERCEPTOR, useClass: TimeoutInterceptor },
    { provide: APP_INTERCEPTOR, useClass: CacheInterceptor },
    { provide: APP_INTERCEPTOR, useClass: AuditInterceptor },
    { provide: APP_GUARD, useClass: ProductPermissionGuard },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(RequestIdMiddleware).forRoutes('*');
    consumer.apply(DeprecationMiddleware).forRoutes('*');
    const { TenantMiddleware } = require('./modules/tenants/tenant.middleware');
    consumer.apply(TenantMiddleware).forRoutes('*');
  }
}

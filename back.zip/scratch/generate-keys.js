const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

function generateKeys() {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength: 4096,
    publicKeyEncoding: {
      type: 'spki',
      format: 'pem',
    },
    privateKeyEncoding: {
      type: 'pkcs8',
      format: 'pem',
    },
  });

  const keysDir = path.join(__dirname, '..', 'keys');
  if (!fs.existsSync(keysDir)) {
    fs.mkdirSync(keysDir);
  }

  fs.writeFileSync(path.join(keysDir, 'private.pem'), privateKey);
  fs.writeFileSync(path.join(keysDir, 'public.pem'), publicKey);

  console.log('✅ RSA Keys generated successfully in /keys directory');
  console.log('\n--- PRIVATE KEY (Copy to JWT_PRIVATE_KEY in .env) ---');
  console.log(privateKey.toString().replace(/\n/g, '\\n'));
  console.log('\n--- PUBLIC KEY (Copy to JWT_PUBLIC_KEY in .env) ---');
  console.log(publicKey.toString().replace(/\n/g, '\\n'));
}

generateKeys();

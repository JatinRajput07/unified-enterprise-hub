const { Client } = require('pg');
require('dotenv').config();

async function checkTenants() {
  const client = new Client({
    host: process.env.AUTH_DB_HOST || process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.AUTH_DB_PORT || process.env.DB_PORT || '5432'),
    user: process.env.AUTH_DB_USER || process.env.DB_USER || 'postgres',
    password: process.env.AUTH_DB_PASS || process.env.DB_PASS || 'root',
    database: process.env.AUTH_DB_NAME || 'auth_db',
  });

  try {
    await client.connect();
    const res = await client.query('SELECT id, name, slug FROM tenants');
    console.log('Tenants in auth_db:', res.rows);
  } catch (err) {
    console.error('Error:', err.message);
  } finally {
    await client.end();
  }
}

checkTenants();

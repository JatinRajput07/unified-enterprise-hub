const { Client } = require('pg');
require('dotenv').config();

const dbs = ['auth_db', 'sales_db', 'hrms_db', 'finance_db'];

async function inspectAll() {
  for (const dbName of dbs) {
    const client = new Client({
      host: process.env.DB_HOST || 'localhost',
      port: 5432,
      user: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASS || 'root',
      database: dbName,
    });

    try {
      await client.connect();
      console.log(`\n🔍 Inspecting ${dbName}:`);
      
      const schemas = await client.query("SELECT nspname FROM pg_namespace WHERE nspname NOT LIKE 'pg_%' AND nspname != 'information_schema' ORDER BY nspname DESC");
      
      const tenantSchemas = schemas.rows.map(r => r.nspname).filter(n => n !== 'public');
      console.log(`   Total tenant schemas:`, tenantSchemas.length);

      // Check the MOST RECENT tenant (from the end of the list)
      const lastTenant = tenantSchemas[0]; 
      if (lastTenant) {
        const tables = await client.query(`SELECT table_name FROM information_schema.tables WHERE table_schema = '${lastTenant}'`);
        console.log(`   Tables in [${lastTenant}]:`, tables.rows.map(r => r.table_name));
      }

    } catch (err) {
      console.error(`   Error:`, err.message);
    } finally {
      await client.end();
    }
  }
}

inspectAll();

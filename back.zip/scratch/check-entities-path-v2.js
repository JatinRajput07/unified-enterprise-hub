const glob = require('glob');
const path = require('path');

const entityPath = path.join(process.cwd(), 'src/modules/**/*.entity{.ts,.js}');
console.log('Searching for entities in:', entityPath);

const files = glob.sync(entityPath);
console.log('Found', files.length, 'entities:');
files.forEach(f => console.log(' -', f));

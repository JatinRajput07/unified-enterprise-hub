const { Client } = require('pg');
require('dotenv').config();

const dbs = ['auth_db', 'sales_db', 'hrms_db', 'finance_db'];

async function inspectAll() {
  for (const dbName of dbs) {
    const client = new Client({
      host: process.env.DB_HOST || 'localhost',
      port: 5432,
      user: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASS || 'root',
      database: dbName,
    });

    try {
      await client.connect();
      console.log(`\n🔍 Inspecting ${dbName}:`);
      
      const schemas = await client.query("SELECT nspname FROM pg_namespace WHERE nspname NOT LIKE 'pg_%' AND nspname != 'information_schema'");
      console.log(`   Schemas:`, schemas.rows.map(r => r.nspname).filter(n => n !== 'public').length, 'tenant schemas found');

      const firstTenant = schemas.rows.find(r => r.nspname !== 'public')?.nspname;
      if (firstTenant) {
        const tables = await client.query(`SELECT table_name FROM information_schema.tables WHERE table_schema = '${firstTenant}'`);
        console.log(`   Tables in [${firstTenant}]:`, tables.rows.map(r => r.table_name));
      }

      const publicTables = await client.query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
      console.log(`   Tables in [public]:`, publicTables.rows.map(r => r.table_name));

    } catch (err) {
      console.error(`   Error:`, err.message);
    } finally {
      await client.end();
    }
  }
}

inspectAll();

const glob = require('glob');
const path = require('path');

const entityPath = path.join(__dirname, '../modules/**/entities/*.entity.{ts,js}');
console.log('Searching for entities in:', entityPath);

const files = glob.sync(entityPath);
console.log('Found', files.length, 'entities:');
files.forEach(f => console.log(' -', path.basename(f)));

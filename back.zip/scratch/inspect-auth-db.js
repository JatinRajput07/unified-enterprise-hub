const { Client } = require('pg');
require('dotenv').config();

async function inspectAuthDb() {
  const client = new Client({
    host: process.env.DB_HOST || 'localhost',
    port: 5432,
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASS || 'root',
    database: 'auth_db',
  });

  try {
    await client.connect();
    
    // 1. List Schemas
    const schemas = await client.query("SELECT nspname FROM pg_namespace WHERE nspname NOT LIKE 'pg_%' AND nspname != 'information_schema'");
    console.log('Schemas in auth_db:', schemas.rows.map(r => r.nspname));

    // 2. Sample tables in a tenant schema (first one found)
    const tenantSchema = schemas.rows.find(r => r.nspname !== 'public')?.nspname;
    if (tenantSchema) {
      const tables = await client.query(`SELECT table_name FROM information_schema.tables WHERE table_schema = '${tenantSchema}'`);
      console.log(`Tables in ${tenantSchema} schema:`, tables.rows.map(r => r.table_name));
    }

    // 3. Tables in public schema
    const publicTables = await client.query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
    console.log('Tables in public schema:', publicTables.rows.map(r => r.table_name));

  } catch (err) {
    console.error('Error:', err.message);
  } finally {
    await client.end();
  }
}

inspectAuthDb();

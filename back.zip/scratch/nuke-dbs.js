const { Client } = require('pg');
require('dotenv').config();

const dbs = ['auth_db', 'sales_db', 'hrms_db', 'finance_db'];

async function nukebatabase() {
  for (const dbName of dbs) {
    const client = new Client({
      host: process.env.DB_HOST || 'localhost',
      port: 5432,
      user: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASS || 'root',
      database: dbName,
    });

    try {
      await client.connect();
      console.log(`🧨 Nuking all schemas in ${dbName}...`);
      
      const res = await client.query("SELECT nspname FROM pg_namespace WHERE nspname NOT LIKE 'pg_%' AND nspname != 'information_schema' AND nspname != 'public'");
      for (const row of res.rows) {
        await client.query(`DROP SCHEMA "${row.nspname}" CASCADE`);
      }

      // Also clean public
      await client.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
      
      console.log(`✅ ${dbName} nuked and cleaned.`);
    } catch (err) {
      console.error(`❌ Error nuking ${dbName}:`, err.message);
    } finally {
      await client.end();
    }
  }
}

nukebatabase();

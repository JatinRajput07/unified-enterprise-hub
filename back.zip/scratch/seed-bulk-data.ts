import { NestFactory } from '@nestjs/core';
import { AppModule } from '../src/app.module';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { Plan } from '../src/modules/tenants/entities/plan.entity';
import { TenantEntity, TenantStatus } from '../src/modules/tenants/entities/tenant.entity';
import { faker } from '@faker-js/faker';
import { ProductName } from '../src/database/product-db.constants';
import { SchemaProvisionerService } from '../src/database/schema-provisioner.service';
import { TenantConnectionService } from '../src/database/tenant-connection.service';
import * as bcrypt from 'bcrypt';
import { UserEntity, AuthProvider } from '../src/modules/users/entities/user.entity';
import { Employee, EmployeeStatus } from '../src/modules/products/hrms/entities/employee.entity';
import { Lead, LeadStatus } from '../src/modules/products/crm/entities/lead.entity';
import { Invoice, InvoiceStatus } from '../src/modules/products/finance/entities/invoice.entity';

async function bootstrap() {
  console.log('🚀 Starting Bulk Data Seeder (Post-Refactoring)...');
  const app = await NestFactory.createApplicationContext(AppModule);
  
  const schemaProvisioner = app.get(SchemaProvisionerService);
  const connectionService = app.get(TenantConnectionService);
  const dataSource = app.get(DataSource);
  
  const planRepo = dataSource.getRepository(Plan);
  const tenantRepo = dataSource.getRepository(TenantEntity);
  
  // 1. Seed Plans
  console.log('📦 Seeding Plans...');
  let plans = await planRepo.find();
  if (plans.length === 0) {
    plans = await planRepo.save([
      {
        name: 'Basic Plan',
        slug: 'basic',
        priceMonthly: 29,
        priceYearly: 290,
        maxUsers: 10,
        productLimits: { sales: true, hrms: true, pms: false, finance: false },
        isActive: true,
        isPubliclyVisible: true,
      },
      {
        name: 'Professional Plan',
        slug: 'professional',
        priceMonthly: 99,
        priceYearly: 990,
        maxUsers: 50,
        productLimits: { sales: true, hrms: true, pms: true, finance: true },
        isActive: true,
        isPubliclyVisible: true,
      },
      {
        name: 'Enterprise Plan',
        slug: 'enterprise',
        priceMonthly: 499,
        priceYearly: 4990,
        maxUsers: 1000,
        productLimits: { sales: true, hrms: true, pms: true, finance: true },
        isActive: true,
        isPubliclyVisible: true,
      }
    ] as any);
  }
  
  // 2. Create 10 Tenants
  console.log('🏢 Seeding 10 Tenants...');
  const tenantSlugs: string[] = [];
  for (let i = 1; i <= 10; i++) {
    const name = faker.company.name();
    const slug = name.toLowerCase().replace(/[^a-z0-9]/g, '') + i;
    const plan = faker.helpers.arrayElement(plans);
    
    try {
      console.log(`   - Provisioning Tenant: ${name} (${slug})...`);
      
      const tenant = tenantRepo.create({
        name,
        slug,
        subdomain: `${slug}.enterprise-crm.local`,
        planId: plan.id,
        status: TenantStatus.ACTIVE,
        maxUsers: plan.maxUsers,
      } as any);
      await tenantRepo.save(tenant);

      await schemaProvisioner.provisionSchemas(slug, ['auth', 'sales', 'hrms', 'finance']);
      tenantSlugs.push(slug);
    } catch (e: any) {
      console.error(`   ❌ Failed to provision tenant ${slug}: ${e.message}`);
    }
  }

  // 3. Seed Data
  const hashedPassword = await bcrypt.hash('User@123456', 12);

  for (const slug of tenantSlugs) {
    console.log(`🌱 Seeding data for tenant: ${slug}...`);
    
    try {
      const authDs = await connectionService.getConnection('auth', slug);
      const userRepo = authDs.getRepository(UserEntity);
      
      const users: UserEntity[] = [];
      for (let i = 0; i < 10; i++) {
        const user = userRepo.create({
          firstName: faker.person.firstName(),
          lastName: faker.person.lastName(),
          email: `${faker.internet.username().toLowerCase()}${i}@${slug}.com`,
          password: hashedPassword,
          isEmailVerified: true,
          isActive: true,
          authProvider: AuthProvider.LOCAL
        } as any);
        const saved = await userRepo.save(user);
        users.push(Array.isArray(saved) ? saved[0] : saved);
      }

      const hrmsDs = await connectionService.getConnection('hrms', slug);
      const empRepo = hrmsDs.getRepository(Employee);
      const empCount = faker.number.int({ min: 20, max: 40 });
      for (let i = 0; i < empCount; i++) {
        const user = faker.helpers.arrayElement(users);
        await empRepo.save({
          userId: user.id,
          employeeId: `EMP-${slug.substring(0, 3).toUpperCase()}-${1000 + i}`,
          designation: faker.person.jobTitle(),
          joiningDate: faker.date.past({ years: 2 }).toISOString().split('T')[0],
          status: faker.helpers.arrayElement(Object.values(EmployeeStatus)),
          baseSalary: faker.number.int({ min: 30000, max: 150000 }),
        });
      }

      const salesDs = await connectionService.getConnection('sales', slug);
      const leadRepo = salesDs.getRepository(Lead);
      for (let i = 0; i < 20; i++) {
        await leadRepo.save({
          name: faker.person.fullName(),
          email: faker.internet.email(),
          phone: faker.phone.number(),
          companyName: faker.company.name(),
          source: faker.helpers.arrayElement(['website', 'referral', 'linkedin', 'cold_call']),
          status: faker.helpers.arrayElement(Object.values(LeadStatus)),
          score: faker.number.int({ min: 0, max: 100 }),
          notes: faker.lorem.sentence(),
        });
      }

      const financeDs = await connectionService.getConnection('finance', slug);
      const invRepo = financeDs.getRepository(Invoice);
      for (let i = 0; i < 10; i++) {
        const subtotal = faker.number.float({ min: 100, max: 5000, multipleOf: 0.01 });
        const taxAmount = subtotal * 0.18;
        await invRepo.save({
          invoiceNumber: `INV-${slug.substring(0, 3).toUpperCase()}-${Date.now()}-${i}`,
          clientName: faker.company.name(),
          clientEmail: faker.internet.email(),
          lineItems: [{ description: 'Service A', quantity: 1, unitPrice: subtotal, total: subtotal }],
          subtotal,
          taxPercent: 18,
          taxAmount,
          totalAmount: subtotal + taxAmount,
          status: faker.helpers.arrayElement(Object.values(InvoiceStatus)),
          dueDate: faker.date.future(),
          paidAt: faker.helpers.arrayElement([new Date(), null]),
        } as any);
      }

    } catch (e: any) {
      console.error(`   ❌ Error seeding data for ${slug}: ${e.message}`);
    }
  }

  console.log('✅ Bulk Data Seeding Completed!');
  await app.close();
  process.exit(0);
}

bootstrap();

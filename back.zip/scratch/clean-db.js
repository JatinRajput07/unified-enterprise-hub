const { Client } = require('pg');
require('dotenv').config();

async function cleanDb() {
  const client = new Client({
    host: process.env.AUTH_DB_HOST || process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.AUTH_DB_PORT || process.env.DB_PORT || '5432'),
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASS || 'root',
    database: process.env.AUTH_DB_NAME || 'auth_db',
  });

  try {
    await client.connect();
    console.log('Cleaning auth_db tables...');
    // Drop in correct order
    await client.query('TRUNCATE TABLE tenants CASCADE');
    await client.query('TRUNCATE TABLE plans CASCADE');
    console.log('Clean complete!');
  } catch (err) {
    console.error('Error:', err.message);
  } finally {
    await client.end();
  }
}

cleanDb();

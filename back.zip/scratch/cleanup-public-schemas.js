const { Client } = require('pg');
require('dotenv').config();

const dbs = ['auth_db', 'sales_db', 'hrms_db', 'finance_db'];
const tablesToKeepInAuthPublic = [
  'tenants', 
  'plans', 
  'tenant_subscriptions', 
  'tenant_product_subscriptions',
  'migrations'
];

async function cleanup() {
  for (const dbName of dbs) {
    const client = new Client({
      host: process.env.DB_HOST || 'localhost',
      port: 5432,
      user: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASS || 'root',
      database: dbName,
    });

    try {
      await client.connect();
      console.log(`🧹 Cleaning public schema in ${dbName}...`);

      // Get all tables in public schema
      const res = await client.query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE'");
      const tables = res.rows.map(r => r.table_name);

      for (const table of tables) {
        if (dbName === 'auth_db' && tablesToKeepInAuthPublic.includes(table)) {
          console.log(`   - Skipping protected table: ${table}`);
          continue;
        }

        console.log(`   - Dropping leaked table: ${table}`);
        await client.query(`DROP TABLE "public"."${table}" CASCADE`);
      }

      // Also drop all Enums in public schema (TypeORM creates them)
      const enumRes = await client.query("SELECT typname FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace WHERE n.nspname = 'public' AND t.typtype = 'e'");
      for (const enumType of enumRes.rows) {
         console.log(`   - Dropping leaked enum: ${enumType.typname}`);
         await client.query(`DROP TYPE "public"."${enumType.typname}" CASCADE`);
      }

      console.log(`✅ ${dbName} cleaned.`);
    } catch (err) {
      console.error(`❌ Error cleaning ${dbName}:`, err.message);
    } finally {
      await client.end();
    }
  }
}

cleanup();

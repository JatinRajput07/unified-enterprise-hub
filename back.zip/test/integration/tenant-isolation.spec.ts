import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../../src/app.module';
import { TenantTestFactory, TestTenantContext } from '../setup/tenant-test-factory';
import { TenantsService } from '../../src/modules/tenants/tenants.service';
import { SchemaProvisionerService } from '../../src/database/schema-provisioner.service';

describe('Tenant Isolation (Integration)', () => {
  let app: INestApplication;
  let factory: TenantTestFactory;
  let tenantA: TestTenantContext;
  let tenantB: TestTenantContext;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();

    const tenantsService = moduleFixture.get<TenantsService>(TenantsService);
    const schemaProvisioner = moduleFixture.get<SchemaProvisionerService>(SchemaProvisionerService);
    factory = new TenantTestFactory(tenantsService, schemaProvisioner);
  });

  afterAll(async () => {
    if (tenantA) await tenantA.cleanup();
    if (tenantB) await tenantB.cleanup();
    await app.close();
  });

  it('should not allow access to data from another tenant', async () => {
    // 1. Create two tenants
    tenantA = await factory.createTestTenant({ products: ['hrms'] });
    tenantB = await factory.createTestTenant({ products: ['hrms'] });

    // 2. Create employee in Tenant A
    await request(app.getHttpServer())
      .post('/hrms/employees')
      .query({ tenantSlug: tenantA.tenantSlug })
      .set('Authorization', `Bearer ${tenantA.adminToken}`)
      .send({ firstName: 'Tenant', lastName: 'A Employee' })
      .expect(201);

    // 3. Try to fetch from Tenant B
    const response = await request(app.getHttpServer())
      .get('/hrms/employees')
      .query({ tenantSlug: tenantB.tenantSlug })
      .set('Authorization', `Bearer ${tenantB.adminToken}`)
      .expect(200);

    expect(response.body.items).toHaveLength(0);
  });

  it('should block access if product is not subscribed', async () => {
    // Tenant A only has HRMS
    return request(app.getHttpServer())
      .get('/crm/leads')
      .query({ tenantSlug: tenantA.tenantSlug })
      .set('Authorization', `Bearer ${tenantA.adminToken}`)
      .expect(403);
  });
});

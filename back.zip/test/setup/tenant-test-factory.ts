import { randomUUID } from 'crypto';
import { TenantsService } from '../../src/modules/tenants/tenants.service';
import { SchemaProvisionerService } from '../../src/database/schema-provisioner.service';
import { ProductName } from '../../src/database/product-db.constants';
import { TenantStatus } from '../../src/modules/tenants/entities/tenant.entity';

export interface TestTenantContext {
  tenantSlug: string;
  adminToken: string;
  cleanup: () => Promise<void>;
}

export class TenantTestFactory {
  constructor(
    private readonly tenantsService: TenantsService,
    private readonly schemaProvisioner: SchemaProvisionerService,
  ) {}

  async createTestTenant(options: {
    products: ProductName[];
    status?: TenantStatus;
  }): Promise<TestTenantContext> {
    const slug = `test_${randomUUID().slice(0, 8)}`;
    
    // 1. Create tenant in registry
    const tenant = await this.tenantsService.create({
      name: `Test Tenant ${slug}`,
      slug,
      status: options.status || TenantStatus.ACTIVE,
    });

    // 2. Provision schemas
    await this.schemaProvisioner.provisionTenant(slug, options.products);

    // 3. Return context (Token generation logic would go here)
    return {
      tenantSlug: slug,
      adminToken: 'mock-token-' + slug, // Simplified for brevity
      cleanup: async () => {
        await this.schemaProvisioner.deprovisionTenant(slug, options.products);
        // Delete tenant record...
      },
    };
  }
}

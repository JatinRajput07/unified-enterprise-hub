Continue the NestJS backend. Add AI integrations, billing, audit logs, and harden security.

## What to build

### 1. AI Service Abstraction Layer
src/modules/ai/
├── ai.module.ts
├── ai.service.ts            # facade
├── providers/
│   ├── openai.provider.ts
│   ├── anthropic.provider.ts
│   └── gemini.provider.ts
├── prompt-manager/
│   ├── prompt.entity.ts     # stored prompts in DB
│   ├── prompt.service.ts
│   └── prompt.controller.ts
├── cost-tracker/
│   ├── ai-log.entity.ts     # tokens used, cost, model, userId
│   └── cost-tracker.service.ts
└── dto/

- IAIProvider interface: complete(messages, options): Promise<AIResponse>
- Provider selected by AI_DRIVER=openai|anthropic|gemini env
- AIService.chat(userId, promptKey, variables, options): Promise<string>
  - Loads prompt template from DB by key
  - Interpolates variables
  - Enqueues to AI_QUEUE (non-blocking) or awaits (blocking mode)
  - Logs request: model, inputTokens, outputTokens, cost, latency, userId, tenantId
- Prompt Manager:
  - Prompts stored in DB: { key, template, variables[], model, maxTokens, temperature }
  - CRUD endpoints (admin only)
  - Versioning: prompts have version history
- Cost Tracker:
  - Per-user, per-tenant monthly aggregation
  - Cost limit enforcement: if user exceeds AI_COST_LIMIT_USD reject with 429
  - GET /ai/usage — returns current month usage for user
- Rate Limiting: AI-specific throttle (separate from API throttle)
  - Default: 20 AI calls/min per user
  - Configurable per plan from tenant settings

### 2. Automation & AI Tool System
src/modules/automation/
├── automation.module.ts
├── automation.service.ts
├── workflow.entity.ts       # stored workflows in DB
├── triggers/
│   ├── webhook.trigger.ts
│   ├── schedule.trigger.ts
│   └── event.trigger.ts
├── actions/
│   ├── http.action.ts       # call external URL
│   ├── email.action.ts
│   ├── ai.action.ts         # run AI prompt
│   └── db.action.ts         # query/insert
└── executor.service.ts

- Workflow: { id, name, trigger, steps[], tenantId, isActive }
- WorkflowExecutor: runs steps sequentially, passes output of step N as input to step N+1
- Context object passed through: { triggerPayload, stepResults, user, tenant }
- Execution log stored in DB with status (running/completed/failed) and step outputs
- Admin UI endpoints: CRUD workflows, manual trigger, view logs

### 3. Stripe Billing
src/modules/billing/
├── billing.module.ts
├── billing.service.ts
├── webhook.controller.ts    # Stripe webhooks
├── subscription.entity.ts
└── plan.entity.ts

- Plans stored in DB with Stripe product/price IDs
- BillingService:
  - createCustomer(user): Promise<string>  # returns stripeCustomerId
  - createSubscription(userId, planId)
  - cancelSubscription(userId)
  - getPortalUrl(userId): Promise<string>  # Stripe billing portal
- Webhook handler (POST /billing/webhook):
  - Verify Stripe signature (STRIPE_WEBHOOK_SECRET)
  - Handle: customer.subscription.updated, invoice.payment_failed, customer.subscription.deleted
  - Update subscription status in DB
- Usage-based billing hook: BillingService.recordUsage(userId, quantity, metricName)
- Middleware: check subscription status, block certain routes if subscription expired

### 4. Audit Logs & Activity Tracking
src/modules/audit/
├── audit.module.ts
├── audit.service.ts
├── audit-log.entity.ts
└── audit.interceptor.ts

- AuditLog: { id, userId, tenantId, action, resource, resourceId, oldValue (jsonb), newValue (jsonb), ip, userAgent, timestamp }
- @Audit('users:update') method decorator — auto-captures before/after entity state
- AuditInterceptor: global opt-in, logs all mutating requests (POST/PUT/PATCH/DELETE)
- AuditService.log(entry): saves to DB + emits to ElasticSearch for search
- Admin endpoints: GET /audit/logs with filter by userId, action, dateRange, resource
- Data retention: cron job deletes logs older than AUDIT_RETENTION_DAYS (default 90)

### 5. Security Hardening
src/common/security/
├── security.module.ts
├── sanitization.pipe.ts
├── sql-injection.guard.ts
└── csrf.middleware.ts

- Helmet with strict CSP configured
- CORS: whitelist from ALLOWED_ORIGINS env, vary header set correctly
- Input sanitization pipe: strip HTML tags, trim strings (runs before validation)
- SQL injection: even with ORM, parameterized query audit — custom lint rule for raw queries
- CSRF: Double-submit cookie pattern for browser clients
- Content Security Policy nonces for inline scripts
- Sensitive field masking in logs: mask password, token, cardNumber fields via Winston transform
- brute-force protection on /auth/login: lock account after 10 failed attempts (Redis TTL counter)

### 6. OAuth + SSO Expansion
- SAML 2.0 support stub (passport-saml installed, config ready from env)
- SSO via OIDC: generic OIDC strategy (passport-openidconnect) configured by tenant
- Per-tenant OAuth settings stored in tenant.settings.sso (provider, clientId, clientSecret, callbackUrl)
- Dynamic strategy registration: on startup, load SSO configs from DB and register passport strategies

### 7. Error Handling System
- Global exception filter with error code system:
  - AUTH_001: invalid token, AUTH_002: expired token, AUTH_003: insufficient permissions
  - DB_001: not found, DB_002: duplicate, DB_003: constraint violation
  - AI_001: quota exceeded, AI_002: provider error
  - etc. (define ~30 error codes with HTTP status mapping)
- All exceptions extend BaseException(errorCode, message, metadata)
- Error response: { success: false, errorCode, message, details, requestId, timestamp }
- Sentry integration: SENTRY_DSN env, auto-capture unhandled exceptions with user context

## Output
All files complete. Show updated Docker-compose with new services if any.
Include environment variable additions for this phase.
Continue the NestJS backend. Add the infrastructure layer: caching, job queues, file storage, and background processing.

## What to build (COMPLETE, production-ready)

### 1. Redis Caching Layer
src/common/cache/
├── cache.service.ts         # typed wrapper around ioredis
├── cache.module.ts
└── decorators/
    └── cacheable.decorator.ts

- ioredis client with cluster support (REDIS_URL or REDIS_CLUSTER_URLS env)
- CacheService methods:
  - get<T>(key): Promise<T | null>
  - set(key, value, ttl?): Promise<void>
  - del(key | key[]): Promise<void>
  - getOrSet<T>(key, factory, ttl): Promise<T>  # stale-while-revalidate pattern
  - invalidateByPattern(pattern): Promise<void>  # uses SCAN not KEYS
- @Cacheable({ key: (args) => `user:${args[0]}`, ttl: 300 }) method decorator
- @CacheEvict({ key: (args) => `user:${args[0]}` }) method decorator
- Cache key namespacing by tenant: prefix all keys with tenantId if in tenant context
- NestJS CacheModule also configured (for HTTP response caching via CacheInterceptor)

### 2. BullMQ Queue System
src/queue/
├── queue.module.ts
├── queue.constants.ts       # queue name enums
├── processors/
│   ├── email.processor.ts
│   ├── notification.processor.ts
│   ├── search-sync.processor.ts
│   ├── ai.processor.ts
│   └── report.processor.ts
└── jobs/
    ├── email.job.ts
    └── notification.job.ts

- BullMQ with Redis, separate named queues per domain
- Queue names: EMAIL_QUEUE, NOTIFICATION_QUEUE, SEARCH_SYNC_QUEUE, AI_QUEUE, REPORT_QUEUE
- Each processor:
  - @Processor decorator with concurrency setting
  - @OnWorkerEvent('failed') handler with retry logic
  - Dead letter queue for failed jobs after 3 retries
  - Progress reporting via job.updateProgress()
- Bull Board UI at /admin/queues (protected by admin auth guard)
- Scheduled/cron jobs via BullMQ schedulers: daily cleanup, weekly reports
- Job payload validation with class-validator before enqueue

### 3. RabbitMQ / Kafka Bridge (microservice-ready)
src/transport/
├── transport.module.ts
├── rabbitmq.transport.ts
├── kafka.transport.ts
└── event-bus.service.ts     # abstraction over both

- NestJS microservice transport configured but not started (can be enabled via TRANSPORT_DRIVER=rabbitmq|kafka env)
- EventBusService: publish(topic, payload) and subscribe(topic, handler) methods
- Uses RabbitMQ by default (amqplib), Kafka optional (@nestjs/microservices KafkaOptions)
- Connection from env: RABBITMQ_URL, KAFKA_BROKERS
- Graceful shutdown: drain queues before process exit
- Dead letter exchange (RabbitMQ) / DLT topic (Kafka) config included

### 4. File Storage Abstraction
src/modules/storage/
├── storage.module.ts
├── storage.service.ts       # facade
├── providers/
│   ├── local.provider.ts
│   ├── s3.provider.ts
│   └── cloudinary.provider.ts
├── upload.controller.ts
└── dto/upload.dto.ts

- IStorageProvider interface: upload(file, path, options), delete(path), getSignedUrl(path, expiry), getPublicUrl(path)
- Provider selected by STORAGE_DRIVER=local|s3|cloudinary env variable
- Local: saves to /uploads, serves via static middleware
- S3: @aws-sdk/client-s3 + presigned URLs, multipart for files >5MB
- Cloudinary: transformation params support (resize, format, quality)
- Upload controller: POST /upload/single, POST /upload/multiple
  - Multer middleware with file type whitelist and size limits from config
  - Virus scan hook (pluggable — logs warning if no scanner configured)
  - Returns { url, key, size, mimetype }
- File entity in DB: track uploads per user, support soft delete

### 5. Connection Pooling & DB Optimization
- TypeORM connection pool tuned: max 20, min 2, acquireTimeoutMillis 30000
- Readonly replica connection for GET queries (reads go to replica if READONLY_DB_URL set)
- Query performance logging: log queries > 500ms as warnings
- DB health check endpoint: GET /health/db
- Index strategy helper: document which fields need indexes (migration generator)
- Cursor-based pagination utility using TypeORM QueryBuilder

### 6. Health Checks
src/health/
├── health.module.ts
├── health.controller.ts
└── indicators/
    ├── database.health.ts
    ├── redis.health.ts
    ├── elasticsearch.health.ts
    └── queue.health.ts

- @nestjs/terminus
- GET /health — liveness probe (always 200 if app is up)
- GET /health/ready — readiness probe (checks DB, Redis, ES all healthy)
- GET /health/detailed — full status with response times (admin only)
- Kubernetes liveness/readiness annotations in comments

### 7. Feature Flags
src/modules/feature-flags/
├── feature-flags.module.ts
├── feature-flags.service.ts
└── decorators/
    └── feature-flag.decorator.ts

- Store flags in Redis with DB fallback: key = flag:{tenantId}:{flagName}
- FeatureFlagsService.isEnabled(flagName, context: { userId, tenantId, env })
- Percentage rollout support: { enabled: true, percentage: 20 } → 20% of users
- @FeatureFlag('new-checkout') guard — returns 404 if flag disabled
- Admin endpoints: CRUD for flags per tenant
- Cache flags for 60s (avoid DB hit on every request)

## Output
All files complete. Show the updated app.module.ts with all new modules registered.
Include Docker-compose additions for new services (Redis standalone if not in Phase 1).
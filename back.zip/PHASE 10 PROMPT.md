Final phase. Already exists from Phase 5 — DO NOT recreate:
- Jest config, test helpers, docker-compose.test.yml (Phase 5)
- Prometheus metrics, health endpoints (Phase 5)
- Kubernetes manifests, GitHub Actions workflows (Phase 5)
- All guards, interceptors, filters (Phases 1, 7)

## What this phase adds
Multi-tenant-specific tests, observability tuned for SaaS, and production hardening specific to this schema-per-tenant architecture.

## 1. Multi-tenant Test Helpers (extend existing test/setup/)

test/setup/tenant-test-factory.ts (NEW — extend existing test-database.ts):
createTestTenant(options: {
  products: ProductName[],
  planSlug?: string,
  status?: TenantStatus,
}): Promise<TestTenantContext>

TestTenantContext: {
  tenant: Tenant,
  tenantSlug: string,
  orgAdminToken: string,       # JWT for ORG_ADMIN user
  getEmployeeToken(products: { product: ProductName, role: string }[]): Promise<string>,
  cleanup(): Promise<void>,    # drops tenant schemas from all product DBs
}

Implementation:
1. Generate unique slug: `test_${randomUUID().slice(0,8)}`
2. Call TenantsService.create() to create tenant + provision schemas
3. Create ORG_ADMIN user in tenant schema, generate JWT
4. Return context object with cleanup function

Before each test suite: createTestTenant(...)
After each test suite: context.cleanup() — drops all provisioned schemas

## 2. Critical Test Suites (write ALL completely — no stubs)

### Suite A: Tenant Isolation (MOST IMPORTANT)
test/integration/tenant-isolation.spec.ts

Test: employee data is completely isolated between tenants
1. Create two test tenants: tenantA and tenantB, both with HRMS
2. Create employee in tenantA's HRMS
3. Login as tenantB's ORG_ADMIN
4. GET /hrms/employees → expect empty array (tenantB has no employees)
5. GET /hrms/employees/:idFromTenantA → expect 404
Assert: no data leakage between tenants

Test: product schema non-existence blocks access
1. Create tenantC with ONLY hrms product
2. GET /crm/leads with tenantC token → expect 403 (PRODUCT_NOT_SUBSCRIBED)
3. Verify no schema exists for tenantC in sales_db

Test: tenant suspension blocks all API access
1. Create tenantD, activate it
2. Create user, get valid JWT
3. Set tenantD.status = suspended
4. Invalidate tenant cache (Redis DEL)
5. Any API call with tenantD JWT → expect 402 with SUBSCRIPTION_INACTIVE

### Suite B: Schema Provisioning Lifecycle
test/integration/schema-provisioning.spec.ts

Test: full provision + deprovision
1. provisionSchema('test_abc', ['hrms', 'pms'])
2. listProvisionedSchemas('test_abc') → expect ['auth', 'hrms', 'pms']
3. Verify schema exists: SELECT schema_name FROM information_schema.schemata in hrms_db → has 'test_abc'
4. deprovisionSchema('test_abc', ['hrms', 'pms'])
5. listProvisionedSchemas('test_abc') → expect ['auth']
6. Verify schema gone: above query → no 'test_abc' row

Test: addSingleProductSchema idempotency
1. addSingleProductSchema('test_abc', 'finance')
2. addSingleProductSchema('test_abc', 'finance') — call again
3. Expect no error (CREATE SCHEMA IF NOT EXISTS is idempotent)

Test: provisioning failure partial recovery
1. Mock SchemaProvisionerService to fail on 3rd product
2. Call provisionSchema('test_abc', ['hrms', 'pms', 'finance'])
3. Expect hrms and pms to be provisioned, finance not
4. Verify error is logged but other products unaffected

### Suite C: Permission Model
test/integration/permissions.spec.ts

Test: RBAC hierarchy respected
1. Create tenant with HRMS
2. Grant user Mehak hr_viewer role in HRMS
3. Mehak GET /hrms/employees → 200 ✅
4. Mehak POST /hrms/payroll/generate → 403 ✅ (hr_viewer doesn't have payroll:create)
5. Promote Mehak to hr_admin
6. Invalidate cache
7. Mehak POST /hrms/payroll/generate → 200 ✅

Test: permission cache invalidation
1. Grant hrms access to user
2. Make request → verify cache SET in Redis
3. Revoke hrms access
4. Verify Redis cache key deleted
5. Make request again → 403 (fresh DB check)

Test: ORG_ADMIN bypasses all product permission checks
1. Create user with ORG_ADMIN role, NO explicit product_roles
2. ORG_ADMIN can access /hrms/employees, /crm/leads, /pms/projects, /finance/invoices
3. All return 200 regardless of product_roles table

Test: dashboard admin can only grant permissions ≤ own permissions
1. Grant Mehak hr_manager role (has leaves:approve, employees:read, employees:update)
2. Mehak tries to grant Jatinder hr_admin (has employees:* — MORE than Mehak)
3. Expect 403 INSUFFICIENT_PERMISSIONS_TO_GRANT

### Suite D: Hybrid Onboarding E2E
test/e2e/onboarding.e2e-spec.ts

Test: self-service flow end-to-end
1. GET /public/plans → pick first active plan slug
2. POST /auth/register → get back { tenant, user, requiresPayment }
3. If requiresPayment: mock Stripe webhook customer.subscription.created → verify tenant active + schemas provisioned
4. POST /auth/login → get tokens
5. GET /me/access → expect ORG_ADMIN role
6. Cleanup: delete tenant (deprovision schemas)

Test: sales-driven flow end-to-end
1. POST /auth/demo-request → 200, email queued
2. POST /super-admin/tenants → create tenant manually
3. POST /super-admin/tenants/:id/invite-admin → get invite token from Redis
4. POST /auth/accept-invite → get tokens
5. Login → GET /me/access → expect ORG_ADMIN

Test: Stripe webhook payment failure → suspension
1. Create active tenant
2. POST /billing/webhook with invoice.payment_failed × 3 (simulate 3 consecutive)
3. GET any protected route → 402 SUBSCRIPTION_INACTIVE

### Suite E: Unit tests for new services
test/unit/schema-provisioner.spec.ts — mock PG client, test all branches
test/unit/product-access.spec.ts — test permission check logic, wildcard expansion, cache behavior
test/unit/billing.spec.ts — test webhook handler logic per event type

## 3. Extend Existing Prometheus Metrics (from Phase 5)
Add to existing prometheus.service.ts — DO NOT replace existing metrics:

New metrics:
- tenant_active_total: Gauge — total active tenants (updated on tenant status change)
- tenant_product_subscriptions_total: Gauge with label {product} — how many tenants have each product
- schema_provisioning_duration_seconds: Histogram — time to provision all schemas for a tenant
- schema_provisioning_failures_total: Counter with label {product} — failed provisions per product
- product_api_requests_total: Counter with labels {product, tenantSlug, endpoint, status} — per-product usage tracking
- billing_webhook_events_total: Counter with label {event_type, status}

Expose at existing GET /metrics endpoint.

## 4. Extend Existing Health Checks (from Phase 5)
Extend existing health.controller.ts — add to /health/detailed response:

{
  "productDatabases": {
    "sales_db": { "status": "healthy", "responseTimeMs": 12, "activeConnections": 4 },
    "hrms_db":  { "status": "healthy", "responseTimeMs": 8, "activeConnections": 2 },
    "pms_db":   { "status": "healthy", "responseTimeMs": 9, "activeConnections": 1 },
    "finance_db":{ "status": "degraded", "responseTimeMs": 890, "error": "slow query" }
  },
  "tenantConnectionPool": {
    "totalCachedConnections": 24,
    "connectionsByProduct": { "hrms": 8, "sales": 10, "pms": 4, "finance": 2 }
  },
  "schemaStats": {
    "totalProvisionedSchemas": 48
  }
}

Add DatabaseHealthIndicator for each product DB — reuse existing pattern from Phase 5.

## 5. Extend Existing K8s Manifests (from Phase 5)
Add to existing k8s/ folder — DO NOT recreate existing files:

k8s/configmap-databases.yaml (NEW):
All non-secret DB config: hosts, ports, DB names — referenced by deployment

k8s/hpa-worker.yaml (UPDATE existing hpa.yaml):
Add BullMQ SCHEMA_QUEUE depth as custom metric trigger for worker pod:
- If schema_queue_depth > 5: scale worker up (schema provisioning is CPU-heavy)

k8s/jobs/provision-check.yaml (NEW — CronJob):
Runs every 6 hours: NodeJS script queries tenant_product_subscriptions and verifies each active product subscription has a real schema in the corresponding DB. Logs discrepancies. This catches any provisioning failures from webhook processing.

k8s/network-policy.yaml (NEW):
- API pod: can talk to ALL 5 DBs, Redis, ElasticSearch
- Worker pod: can talk to ALL 5 DBs, Redis (needs to provision schemas)
- NO direct pod-to-pod communication allowed outside these rules

## 6. Extend Existing CI/CD (from Phase 5)
Add to existing ci.yml (after existing steps — do NOT replace):

New step after integration tests:
- name: Tenant isolation test
  run: jest --config jest.config.integration.ts --testPathPattern="tenant-isolation"

New step after build:
- name: Schema provisioning smoke test
  run: |
    docker-compose -f docker-compose.test.yml up -d
    sleep 10
    npm run test:provision-smoke  # script that creates a test tenant, provisions, verifies, cleans up

Add to existing cd-production.yml after migration job:
- name: Verify all tenant schemas healthy
  run: kubectl exec deploy/api -- npm run check:schemas
  # This runs the provision-check logic once synchronously before declaring deploy successful

## 7. Production Runbook (generate as src/docs/runbook.md)
Sections:
1. Adding a new product DB (e.g. adding a new 'analytics' product)
   - Add env vars, add to PRODUCT_DB_NAMES, add DataSource config, create new DB, deploy
2. Manual tenant schema provisioning (if webhook failed)
   - npm run cli:provision -- --tenant=abc --products=hrms,pms
3. Emergency tenant suspension
   - Direct DB update + Redis cache flush command
4. Schema corruption recovery
   - How to restore from backup to specific tenant schema without affecting others
5. Connection pool exhaustion
   - How to identify which tenant+product is hogging connections
   - How to force-close and evict from TenantConnectionService pool

## Output
All test files complete (no stubs in test assertions). Show how cleanup() in TestTenantContext uses SchemaProvisionerService.deprovisionSchema(). Show the provision-check CronJob YAML in full. Generate the runbook.md completely.
Continue from Phase 6. The following already exist and must be REUSED not recreated:
- TenantConnectionService (get DB connection per product + tenant)
- TenantContextService (get current tenant from AsyncLocalStorage — Phase 1)
- CacheService (Redis wrapper — Phase 3)
- ProductName type, PRODUCT_DB_NAMES constant (Phase 6)
- plan.entity, tenant.entity, tenant_product_subscriptions.entity (Phase 6)
- BullMQ EMAIL_QUEUE for sending invite emails (Phase 3)
- JwtAuthGuard, RolesGuard (Phase 1)

## What this phase builds
All data in this phase lives in auth_db TENANT SCHEMA (e.g. abc, xyz — not public schema).
Use TenantConnectionService.getConnection('auth', tenantSlug) for all queries here.

## New Entities (all in auth_db per-tenant schema)

departments:
id, name, slug(unique within tenant), description,
parent_department_id(self-FK nullable — for nested hierarchy),
head_user_id(FK to users, nullable),
is_active(bool default true),
created_at, updated_at, deleted_at

teams:
id, name, slug(unique within tenant), description,
department_id(FK nullable — team can exist without department),
lead_user_id(FK nullable),
is_active(bool),
created_at, updated_at, deleted_at

user_departments: (junction)
user_id(FK), department_id(FK),
is_primary(bool default false),
joined_at(timestamp)
UNIQUE(user_id, department_id)
RULE: only one row per user per dept can have is_primary=true — enforce in service layer

user_teams: (junction)
user_id(FK), team_id(FK), joined_at(timestamp)
UNIQUE(user_id, team_id)

product_roles: (THE MOST IMPORTANT TABLE)
id, user_id(FK),
product_name(ProductName enum),
role_name(varchar — e.g. 'hr_admin', 'sales_rep'),
custom_permissions(text[] — e.g. ['employees:read','leaves:approve']),
granted_by_user_id(FK),
granted_at(timestamp),
revoked_at(timestamp nullable)
UNIQUE(user_id, product_name) where revoked_at IS NULL
RULE: a user can only have ONE active role per product at a time

## New folder structure
src/modules/org/
├── org.module.ts
├── departments/
│   ├── department.entity.ts
│   ├── departments.service.ts
│   ├── departments.controller.ts    # /org/departments/*
│   └── dto/
├── teams/
│   ├── team.entity.ts
│   ├── teams.service.ts
│   ├── teams.controller.ts          # /org/teams/*
│   └── dto/
├── members/
│   ├── members.service.ts           # handles user↔dept and user↔team assignments
│   └── members.controller.ts        # /org/users/:id/departments, /org/users/:id/teams
└── product-access/
    ├── product-access.service.ts    # handles product_roles CRUD + permission checks
    ├── product-access.controller.ts # /org/users/:id/product-access
    └── product-roles.constants.ts   # default roles per product

## Departments Module

DepartmentsController:
POST   /org/departments                    # ORG_ADMIN only
GET    /org/departments                    # returns tree structure
GET    /org/departments/:id                # detail + member count + teams
GET    /org/departments/:id/members        # paginated member list
PATCH  /org/departments/:id               # ORG_ADMIN only
DELETE /org/departments/:id               # only if no active members

DepartmentsService.findAllAsTree():
- Fetch all departments flat from DB
- Build tree in memory: { id, name, children: [], memberCount }
- Root nodes: parent_department_id IS NULL

DepartmentsService.create(dto, tenantSlug):
- Use TenantConnectionService.getConnection('auth', tenantSlug)
- Validate parent exists if parent_department_id provided
- Validate slug unique within tenant
- Insert and return

DepartmentsService.delete(id, tenantSlug):
- Check user_departments count for this dept — reject if > 0
- Check if any teams reference this dept — reject if > 0
- Soft delete

## Teams Module

TeamsController:
POST   /org/teams
GET    /org/teams                          # filter: ?departmentId=
GET    /org/teams/:id                      # detail + members
PATCH  /org/teams/:id
DELETE /org/teams/:id                      # only if no active members
POST   /org/teams/:id/members              # body: { userId }
DELETE /org/teams/:id/members/:userId

## Members Module

MembersController (extend existing users routes):
GET    /org/users/:id/departments          # all depts for a user
POST   /org/users/:id/departments          # body: { departmentId, isPrimary }
DELETE /org/users/:id/departments/:deptId
GET    /org/users/:id/teams
POST   /org/users/:id/teams               # body: { teamId }
DELETE /org/users/:id/teams/:teamId

MembersService.assignDepartment(userId, deptId, isPrimary, tenantSlug):
- Check user exists in this tenant
- Check dept exists in this tenant
- If isPrimary=true: first set existing primary row to isPrimary=false for this user
- INSERT into user_departments (or upsert)

## Product Access Module (MOST CRITICAL)

product-roles.constants.ts — define default role permissions per product:
export const PRODUCT_ROLES = {
  hrms: {
    hr_admin:    ['employees:*','leaves:*','payroll:*','departments:read','reports:read'],
    hr_manager:  ['employees:read','employees:update','leaves:approve','leaves:read','payroll:read'],
    hr_viewer:   ['employees:read','leaves:read'],
  },
  sales: {
    crm_admin:   ['leads:*','deals:*','contacts:*','pipeline:*','reports:*'],
    sales_rep:   ['leads:create','leads:read','leads:update','deals:read','deals:update','contacts:read'],
    crm_viewer:  ['leads:read','deals:read','contacts:read'],
  },
  pms: {
    pms_admin:   ['projects:*','tasks:*','timesheets:*','reports:*'],
    project_lead:['projects:read','tasks:*','timesheets:read'],
    member:      ['tasks:read','tasks:update','timesheets:create','timesheets:read'],
  },
  finance: {
    finance_admin:  ['invoices:*','budget:*','payroll:*','reports:*'],
    accountant:     ['invoices:*','budget:read','payroll:read'],
    finance_viewer: ['invoices:read','budget:read'],
  },
} as const;

ProductAccessController:
GET    /org/users/:id/product-access           # all products this user has access to
POST   /org/users/:id/product-access           # grant access
DELETE /org/users/:id/product-access/:product  # revoke access
GET    /products/roles/:product                # list available roles for a product (public within tenant)

ProductAccessService.grantAccess(params: {
  targetUserId: string,
  product: ProductName,
  roleName: string,
  customPermissions: string[],
  grantedByUserId: string,
  tenantSlug: string,
}): Promise<void>

Validation steps:
1. Check tenant has active subscription to this product (query tenant_product_subscriptions)
2. Check grantedByUserId has access to this product with a role that includes 'manage_access' OR is ORG_ADMIN
3. If grantedBy is dashboard admin (not ORG_ADMIN): verify customPermissions ⊆ grantedBy's own permissions for this product
4. Revoke any existing active product_role for this user+product (set revoked_at = now)
5. Insert new product_roles row
6. Invalidate Redis cache key: perm:{tenantSlug}:{userId}:{product}
7. Emit socket event USER_PERMISSIONS_UPDATED to user:{userId} room (use existing TenantRoomsService from Phase 2)

ProductAccessService.checkPermission(userId, product, permission, tenantSlug): Promise<boolean>
- Cache key: perm:{tenantSlug}:{userId}:{product} TTL=300s
- If cache hit: parse permissions array, check if permission or wildcard (*) matches
- If cache miss: query product_roles table, expand role permissions from PRODUCT_ROLES constant + custom_permissions, cache result
- Return true/false

ProductAccessService.getUserAccessSummary(userId, tenantSlug): Promise<ProductAccessSummary[]>
Returns: [{ product, roleName, permissions[], grantedBy: { id, name }, grantedAt }]
Used by GET /me/access endpoint

## Me endpoints (for any logged-in user)
Add to existing auth or profile controller:
GET /me/access        → ProductAccessService.getUserAccessSummary(currentUserId)
GET /me/departments   → user's departments with isPrimary flag
GET /me/teams         → user's teams
PATCH /me/profile     → update own firstName, lastName, avatar (NOT email, NOT role)

## Product Permission Guard
src/common/guards/product-permission.guard.ts

Extend existing guards — do NOT rewrite RolesGuard:
@Injectable()
export class ProductPermissionGuard implements CanActivate {
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest();
    const product: ProductName = Reflect.getMetadata('product', context.getHandler());
    const permission: string = Reflect.getMetadata('permission', context.getHandler());
    const user = req.user;
    const tenant = req.tenant;
    // Step 1: check tenant has product subscription
    // Step 2: check user has required permission via ProductAccessService.checkPermission()
    // ORG_ADMIN bypass: if user has ORG_ADMIN role, skip permission check for all products
  }
}

@RequiresProductPermission(product: ProductName, permission: string) decorator that sets both metadata keys.

## Output
All files complete. Show end-to-end: org admin grants hrms access to Mehak → Mehak logs in → GET /me/access returns hrms role → GET /hrms/employees uses ProductPermissionGuard → cache hit on second request.
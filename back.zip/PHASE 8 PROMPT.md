Continue from Phase 7. The following already exist — DO NOT recreate:
- TenantConnectionService (Phase 6) — use for all product DB queries
- ProductPermissionGuard + @RequiresProductPermission decorator (Phase 7)
- PRODUCT_ROLES constant (Phase 7)
- ProductName type (Phase 6)
- BullMQ queues including SEARCH_QUEUE (Phase 3)
- SearchService with ElasticSearch (Phase 2)
- TenantRoomsService for socket events (Phase 2)
- CacheService (Phase 3)

## Architecture Rule (enforce in every product module)
Every service method in every product module MUST:
1. Call TenantConnectionService.getConnection(productName, tenantSlug) to get DataSource
2. Use that DataSource to get the repository — never use global TypeORM repositories
3. Never hardcode tenantSlug — always take from TenantContextService or method param

Pattern to follow (implement this exactly):
```typescript
@Injectable()
export class EmployeesService {
  constructor(
    private tenantConn: TenantConnectionService,
    private tenantCtx: TenantContextService,
    private searchService: SearchService,
    private eventEmitter: EventEmitter2,
  ) {}

  private async getRepo(tenantSlug: string) {
    const ds = await this.tenantConn.getConnection('hrms', tenantSlug);
    return ds.getRepository(Employee);
  }

  async findAll(tenantSlug: string, filters: EmployeeFilterDto) {
    const repo = await this.getRepo(tenantSlug);
    return repo.createQueryBuilder('e')
      .where('e.deleted_at IS NULL')
      .andWhere(filters.department ? 'e.department_id = :deptId' : '1=1', { deptId: filters.department })
      .orderBy('e.created_at', 'DESC')
      .skip(filters.offset).take(filters.limit)
      .getManyAndCount();
  }
}
```

## Folder structure
src/modules/products/
├── shared/
│   ├── product.guard.ts               # checks tenant_product_subscriptions (reuse Phase 6 logic)
│   ├── base-product.module.ts         # abstract — registers ProductGuard + ProductPermissionGuard
│   └── product-event.constants.ts     # all socket event names for all products
├── hrms/
│   ├── hrms.module.ts                 # extends BaseProductModule, product='hrms'
│   ├── hrms.controller.ts
│   ├── entities/
│   │   ├── employee.entity.ts
│   │   ├── leave.entity.ts
│   │   └── payroll.entity.ts
│   ├── services/
│   │   ├── employees.service.ts
│   │   ├── leaves.service.ts
│   │   └── payroll.service.ts
│   └── dto/
├── crm/
│   ├── crm.module.ts
│   ├── crm.controller.ts
│   ├── entities/
│   │   ├── lead.entity.ts
│   │   ├── deal.entity.ts
│   │   └── contact.entity.ts
│   ├── services/
│   │   ├── leads.service.ts
│   │   ├── deals.service.ts
│   │   └── contacts.service.ts
│   └── dto/
├── pms/
│   ├── pms.module.ts
│   ├── pms.controller.ts
│   ├── entities/
│   │   ├── project.entity.ts
│   │   ├── task.entity.ts
│   │   └── timesheet.entity.ts
│   ├── services/
│   │   ├── projects.service.ts
│   │   ├── tasks.service.ts
│   │   └── timesheets.service.ts
│   └── dto/
└── finance/
    ├── finance.module.ts
    ├── finance.controller.ts
    ├── entities/
    │   ├── invoice.entity.ts
    │   ├── budget.entity.ts
    │   └── expense.entity.ts
    ├── services/
    │   ├── invoices.service.ts
    │   ├── budgets.service.ts
    │   └── expenses.service.ts
    └── dto/

## HRMS Module (implement COMPLETELY — other 3 modules follow same pattern)

### Entities (all in hrms_db, tenant schema)

employee.entity.ts:
id, user_id(varchar — references auth_db user, NOT a FK across DBs),
emp_code(varchar unique within schema), first_name, last_name, email,
designation, department_id(varchar — references auth_db dept, NOT FK across DBs),
joining_date(date), status(enum: active|inactive|on_leave|terminated),
salary_grade(varchar), manager_id(varchar nullable — references another employee.id),
emergency_contact(jsonb: { name, phone, relation }),
created_at, updated_at, deleted_at

leave.entity.ts:
id, employee_id(FK → employee.id within same schema),
leave_type(enum: annual|sick|casual|maternity|paternity|unpaid),
from_date(date), to_date(date), total_days(decimal),
reason(text), status(enum: pending|approved|rejected|cancelled),
approved_by_employee_id(varchar nullable), approved_at(timestamp nullable),
rejection_reason(text nullable),
created_at, updated_at

payroll.entity.ts:
id, employee_id(FK), month(int 1-12), year(int),
basic_salary(decimal), hra(decimal), other_allowances(jsonb),
pf_deduction(decimal), tax_deduction(decimal), other_deductions(jsonb),
net_pay(decimal), status(enum: draft|processed|paid),
paid_at(timestamp nullable), payment_reference(varchar nullable),
created_at, updated_at
UNIQUE(employee_id, month, year)

### Employees Service (complete all methods)
findAll(tenantSlug, filters: { department?, status?, search?, limit, offset })
findOne(id, tenantSlug)
create(dto, tenantSlug): Promise<Employee>
  - After save: enqueue SEARCH_QUEUE job to index in ElasticSearch index employees_{tenantSlug}
update(id, dto, tenantSlug): Promise<Employee>
  - After update: enqueue search reindex job
  - Emit socket event HRMS_EMPLOYEE_UPDATED to product:hrms:{tenantSlug} room
softDelete(id, tenantSlug)
search(query, tenantSlug): delegate to SearchService.search('employees', tenantSlug, query)

### Leaves Service (complete all methods)
findAll(tenantSlug, filters: { employeeId?, status?, from?, to? })
create(dto, tenantSlug): Promise<Leave>
  - Validate no overlapping approved leave for same employee
  - status defaults to 'pending'
  - Notify employee's manager via NotificationService (Phase 3)
approve(leaveId, approverId, tenantSlug): Promise<Leave>
  - Check approverId has leaves:approve permission
  - Set status=approved, approved_by, approved_at
  - Emit HRMS_LEAVE_STATUS_CHANGED socket event
  - Send notification to employee
reject(leaveId, approverId, reason, tenantSlug): similar to approve

### Payroll Service (complete all methods)
generatePayroll(employeeId, month, year, tenantSlug): Promise<Payroll>
  - Check no duplicate for same month/year
  - Calculate net_pay from basic + allowances - deductions
  - status=draft
processPayroll(payrollId, tenantSlug): status=processed
markPaid(payrollId, reference, tenantSlug): status=paid, paid_at=now

### HRMS Controller (mount all at /hrms/*)
All routes protected by: JwtAuthGuard + @RequiresProductPermission('hrms', 'employees:read') minimum

GET    /hrms/employees
POST   /hrms/employees                 # requires employees:create
GET    /hrms/employees/search          # ?q=
GET    /hrms/employees/:id
PATCH  /hrms/employees/:id             # requires employees:update
DELETE /hrms/employees/:id             # requires employees:delete

GET    /hrms/leaves                    # filter by employeeId, status, date range
POST   /hrms/leaves                    # employee creates own leave request
GET    /hrms/leaves/:id
PATCH  /hrms/leaves/:id/approve        # requires leaves:approve
PATCH  /hrms/leaves/:id/reject         # requires leaves:approve

GET    /hrms/payroll                   # filter by month, year, status
POST   /hrms/payroll/generate          # requires payroll:create
PATCH  /hrms/payroll/:id/process       # requires payroll:process
PATCH  /hrms/payroll/:id/mark-paid     # requires payroll:process

## CRM Module (entity fields + controller routes — services follow HRMS pattern)

lead.entity.ts:
id, name, email, phone, company_name, source(enum: website|referral|cold_call|linkedin|other),
status(enum: new|contacted|qualified|proposal|negotiation|won|lost),
assigned_to_user_id(varchar), score(int 0-100), notes(text),
last_contacted_at(timestamp nullable),
created_at, updated_at, deleted_at

deal.entity.ts:
id, title, lead_id(FK), value(decimal), currency(varchar default 'INR'),
stage(enum: discovery|proposal|negotiation|closed_won|closed_lost),
expected_close_date(date), actual_close_date(date nullable),
owner_user_id(varchar), probability(int 0-100),
created_at, updated_at, deleted_at

contact.entity.ts:
id, first_name, last_name, email, phone, company_name,
lead_id(FK nullable), designation, notes(text),
created_at, updated_at, deleted_at

CRM Routes at /crm/*:
GET/POST/GET/:id/PATCH/:id/DELETE/:id for leads, deals, contacts
GET /crm/leads/search, GET /crm/pipeline (deals grouped by stage with totals)
PATCH /crm/leads/:id/assign  # assign to user
PATCH /crm/deals/:id/stage   # move stage + emit CRM_DEAL_STAGE_CHANGED socket event

## PMS Module (entity fields + routes — services follow HRMS pattern)

project.entity.ts:
id, name, description, status(enum: planning|active|on_hold|completed|cancelled),
start_date(date), end_date(date nullable), owner_user_id(varchar),
team_id(varchar nullable), budget(decimal nullable),
created_at, updated_at, deleted_at

task.entity.ts:
id, title, description(text), project_id(FK),
parent_task_id(FK nullable — for subtasks), assignee_user_id(varchar nullable),
priority(enum: low|medium|high|critical), status(enum: todo|in_progress|review|done|cancelled),
due_date(date nullable), estimated_hours(decimal nullable), actual_hours(decimal nullable),
created_at, updated_at, deleted_at

timesheet.entity.ts:
id, task_id(FK), user_id(varchar), date(date),
hours_logged(decimal), description(text),
created_at, updated_at
UNIQUE(task_id, user_id, date)

PMS Routes at /pms/*:
Full CRUD for projects, tasks, timesheets
GET /pms/projects/:id/tasks  # task tree (with subtasks)
PATCH /pms/tasks/:id/status  # emit PMS_TASK_UPDATED socket event
POST /pms/timesheets         # log hours
GET /pms/reports/timesheet   # hours by user/project, filter by date range

## Finance Module (entity fields + routes — services follow HRMS pattern)

invoice.entity.ts:
id, invoice_number(varchar unique), client_name, client_email,
line_items(jsonb: [{description, quantity, unit_price, total}]),
subtotal(decimal), tax_percent(decimal), tax_amount(decimal), total_amount(decimal),
status(enum: draft|sent|paid|overdue|cancelled),
due_date(date), paid_at(timestamp nullable), payment_reference(varchar nullable),
notes(text nullable), created_at, updated_at, deleted_at

budget.entity.ts:
id, name, department_id(varchar nullable), fiscal_year(int), fiscal_month(int nullable),
allocated_amount(decimal), spent_amount(decimal default 0), category(varchar),
created_at, updated_at

expense.entity.ts:
id, title, amount(decimal), category(varchar), budget_id(FK nullable),
submitted_by_user_id(varchar), approved_by_user_id(varchar nullable),
status(enum: pending|approved|rejected), receipt_url(varchar nullable),
expense_date(date), created_at, updated_at

Finance Routes at /finance/*:
Full CRUD for invoices, budgets, expenses
PATCH /finance/invoices/:id/send      # mark as sent, email client
PATCH /finance/invoices/:id/mark-paid
GET /finance/reports/revenue          # monthly revenue summary
GET /finance/reports/expenses         # expenses by category/department

## Output
All files complete for HRMS (100% implemented). CRM, PMS, Finance: entities complete, controllers complete, services with all method signatures and bodies (not stubs — full logic following HRMS pattern). Show how the SAME ProductPermissionGuard works across all 4 products by just changing the product+permission metadata.
Continue the NestJS backend from Phase 1. Now add the real-time layer, API documentation, versioning, and external communication.

## What to build (COMPLETE implementation, no stubs)

### 1. Socket.io Setup (Scalable)
src/modules/gateway/
├── app.gateway.ts          # main gateway
├── gateway.module.ts
├── presence.service.ts     # online/offline tracking
├── events.enum.ts          # all event name constants
└── dto/                    # socket event DTOs

- Socket.io with Redis adapter (@socket.io/redis-adapter) for multi-instance scaling
- Auth middleware for socket: validate JWT on connection, attach user to socket.data
- Rooms: per-user room (user:{userId}), per-tenant room (tenant:{tenantId}), per-resource room
- Presence system:
  - On connect: set user online in Redis (HSET presence:{tenantId} userId timestamp)
  - On disconnect: remove from Redis, emit 'user:offline' to tenant room
  - GET /presence/online — returns online users for current tenant
  - Heartbeat: client pings every 30s, server updates TTL
- Typed event emitter service (EventEmitter2): other modules emit events, gateway broadcasts
- Rate limiting on socket events (per user, per event type)

### 2. WebRTC Signaling Server
src/modules/webrtc/
├── webrtc.gateway.ts
├── webrtc.module.ts
├── room.service.ts
└── dto/

- Signaling via Socket.io events: offer, answer, ice-candidate, room:join, room:leave
- Room management in Redis: room:{roomId} → { participants[], createdAt, maxParticipants }
- Participant limit enforcement
- Room cleanup on all participants disconnect
- TURN server config delivery endpoint: GET /webrtc/ice-config (returns STUN/TURN credentials from env)
- No media handling (that's client-side) — pure signaling

### 3. SMTP / Email Service
src/modules/notifications/email/
├── email.service.ts
├── email.module.ts
├── templates/              # Handlebars .hbs templates
│   ├── welcome.hbs
│   ├── reset-password.hbs
│   ├── verify-email.hbs
│   └── 2fa-code.hbs
└── dto/send-email.dto.ts

- Nodemailer with SMTP config from env (SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM)
- Template engine: Handlebars (compile once, cache, inject variables)
- EmailService.send({ to, subject, template, context }) method
- Queue-based: email jobs pushed to BullMQ 'email' queue (processor in Phase 3)
- Retry logic: 3 retries with exponential backoff
- Dev mode: use Ethereal (auto-create test account if no SMTP configured)

### 4. API Versioning
- URI versioning: /v1/users, /v2/users
- Default version: v1
- Version-specific controllers via @Version('1'), @Version('2')
- Deprecation header middleware: add Deprecation header to v1 endpoints when v2 exists

### 5. Swagger / OpenAPI
- Full Swagger setup at /api/docs (disabled in prod unless SWAGGER_ENABLED=true)
- Swagger UI with JWT bearer auth built in
- @ApiTags, @ApiOperation, @ApiBearerAuth, @ApiResponse on ALL controllers
- Schema examples on all DTOs via @ApiProperty({ example: ... })
- Separate Swagger document per API version
- Export swagger.json on startup for CI

### 6. Rate Limiting & Throttling
- @nestjs/throttler global: 100 req/min per IP default
- Custom @Throttle() decorator per route (e.g. login: 5/min)
- Redis-backed throttler store (ThrottlerStorageRedisService) for multi-instance
- Custom ThrottlerGuard that returns 429 with Retry-After header
- Skip throttling for internal service requests (X-Internal-Key header)
- Per-user limits (authenticated): higher limits than anonymous

### 7. ElasticSearch Integration
src/modules/search/
├── search.service.ts       # generic search wrapper
├── search.module.ts
├── elasticsearch.provider.ts
└── indices/
    └── users.index.ts      # index mapping definition

- @elastic/elasticsearch client, configured from env (ELASTICSEARCH_URL, ELASTICSEARCH_USERNAME, ELASTICSEARCH_PASSWORD)
- SearchService.index(indexName, doc), .search(indexName, query), .delete(indexName, id), .bulkIndex(indexName, docs)
- Auto-create indices with mappings on module init (only if not exists)
- TypeORM subscribers: on User save/update → sync to ES (async via BullMQ job)
- Pagination support in search results

### 8. Notification Abstraction Layer
src/modules/notifications/
├── notification.service.ts  # facade — route to correct channel
├── notification.module.ts
├── channels/
│   ├── sms.service.ts       # Twilio abstraction
│   ├── push.service.ts      # Firebase FCM abstraction
│   └── webpush.service.ts   # web-push lib
└── dto/notification.dto.ts

- INotificationChannel interface: send(to, payload): Promise<void>
- NotificationService.send(userId, { channel, template, data }) — looks up user prefs and delivers
- SMS: Twilio SDK (TWILIO_SID, TWILIO_TOKEN, TWILIO_FROM env vars)
- Push: Firebase Admin SDK (FIREBASE_PROJECT_ID, FIREBASE_PRIVATE_KEY, FIREBASE_CLIENT_EMAIL)
- Web Push: VAPID keys from env, store subscriptions in DB

## Output
All files complete. Show imports clearly. Maintain the module structure from Phase 1.
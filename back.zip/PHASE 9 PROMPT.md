Continue from Phase 8. Already exists — DO NOT recreate:
- TenantConnectionService, SchemaProvisionerService (Phase 6)
- BillingService basic structure, StripeService (Phase 4)
- EMAIL_QUEUE + email templates (Phase 3)
- tenant.entity, plan.entity, tenant_product_subscriptions (Phase 6)
- AuthService, JWT strategy (Phase 1)
- FeatureFlagsService (Phase 3)

## What this phase completes
- Hybrid onboarding flows (self-service + sales-driven) wired end-to-end
- Stripe webhooks tightly integrated with schema provisioning
- Subscription lifecycle fully connected to product access
- Tenant billing portal for org admin

## New .env variables (add to existing .env.example)
STRIPE_WEBHOOK_SECRET=whsec_...
SELF_SERVICE_ENABLED=true        # feature flag fallback
DEMO_REQUEST_NOTIFY_EMAIL=sales@yourplatform.com
INVITE_TOKEN_TTL_HOURS=48
TRIAL_DAYS=14

## 1. Self-Service Onboarding Flow

New endpoint: POST /auth/register
Body: { firstName, lastName, email, password, companyName, planSlug }

Steps (implement completely in AuthService.selfServiceRegister):
1. Check SELF_SERVICE_ENABLED env — if false, return 503 with { message: 'Self-service signup is disabled. Please request a demo.' }
2. Validate email not already in auth_db public.users (super admins) or any tenant schema
3. Validate planSlug exists, plan.is_active=true, plan.is_publicly_visible=true
4. Generate tenantSlug: slugify(companyName) + check uniqueness → if taken append random 4 digits
5. CREATE tenant record status=pending (TenantsService.create from Phase 6)
   - This triggers: Stripe customer creation + auth_db schema provisioning + seed default roles
6. Create user in new tenant's auth schema: status=active, role=ORG_ADMIN
7. If plan has trial: create Stripe trial subscription (trial_period_days: TRIAL_DAYS)
   Else: create Stripe checkout session and return { checkoutUrl } — user pays before full activation
8. Send welcome email (BullMQ EMAIL_QUEUE, template: welcome.hbs with { firstName, companyName, loginUrl })
9. Return { tenant: { slug, subdomain }, user: { id, email }, requiresPayment: bool, checkoutUrl?: string }

New endpoint: GET /auth/verify-email?token=
- Validate JWT email-verification token (issued at registration, 24h TTl, stored in Redis)
- Mark user.is_email_verified = true
- If tenant status=pending AND subscription is trialing: set tenant status=active
- Return { accessToken, refreshToken, tenant }

## 2. Sales-Driven Onboarding Flow

New endpoint: POST /auth/demo-request
Body: { firstName, lastName, email, company, phone, message, interestedProducts: string[] }

Steps:
1. Save to auth_db public.demo_requests table:
   id, first_name, last_name, email, company, phone, message, interested_products(text[]), status(new|contacted|converted), created_at
2. Enqueue email to DEMO_REQUEST_NOTIFY_EMAIL (notify sales team)
3. Send acknowledgment email to requester (template: demo-request-received.hbs)
4. Return { success: true, message: 'We will contact you within 24 hours' }

New Super Admin endpoint: POST /super-admin/tenants/:id/invite-admin
Body: { email, firstName, lastName }
Steps:
1. Create user in tenant schema: status=invited, role=ORG_ADMIN
2. Generate invite token: sign JWT { userId, tenantSlug, type:'invite' }, store in Redis key invite:{token} TTL=INVITE_TOKEN_TTL_HOURS*3600
3. Send invite email (template: invite.hbs with { firstName, inviteUrl: FRONTEND_URL/accept-invite?token=... })
4. Return { userId, inviteExpiresAt }

New endpoint: POST /auth/accept-invite
Body: { token, password, firstName, lastName }
Steps:
1. Verify token from Redis — if missing: INVITE_TOKEN_EXPIRED error
2. Decode JWT to get userId + tenantSlug
3. Update user: set password_hash, first_name, last_name, status=active
4. Delete Redis key
5. Return { accessToken, refreshToken, tenant }

## 3. Stripe Webhooks — Full Integration with Schema Provisioning

Extend existing webhook.controller.ts (from Phase 4):
POST /billing/webhook (verify Stripe-Signature header using existing STRIPE_WEBHOOK_SECRET)

Handle these events completely:

customer.subscription.created:
1. Find tenant by stripe_customer_id
2. Update tenant_subscriptions: status=active, current_period_start, current_period_end
3. Determine products from plan.product_limits
4. For each product with limit=true: call SchemaProvisionerService.addSingleProductSchema(tenantSlug, product)
5. Insert rows into tenant_product_subscriptions
6. Set tenant.status = active
7. Invalidate tenant cache key in Redis
8. Emit socket event SUBSCRIPTION_ACTIVATED to tenant:{tenantSlug} room (Phase 2)

customer.subscription.updated:
1. Find tenant, get old plan and new plan from subscription metadata
2. Determine added products: newPlan.product_limits - oldPlan.product_limits → provision new schemas
3. Determine removed products: oldPlan.product_limits - newPlan.product_limits → mark inactive in tenant_product_subscriptions (do NOT drop schema yet)
4. Update tenant_subscriptions record
5. Invalidate all permission caches for this tenant: Redis SCAN perm:{tenantSlug}:* and delete

customer.subscription.deleted:
1. Set tenant.status = inactive
2. Set all tenant_product_subscriptions.status = inactive
3. Send subscription-ended email to org admin (EMAIL_QUEUE)
4. Emit SUBSCRIPTION_CANCELLED socket event
5. Enqueue schema cleanup job (BullMQ, delay: 30 * 24 * 60 * 60 * 1000 ms) — job actually drops schemas after 30 days

invoice.payment_succeeded:
1. Insert into invoice_logs table (local mirror)
2. Send invoice-paid email to org admin

invoice.payment_failed:
1. Set tenant_subscriptions.status = past_due
2. Send payment-failed email with retry link
3. If 3 consecutive failures (check invoice_logs count): set tenant.status = suspended

invoice.upcoming (3 days before renewal):
1. Send renewal-reminder email with next billing amount

## 4. Tenant Billing Portal (for Org Admin)

These routes require: JwtAuthGuard + RolesGuard('ORG_ADMIN')

GET    /billing/current
Returns: { subscription, plan, products: ProductName[], usage: { users, storage }, nextBillingDate, amount }

POST   /billing/portal
Returns: { url } — Stripe billing portal URL
Implementation: stripe.billingPortal.sessions.create({ customer: tenant.stripe_customer_id, return_url: FRONTEND_URL })

GET    /billing/invoices
Returns: paginated list from invoice_logs table, filter: status, from, to

POST   /billing/upgrade
Body: { planSlug, interval: 'monthly'|'yearly' }
Steps:
1. Validate new plan exists and is different from current
2. stripe.subscriptions.update with proration_behavior='create_prorations'
3. DO NOT update DB here — wait for customer.subscription.updated webhook

POST   /billing/cancel
Body: { immediately: boolean }
- immediately=false: stripe cancel_at_period_end=true
- immediately=true: stripe cancel immediately
- DO NOT update DB here — wait for customer.subscription.deleted webhook

## 5. Plan Selection Page Data (public endpoints — no auth)
GET /public/plans
Returns: all plans where is_active=true AND is_publicly_visible=true
Ordered by sort_order. Include product_limits and features.

GET /public/plans/:slug
Returns: single plan detail

## 6. Usage Tracking (connect to existing AI cost tracker from Phase 4)
Tenant usage tracked in Redis + flushed to DB every hour (BullMQ repeatable job):
- User count: COUNT from auth_db tenant schema users table
- AI spend: read from existing ai_usage_log (Phase 4) grouped by tenant
- Storage used: track upload sizes via existing StorageService (Phase 3)

Enforcement middleware (add to global middleware chain):
TenantLimitsMiddleware: on every request, check:
- If tenant.status !== 'active': 402 Payment Required with { code: 'SUBSCRIPTION_INACTIVE' }
- (User count enforcement happens in invite flow, not per-request)

## Output
All files complete. Show the complete flow: user visits /public/plans → selects plan → POST /auth/register → receives checkoutUrl → pays on Stripe → webhook fires → schemas provisioned → tenant active → user logs in. Show every step's code.
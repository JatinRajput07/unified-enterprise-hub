Final phase for the NestJS backend. Add complete testing, CI/CD pipeline, Kubernetes manifests, and production monitoring.

## What to build

### 1. Testing Setup
src/__tests__/
├── unit/
│   ├── auth/auth.service.spec.ts
│   ├── users/users.service.spec.ts
│   ├── ai/ai.service.spec.ts
│   └── billing/billing.service.spec.ts
├── integration/
│   ├── setup.ts              # test DB setup/teardown
│   ├── auth.integration.spec.ts
│   └── tenants.integration.spec.ts
└── e2e/
    ├── jest-e2e.config.ts
    ├── app.e2e-spec.ts
    └── auth.e2e-spec.ts

- Jest config: unit (no DB), integration (test DB via TestContainers or .env.test), e2e (full app)
- Unit: mock all dependencies with jest.mock(), no real IO
- Integration: use real PostgreSQL (test container), real Redis (test container), run migrations before suite
- E2E: supertest against full NestJS app, seed test data before each suite, clean after
- Test factories: UserFactory, TenantFactory, RoleFactory using @faker-js/faker
- Coverage thresholds: branches 70%, functions 80%, lines 80%
- Test scripts in package.json: test:unit, test:integration, test:e2e, test:coverage

### 2. Logging & Monitoring
src/monitoring/
├── monitoring.module.ts
├── metrics.service.ts       # Prometheus metrics
└── tracing.ts               # OpenTelemetry setup

- Prometheus metrics via prom-client:
  - http_request_duration_seconds histogram (method, route, status)
  - active_websocket_connections gauge
  - queue_jobs_total counter (queue, status)
  - ai_tokens_used_total counter (model, userId)
- GET /metrics endpoint (Prometheus scrape target, IP-restricted)
- OpenTelemetry tracing: auto-instrument HTTP, TypeORM, Redis, BullMQ
  - Export to Jaeger (OTEL_EXPORTER_JAEGER_ENDPOINT env)
- Grafana dashboard JSON: pre-built dashboard for the above metrics
- Alert rules (Prometheus AlertManager): CPU > 80%, error rate > 5%, queue depth > 1000

### 3. Docker Setup
docker/
├── Dockerfile               # multi-stage: builder + runner
├── Dockerfile.dev           # hot-reload dev image
├── docker-compose.yml       # full local stack
├── docker-compose.test.yml  # test stack
└── .dockerignore

- Multi-stage Dockerfile:
  - Stage 1 (builder): node:20-alpine, install all deps, build NestJS
  - Stage 2 (runner): node:20-alpine, copy only dist + node_modules/prod, non-root user (uid 1001)
  - Image < 300MB target
- docker-compose.yml: app + postgres + redis + elasticsearch + rabbitmq + kibana + jaeger
- Health checks on all services
- Volume mounts for persistent data

### 4. Kubernetes Manifests
k8s/
├── namespace.yaml
├── configmap.yaml           # non-secret config
├── secrets.yaml             # template (use Sealed Secrets in prod)
├── deployments/
│   ├── api.deployment.yaml  # NestJS app
│   └── worker.deployment.yaml # BullMQ workers (separate pod)
├── services/
│   ├── api.service.yaml
│   └── worker.service.yaml
├── hpa.yaml                 # horizontal pod autoscaler
├── ingress.yaml             # nginx ingress with TLS
└── cronjobs/
    └── db-backup.cronjob.yaml

- API deployment: 2 replicas min, rolling update strategy (maxSurge 1, maxUnavailable 0)
- Worker deployment: separate — can scale independently based on queue depth
- HPA: scale API on CPU > 70% (min 2, max 10 pods); scale worker on custom metric (queue depth)
- Resource limits: API pod: requests cpu=250m mem=256Mi, limits cpu=500m mem=512Mi
- Liveness probe: GET /health, failureThreshold: 3, periodSeconds: 10
- Readiness probe: GET /health/ready, failureThreshold: 3, periodSeconds: 5
- Ingress: TLS termination, subdomain routing (*.yourdomain.com → tenant middleware), rate limiting annotation
- Secret management: template shows external-secrets operator annotations for AWS Secrets Manager / Vault

### 5. CI/CD Pipeline (GitHub Actions)
.github/workflows/
├── ci.yml                   # on PR: lint + unit + integration tests
├── cd-staging.yml           # on merge to develop: build + deploy to staging
└── cd-production.yml        # on tag v*.*.*: build + deploy to prod

ci.yml steps:
1. Checkout
2. Setup Node 20
3. Cache node_modules (key: package-lock.json hash)
4. npm ci
5. Lint (eslint + prettier check)
6. Type check (tsc --noEmit)
7. Unit tests with coverage
8. Integration tests (using docker-compose.test.yml service containers)
9. Build Docker image (don't push on PR)
10. Upload coverage to Codecov

cd-staging.yml:
1. Run CI steps
2. Build + push Docker image to ECR/GHCR (tag: sha + latest)
3. Update k8s deployment image tag (kubectl set image)
4. Wait for rollout (kubectl rollout status)
5. Run smoke test (curl /health/ready)
6. Notify Slack on success/failure

cd-production.yml:
1. Require manual approval (GitHub environment protection)
2. Same as staging but with versioned tag
3. Create GitHub Release with changelog

### 6. Secrets Management
- AWS Secrets Manager integration: external-secrets operator pulls secrets into K8s Secrets
- HashiCorp Vault: vault-agent injector sidecar config (alternative)
- Local dev: .env file (gitignored)
- Staging/Prod: never use .env files, all from K8s Secrets
- Secret rotation: BillingService and AIService re-read secrets on interval via SecretManagerService

### 7. Database Migrations in CI
- Migration check in CI: TypeORM migration:run on test DB, fail if pending
- Migration rollback script: npm run migration:revert with confirmation prompt
- Blue-green migration strategy: all migrations must be backward-compatible (no column drops in same PR as code change)
- Migration naming convention enforced via commit-lint rule

### 8. Performance & Final Checklist
- Clustering: cluster.js entry point — fork workers equal to CPU count (or CLUSTER_WORKERS env)
- Graceful shutdown: SIGTERM handler — stop accepting connections, drain queues, close DB pool, exit
- Memory leak prevention: WeakMap for per-request storage, clear AsyncLocalStorage context on response end
- @nestjs/schedule for cron jobs (not BullMQ) for simple maintenance tasks
- Final app.module.ts showing ALL modules integrated
- README.md with: setup instructions, env var table, architecture diagram link, testing guide, deployment guide

## Output
All files complete.
End with a full "Architecture Decision Record" (ADR) summary — one paragraph per major choice explaining why (TypeORM over Prisma, BullMQ over Agenda, etc.)
Include a final checklist: "Before going to production, verify these 20 items."
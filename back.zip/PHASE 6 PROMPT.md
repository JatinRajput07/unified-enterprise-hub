Continue the existing NestJS backend (Phases 1–5 already complete).
DO NOT re-setup: NestJS, JWT, guards, Redis, BullMQ, Stripe base, Winston logger, Docker — all already exist.

## What Phase 1–5 already provides (use as-is)
- ConfigService for all env vars
- JwtAuthGuard, RolesGuard, PermissionsGuard from common/guards/
- BaseEntity (id uuid, createdAt, updatedAt, deletedAt)
- CacheService (Redis wrapper)
- BullMQ queues: EMAIL_QUEUE, NOTIFICATION_QUEUE
- Stripe basic setup in billing.module.ts
- Global exception filter with error codes
- Response interceptor

## New: Core Architecture Concept (explain to AI before coding)
This is a multi-product SaaS platform. The DB layout is:

auth_db — one DB, multiple schemas:
  public schema → tenants, plans, tenant_subscriptions, tenant_product_subscriptions tables (system-wide)
  {tenantSlug} schema (e.g. "abc") → users, roles, permissions, product_roles tables (per-tenant)

Product DBs — each product has its own DB:
  sales_db → schema per tenant (abc, xyz) created ONLY when tenant subscribes to CRM/Sales
  hrms_db  → schema per tenant, created ONLY when tenant subscribes to HRMS
  pms_db   → schema per tenant, created ONLY when tenant subscribes to PMS
  finance_db → schema per tenant, created ONLY when tenant subscribes to Finance

New .env variables to add to existing .env.example:
AUTH_DB_HOST=localhost
AUTH_DB_PORT=5432
AUTH_DB_NAME=auth_db
AUTH_DB_USER=postgres
AUTH_DB_PASS=secret
AUTH_DB_POOL_MAX=20

SALES_DB_HOST=localhost
SALES_DB_PORT=5432
SALES_DB_NAME=sales_db
SALES_DB_USER=postgres
SALES_DB_PASS=secret

HRMS_DB_HOST=localhost
HRMS_DB_PORT=5432
HRMS_DB_NAME=hrms_db
HRMS_DB_USER=postgres
HRMS_DB_PASS=secret

PMS_DB_HOST=localhost
PMS_DB_PORT=5432
PMS_DB_NAME=pms_db
PMS_DB_USER=postgres
PMS_DB_PASS=secret

FINANCE_DB_HOST=localhost
FINANCE_DB_PORT=5432
FINANCE_DB_NAME=finance_db
FINANCE_DB_USER=postgres
FINANCE_DB_PASS=secret

SUPER_ADMIN_EMAIL=admin@platform.com
SUPER_ADMIN_PASSWORD=SuperStr0ng!

## New files to create

### 1. Multi-DB Connection Manager
src/database/tenant-connection.service.ts

- Maintains Map<`${productDb}:${tenantSlug}`, DataSource> connection pool
- getConnection(product: 'auth'|'sales'|'hrms'|'pms'|'finance', tenantSlug: string): Promise<DataSource>
  - If connection exists in map and is connected: return it
  - Else: create new TypeORM DataSource for that product DB, set search_path=tenantSlug, initialize, cache, return
- closeConnection(product, tenantSlug): Promise<void>
- onModuleDestroy(): close all cached DataSources gracefully
- healthCheck(): Promise<{ product, tenantSlug, status }[]> — pings all active connections

src/database/schema-provisioner.service.ts

- provisionSchema(tenantSlug: string, products: ProductName[]): Promise<void>
  For each product in products array:
    1. Get raw PG client for that product DB
    2. Execute: CREATE SCHEMA IF NOT EXISTS "{tenantSlug}"
    3. Run TypeORM migrations for that product in the new schema (set search_path first)
    4. Log success to audit
  Wrap entire operation in try/catch — if any product fails, log error but continue others (partial provision is acceptable, retry later)

- deprovisionSchema(tenantSlug: string, products: ProductName[]): Promise<void>
  For each product: DROP SCHEMA IF EXISTS "{tenantSlug}" CASCADE
  Remove from TenantConnectionService pool

- addSingleProductSchema(tenantSlug: string, product: ProductName): Promise<void>
  Used when tenant subscribes to a new product mid-lifecycle

- listProvisionedSchemas(tenantSlug: string): Promise<ProductName[]>
  Check which product DBs actually have this tenant's schema (SELECT schema_name FROM information_schema.schemata)

src/database/product-db.constants.ts

export const PRODUCT_DB_NAMES = {
  auth: 'auth',
  sales: 'sales',
  hrms: 'hrms',
  pms: 'pms',
  finance: 'finance',
} as const;
export type ProductName = keyof typeof PRODUCT_DB_NAMES;

### 2. Update existing database.config.ts
Extend to include all 5 DB configs, each loaded from their own env vars.
Export a getProductDbConfig(product: ProductName) function used by TenantConnectionService.

### 3. Super Admin Module
src/modules/super-admin/
├── super-admin.module.ts
├── guards/
│   └── super-admin.guard.ts     # checks role === SUPER_ADMIN AND header X-Admin-Key matches env ADMIN_KEY
├── plans/
│   ├── plan.entity.ts           # auth_db public schema
│   ├── plans.service.ts
│   ├── plans.controller.ts
│   └── dto/
│       ├── create-plan.dto.ts
│       └── update-plan.dto.ts
├── tenants/
│   ├── tenant.entity.ts         # auth_db public schema
│   ├── tenants.service.ts
│   ├── tenants.controller.ts
│   └── dto/
│       ├── create-tenant.dto.ts
│       └── update-tenant.dto.ts
└── subscriptions/
    ├── tenant-subscription.entity.ts
    ├── tenant-product-subscription.entity.ts
    └── subscriptions.service.ts

plan.entity.ts fields:
id, name, slug(unique), description, price_monthly(decimal), price_yearly(decimal),
stripe_product_id, stripe_price_id_monthly, stripe_price_id_yearly,
features(jsonb: string[]),
product_limits(jsonb: { sales: bool, hrms: bool, pms: bool, finance: bool }),
max_users(int), max_storage_gb(int), ai_cost_limit_usd(decimal),
is_active(bool), is_publicly_visible(bool), sort_order(int),
created_at, updated_at, deleted_at

tenant.entity.ts fields:
id, name, slug(unique — used as DB schema name), subdomain(unique), custom_domain(nullable),
plan_id(FK → plans), status(enum: pending|active|inactive|suspended|deleted),
settings(jsonb: { timezone, language, logoUrl, primaryColor }),
stripe_customer_id, onboarding_type(enum: self_service|sales_driven),
max_users(int — copied from plan at subscription time),
created_at, updated_at, deleted_at

tenant_subscriptions fields:
id, tenant_id(FK), plan_id(FK), stripe_subscription_id(unique), stripe_customer_id,
status(active|past_due|cancelled|trialing), interval(monthly|yearly),
current_period_start, current_period_end, cancel_at_period_end(bool),
trial_end(nullable), created_at, updated_at

tenant_product_subscriptions fields:
id, tenant_id(FK), product_name(ProductName enum), status(active|inactive),
subscribed_at, expires_at(nullable), created_at

### 4. Plans CRUD (all routes under /super-admin, protected by SuperAdminGuard)

PlansController routes:
POST   /super-admin/plans
GET    /super-admin/plans              # include is_active filter
GET    /super-admin/plans/:id
PATCH  /super-admin/plans/:id
DELETE /super-admin/plans/:id          # soft delete — check no active tenants on this plan first

PlansService.create(dto): Promise<Plan>
- Validate slug uniqueness
- If stripe_product_id not provided: create Stripe Product + Price via existing StripeService
- Save and return

PlansService.update(id, dto): Promise<Plan>
- If price changed: create new Stripe Price (never update old — Stripe doesn't allow it), update stripe_price_id
- If product_limits reduced: check if any active tenant uses those products → throw error with list

PlansService.delete(id): Promise<void>
- Check: SELECT count(*) FROM tenant_subscriptions WHERE plan_id = id AND status = 'active'
- If > 0: throw PLAN_HAS_ACTIVE_TENANTS error
- Else: soft delete

### 5. Tenants CRUD + Lifecycle

TenantsController routes:
POST   /super-admin/tenants
GET    /super-admin/tenants                        # paginated, filter: status, plan_id, search(name/slug)
GET    /super-admin/tenants/:id                    # full detail: tenant + subscription + product_subscriptions + user count
PATCH  /super-admin/tenants/:id                    # update settings/config only
POST   /super-admin/tenants/:id/activate
POST   /super-admin/tenants/:id/deactivate
POST   /super-admin/tenants/:id/suspend            # body: { reason }
DELETE /super-admin/tenants/:id                    # soft delete
POST   /super-admin/tenants/:id/products/:product  # add product → creates schema
DELETE /super-admin/tenants/:id/products/:product  # remove product → marks inactive (does NOT drop schema immediately — schedule for 30 days)
GET    /super-admin/tenants/:id/usage              # user count, storage used, AI spend this month

TenantsService.create(dto): Promise<Tenant>
Steps (in order, all in try/catch with rollback notes):
1. Validate slug uniqueness in tenants table
2. Validate plan exists and is active
3. Create tenant record (status=pending)
4. Create Stripe customer: existing BillingService.createCustomer(tenant)
5. Provision auth_db schema: SchemaProvisionerService.provisionSchema(slug, ['auth'])
6. Seed default roles in new schema: insert SUPER_ADMIN, ORG_ADMIN, EMPLOYEE roles + their permissions
7. If dto.products provided: provision those product schemas too
8. Set status=active
9. Return tenant

TenantsService.activate/deactivate/suspend(id): simple status update + cache invalidation
TenantsService.delete(id):
1. Soft delete tenant record
2. Cancel Stripe subscription if active
3. Schedule schema deprovision job (BullMQ, delay 30 days) — do NOT drop immediately

TenantsService.addProduct(tenantId, product):
1. Check tenant's plan.product_limits[product] === true — else throw PRODUCT_NOT_IN_PLAN
2. Check not already subscribed
3. SchemaProvisionerService.addSingleProductSchema(tenantSlug, product)
4. Insert into tenant_product_subscriptions
5. Invalidate tenant cache

### 6. Super Admin Stats endpoints
GET /super-admin/stats/overview
Returns: { totalTenants, activeTenants, mrr, arr, totalRevenue30d, newTenantsThisMonth, churnedThisMonth }

GET /super-admin/stats/tenants/:id/usage
Returns: { userCount, maxUsers, storageUsedGb, maxStorageGb, aiSpendThisMonth, aiLimitUsd, activeProducts[] }

### 7. Seed Super Admin on app start
src/database/seeds/super-admin.seed.ts
- On application bootstrap (AppModule onApplicationBootstrap):
  - Check if SUPER_ADMIN_EMAIL user exists in auth_db public.super_admins table
  - If not: create with hashed SUPER_ADMIN_PASSWORD, role=SUPER_ADMIN
  - Log "Super admin seeded" — idempotent (safe to run multiple times)

### 8. Update existing docker-compose.yml
Add 4 new postgres services to existing docker-compose.yml:
  sales-db, hrms-db, pms-db, finance-db
Each with own named volume and healthcheck.
DO NOT change existing services.

## Output
All files complete. Show how TenantsService.create() uses the existing BillingService and new SchemaProvisionerService together. Include rollback strategy comments when schema provisioning fails mid-way.